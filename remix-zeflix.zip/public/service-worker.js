// Kill-switch service worker.
//
// O app não usa mais cache de app-shell: qualquer service worker antigo ainda
// registrado nos dispositivos (TV Box, celulares) fica servindo HTML/JS
// desatualizados. Este worker substitui o antigo no mesmo caminho, apaga
// somente os caches criados por ele, assume o controle imediatamente
// (skipWaiting + clients.claim), recarrega as abas abertas para pegar a
// versão nova e então se desregistra.
//
// Caches de outros workers (ex.: mensageria/push) são preservados: o Cache
// Storage é escopado por origem, então filtramos pelo escopo desta
// registration.
function isOwnAppShellCache(name) {
  const looksLikeAppShell = /(^|-)precache-v\d+-|(^|-)runtime-|(^|-)workbox-|(^|-)zeflix-/.test(
    name,
  );
  return looksLikeAppShell && name.endsWith(self.registration.scope);
}

self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      try {
        const names = await caches.keys();
        await Promise.allSettled(
          names.filter(isOwnAppShellCache).map((name) => caches.delete(name)),
        );
        await self.clients.claim();
        const clients = await self.clients.matchAll({ type: "window" });
        await Promise.allSettled(clients.map((client) => client.navigate(client.url)));
      } finally {
        await self.registration.unregister();
      }
    })(),
  ),
);

// Enquanto este worker estiver ativo, nada é servido do cache: sempre rede.
self.addEventListener("fetch", (event) => {
  event.respondWith(fetch(event.request));
});
