ALTER TABLE public.favorites REPLICA IDENTITY FULL;
ALTER TABLE public.watch_progress REPLICA IDENTITY FULL;
ALTER TABLE public.watched REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'favorites'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.favorites;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'watch_progress'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.watch_progress;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'watched'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.watched;
  END IF;
END $$;