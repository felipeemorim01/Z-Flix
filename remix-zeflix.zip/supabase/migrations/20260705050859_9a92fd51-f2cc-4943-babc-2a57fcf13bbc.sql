
CREATE TABLE public.watched (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  key TEXT NOT NULL,
  kind TEXT NOT NULL,
  content_id BIGINT NOT NULL,
  episode_id BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.watched TO authenticated;
GRANT ALL ON public.watched TO service_role;
ALTER TABLE public.watched ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own watched" ON public.watched FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX watched_user_key_idx ON public.watched (user_id, key);
