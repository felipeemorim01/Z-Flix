const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges, Content-Type",
};

const PROVIDER_HEADERS: Record<string, string> = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  Referer: "http://iptvagora.ddns.net/",
  Origin: "http://iptvagora.ddns.net",
  Accept: "*/*",
};

function corsHeaders(headers: HeadersInit = {}): Headers {
  const result = new Headers(headers);
  for (const [key, value] of Object.entries(CORS_HEADERS)) result.set(key, value);
  return result;
}

function jsonError(message: string, status: number): Response {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: corsHeaders({ "Content-Type": "application/json" }),
  });
}

function buildProxyUrl(origin: string, target: string): string {
  return `${origin}/functions/v1/iptv-proxy?url=${encodeURIComponent(target)}`;
}

function rewriteManifestStream(
  body: ReadableStream<Uint8Array>,
  targetUrl: string,
  proxyOrigin: string,
): ReadableStream<Uint8Array> {
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  const base = new URL(targetUrl);
  let pending = "";

  const resolve = (raw: string): string => {
    try {
      return new URL(raw, base).toString();
    } catch {
      return raw;
    }
  };

  const rewriteLine = (line: string): string => {
    const trimmed = line.trim();
    if (!trimmed) return line;

    if (trimmed.startsWith("#")) {
      return line.replace(/URI="([^"]+)"/g, (_match, uri: string) => {
        return `URI="${buildProxyUrl(proxyOrigin, resolve(uri))}"`;
      });
    }

    return buildProxyUrl(proxyOrigin, resolve(trimmed));
  };

  return body.pipeThrough(
    new TransformStream<Uint8Array, Uint8Array>({
      transform(chunk, controller) {
        pending += decoder.decode(chunk, { stream: true });
        const lines = pending.split(/\r?\n/);
        pending = lines.pop() ?? "";

        for (const line of lines) {
          controller.enqueue(encoder.encode(`${rewriteLine(line)}\n`));
        }
      },
      flush(controller) {
        pending += decoder.decode();
        if (pending) controller.enqueue(encoder.encode(rewriteLine(pending)));
      },
    }),
  );
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders() });
  }

  if (request.method !== "GET") {
    return jsonError("Method not allowed.", 405);
  }

  const incomingUrl = new URL(request.url);
  const target = incomingUrl.searchParams.get("url");
  if (!target) return jsonError("Missing 'url' query parameter.", 400);

  let targetUrl: URL;
  try {
    targetUrl = new URL(target);
  } catch {
    return jsonError("Invalid target URL.", 400);
  }

  if (targetUrl.protocol !== "http:" && targetUrl.protocol !== "https:") {
    return jsonError("Only http/https URLs are allowed.", 400);
  }

  const forwardHeaders = new Headers(PROVIDER_HEADERS);
  const range = request.headers.get("range");
  if (range) forwardHeaders.set("Range", range);

  let upstream: Response;
  try {
    upstream = await fetch(targetUrl.toString(), {
      method: "GET",
      headers: forwardHeaders,
      redirect: "follow",
    });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Upstream request failed.", 502);
  }

  const responseHeaders = corsHeaders();
  for (const name of [
    "content-type",
    "content-length",
    "content-range",
    "accept-ranges",
    "cache-control",
  ]) {
    const value = upstream.headers.get(name);
    if (value) responseHeaders.set(name, value);
  }

  const contentType = upstream.headers.get("content-type") ?? "";
  const isManifest =
    /mpegurl|m3u8/i.test(contentType) ||
    /\.m3u8(\?|$)/i.test(targetUrl.pathname + targetUrl.search);

  if (isManifest && upstream.body) {
    responseHeaders.set("Content-Type", "application/vnd.apple.mpegurl");
    responseHeaders.delete("Content-Length");
    return new Response(
      rewriteManifestStream(upstream.body, targetUrl.toString(), incomingUrl.origin),
      {
        status: upstream.status,
        headers: responseHeaders,
      },
    );
  }

  return new Response(upstream.body, {
    status: upstream.status,
    headers: responseHeaders,
  });
});
