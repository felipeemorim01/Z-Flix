# ZéFlix

vc pode Criar um web app de player de IPTV estilo Netflix. A tela inicial deve ter um formulário para o usuário digitar: URL do Servidor, Usuário e Senha (padrão Xtream Codes API). O app deve buscar a lista de canais, filmes e séries, organizá-los por categorias e usar o Hls.js para reproduzir os vídeos na tela. Inclua uma solução de proxy simples para evitar problemas de CORS., caso sim, me responda para decidirmos o que vamos fazer primeiro.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://zeflix.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/643baf8e-2032-4a99-8301-66d1b4a0ca26).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
