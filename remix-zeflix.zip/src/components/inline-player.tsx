import { Suspense, lazy, useEffect } from "react";
import type { VideoPlayerProps } from "./video-player";

// Lazy: video-player (~500 linhas) + hls.js (~180KB min) só entram no bundle
// quando o usuário realmente inicia uma reprodução.
const VideoPlayer = lazy(() => import("./video-player").then((m) => ({ default: m.VideoPlayer })));

export interface InlinePlayerProps extends Omit<VideoPlayerProps, "onExit"> {
  open: boolean;
  onClose: () => void;
}

/**
 * Fullscreen overlay that mounts the VideoPlayer directly on top of the
 * content page. O fechamento é feito pelo próprio VideoPlayer (Esc, Backspace,
 * teclas de "voltar" da TV — WebOS 461, Tizen 10009 — e saída do fullscreen)
 * que dispara o `onExit`. NÃO manipulamos o history aqui porque o StrictMode
 * do React 18 faz mount→unmount→mount no dev; o `history.back()` do cleanup
 * enfileirava um `popstate` que era capturado pelo listener da segunda
 * montagem e fechava o player imediatamente após abrir.
 */
export function InlinePlayer({ open, onClose, ...playerProps }: InlinePlayerProps) {
  // Prevent background scroll while the overlay is up.
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] bg-black"
      role="dialog"
      aria-modal="true"
      aria-label="Player de vídeo"
    >
      <Suspense
        fallback={
          <div className="grid size-full place-items-center text-white/70">Carregando player…</div>
        }
      >
        <VideoPlayer {...playerProps} onExit={onClose} />
      </Suspense>
    </div>
  );
}
