import { useRouter } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface BackButtonProps {
  fallback?: string;
  label?: string;
  className?: string;
}

/**
 * Botão "Voltar" que retorna à página anterior via histórico do router.
 * Se não há histórico (usuário abriu deep link), navega para o fallback.
 */
export function BackButton({ fallback = "/browse", label = "Voltar", className }: BackButtonProps) {
  const router = useRouter();

  const handleClick = () => {
    // TanStack Router expõe o histórico do navegador via router.history.
    // Se houver entrada anterior, usa-a; caso contrário vai para o fallback.
    if (typeof window !== "undefined" && window.history.length > 1) {
      router.history.back();
    } else {
      void router.navigate({ to: fallback });
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border bg-surface/70 px-2.5 py-1 text-xs font-medium text-muted-foreground backdrop-blur transition-colors hover:border-primary/40 hover:bg-surface hover:text-foreground",
        className,
      )}
    >
      <ArrowLeft className="size-3.5" aria-hidden />
      {label}
    </button>
  );
}
