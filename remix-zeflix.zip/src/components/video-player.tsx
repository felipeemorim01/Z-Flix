import { useCallback, useEffect, useRef, useState } from "react";
import {
  Cast,
  Check,
  Copy,
  ExternalLink,
  Play,
  Share2,
  ShieldCheck,
  SkipForward,
  Tv,
  X,
} from "lucide-react";
import {
  getProgress,
  markWatched,
  removeProgress,
  saveProgress,
  whenLibraryLoaded,
  type MediaKind,
} from "@/lib/library";
import { useCast } from "@/hooks/use-cast";
import { CastRemoteOverlay } from "./cast-remote-overlay";

export interface VideoPlayerProps {
  src: string;
  isHls: boolean;
  /** When set, the player persists playback progress for this key. */
  trackingKey?: string;
  /** When set, renders an in-player "Next episode" overlay (visible in fullscreen). */
  nextHref?: string | null;
  /** Alternative to nextHref: fires a callback instead of navigating (used by inline series player). */
  onNext?: (() => void) | null;
  entry: {
    kind: MediaKind;
    id: number;
    episodeId?: number;
    title: string;
    image?: string;
    href: string;
  };
  /**
   * Called when the user leaves the player via fullscreen-exit, Esc, or the
   * TV remote back button. If not provided, defaults to `window.history.back()`
   * (used by the standalone /watch route).
   */
  onExit?: () => void;
}

/**
 * Pure Cast & External Player Hub:
 * Eliminates all internal browser <video> buffering and Hls.js execution to prevent
 * IPTV providers from blocking browser sessions.
 * Directly sends streams to Google Cast (Smart TV, Mi TV Stick, Chromecast) or
 * external players (Web Video Caster, VLC, MX Player).
 */
export function VideoPlayer({
  src,
  isHls,
  trackingKey,
  nextHref,
  onNext,
  entry,
  onExit,
}: VideoPlayerProps) {
  const cast = useCast();
  const lastCastSrcRef = useRef<string | null>(null);
  const completedRef = useRef(false);
  const [copied, setCopied] = useState(false);
  const [isConnectingCast, setIsConnectingCast] = useState(false);

  const goNext = useCallback(() => {
    if (!nextHref && !onNext) return;
    if (trackingKey) {
      markWatched(trackingKey);
      removeProgress(trackingKey);
    }
  }, [nextHref, onNext, trackingKey]);

  // When Cast connects or new content arrives while connected:
  useEffect(() => {
    if (!cast.isConnected) {
      lastCastSrcRef.current = null;
      return;
    }

    if (lastCastSrcRef.current !== src) {
      lastCastSrcRef.current = src;
      void cast.castMedia({
        url: src,
        title: entry.title,
        image: entry.image,
        isHls,
      });
    }
  }, [cast.isConnected, src, entry.title, entry.image, isHls, cast]);

  // Sync Cast progress & Auto-Next while casting
  useEffect(() => {
    if (!cast.isConnected || !trackingKey) return;
    const dur = cast.duration || 0;
    const pos = cast.currentTime || 0;

    if (pos > 0 && dur > 0) {
      const nearEnd = pos / dur >= 0.95;
      if (nearEnd && !completedRef.current) {
        completedRef.current = true;
        saveProgress({
          key: trackingKey,
          kind: entry.kind,
          id: entry.id,
          episodeId: entry.episodeId,
          title: entry.title,
          image: entry.image,
          href: entry.href,
          position: pos,
          duration: dur,
        });

        // Trigger next episode
        if (onNext) {
          goNext();
          onNext();
        } else if (nextHref && typeof window !== "undefined") {
          goNext();
          window.location.href = nextHref;
        }
      } else if (!completedRef.current) {
        saveProgress({
          key: trackingKey,
          kind: entry.kind,
          id: entry.id,
          episodeId: entry.episodeId,
          title: entry.title,
          image: entry.image,
          href: entry.href,
          position: pos,
          duration: dur,
        });
      }
    }
  }, [
    cast.isConnected,
    cast.currentTime,
    cast.duration,
    trackingKey,
    entry,
    onNext,
    nextHref,
    goNext,
  ]);

  const handleStartCast = async () => {
    setIsConnectingCast(true);
    try {
      const ok = await cast.requestSession();
      if (ok) {
        await cast.castMedia({
          url: src,
          title: entry.title,
          image: entry.image,
          isHls,
        });
      }
    } catch (e) {
      console.warn("Cast request error:", e);
    } finally {
      setIsConnectingCast(false);
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(src);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleOpenWvc = () => {
    const wvcUrl = `wvc-x-callback://open?url=${encodeURIComponent(src)}`;
    window.location.href = wvcUrl;
  };

  const handleOpenVlc = () => {
    // VLC scheme
    const vlcUrl = `vlc://${src}`;
    window.location.href = vlcUrl;
  };

  // Keyboard navigation / exit
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Backspace" || e.keyCode === 10009 || e.keyCode === 461) {
        e.preventDefault();
        if (onExit) onExit();
        else if (typeof window !== "undefined") window.history.back();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onExit]);

  // If Cast is active, show the full Remote Control overlay
  if (cast.isConnected) {
    return (
      <CastRemoteOverlay
        title={entry.title}
        kind={entry.kind}
        image={entry.image}
        isHls={isHls}
        nextHref={nextHref}
        onNext={onNext}
        onExit={onExit}
      />
    );
  }

  // If not connected, show the Cast & External Transmission Hub
  return (
    <div
      className="relative flex min-h-screen size-full flex-col justify-between overflow-y-auto bg-background/95 p-4 text-foreground backdrop-blur-2xl md:p-10"
      role="region"
      aria-label="Central de Transmissão para TV"
    >
      {/* Background artwork blur */}
      {entry.image && (
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-20 blur-3xl"
          style={{
            backgroundImage: `url(${entry.image})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
      )}

      {/* Top bar */}
      <header className="flex items-center justify-between gap-3 border-b border-border/40 pb-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-xl border border-primary/40 bg-primary/20 text-primary shadow-sm">
            <Tv className="size-4" />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Transmissão Sem Buffer Interno
            </p>
            <h2 className="truncate font-display text-sm font-bold text-foreground md:text-base">
              Transmitir para TV
            </h2>
          </div>
        </div>

        {onExit && (
          <button
            type="button"
            onClick={onExit}
            className="flex size-9 items-center justify-center rounded-full border border-border/60 bg-surface/60 text-muted-foreground transition hover:bg-surface hover:text-foreground active:scale-95"
            title="Voltar ao catálogo"
          >
            <X className="size-4" />
          </button>
        )}
      </header>

      {/* Main card */}
      <main className="my-auto mx-auto flex w-full max-w-xl flex-col items-center py-6 text-center">
        {entry.image && (
          <div className="relative mb-5 aspect-video w-full max-w-[260px] overflow-hidden rounded-2xl border border-border/60 shadow-2xl sm:max-w-[320px]">
            <img
              src={entry.image}
              alt={entry.title}
              className="size-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        )}

        <span className="inline-block rounded-full bg-primary/20 px-3 py-0.5 text-xs font-bold uppercase tracking-widest text-primary">
          {entry.kind === "live" ? "Canal de TV" : entry.kind === "series" ? "Série" : "Filme"}
        </span>

        <h1 className="mt-2 font-display text-xl font-extrabold tracking-tight text-foreground sm:text-2xl md:text-3xl">
          {entry.title}
        </h1>

        <div className="mt-3 flex items-center justify-center gap-1.5 text-xs text-emerald-400">
          <ShieldCheck className="size-4 shrink-0" />
          <span>Proteção Anti-Bloqueio: Reprodução direta via Cast / Player Externo</span>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex w-full flex-col gap-3">
          {/* Main: Google Cast */}
          <button
            type="button"
            onClick={handleStartCast}
            disabled={isConnectingCast}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-primary px-6 py-4 text-base font-bold text-primary-foreground shadow-lg shadow-primary/30 transition hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50"
          >
            <Cast className="size-5 animate-pulse" />
            {isConnectingCast
              ? "Procurando dispositivos..."
              : "Transmitir para TV / Mi TV Stick (Cast)"}
          </button>

          {/* Secondary: Web Video Caster / VLC */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <button
              type="button"
              onClick={handleOpenWvc}
              className="flex items-center justify-center gap-2 rounded-xl border border-border/60 bg-surface/80 px-4 py-3 text-sm font-semibold text-foreground transition hover:border-primary/60 hover:bg-surface active:scale-95"
            >
              <ExternalLink className="size-4 text-primary" />
              <span>Web Video Caster</span>
            </button>

            <button
              type="button"
              onClick={handleOpenVlc}
              className="flex items-center justify-center gap-2 rounded-xl border border-border/60 bg-surface/80 px-4 py-3 text-sm font-semibold text-foreground transition hover:border-primary/60 hover:bg-surface active:scale-95"
            >
              <ExternalLink className="size-4 text-primary" />
              <span>Abrir no VLC</span>
            </button>
          </div>

          {/* Tertiary: Copy stream URL */}
          <button
            type="button"
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-background/50 px-4 py-2.5 text-xs font-semibold text-muted-foreground transition hover:border-primary hover:text-foreground active:scale-95"
          >
            {copied ? (
              <>
                <Check className="size-3.5 text-emerald-400" />
                <span className="text-emerald-400">
                  Link direto copiado para a área de transferência!
                </span>
              </>
            ) : (
              <>
                <Copy className="size-3.5" />
                <span>Copiar link direto do stream (para colar em outros apps)</span>
              </>
            )}
          </button>
        </div>
      </main>

      {/* Bottom info */}
      <footer className="mx-auto w-full max-w-xl text-center text-xs text-muted-foreground">
        <p>
          O vídeo será transmitido diretamente da sua conexão para a TV sem carregar buffer no
          navegador.
        </p>
      </footer>
    </div>
  );
}
