import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useCredentialsResolved, useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { useActiveProfile } from "@/hooks/use-profile";
import { proxiedImage } from "@/lib/xtream";
import { cn } from "@/lib/utils";

export interface CatalogPageProps {
  kind: "movie" | "series";
  title: string;
  subtitle: string;
}

export function CatalogPage({ kind, title, subtitle }: CatalogPageProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const credentials = useStoredCredentials();
  const resolved = useCredentialsResolved();
  const navigate = useNavigate();
  const activeProfile = useActiveProfile();
  useEffect(() => {
    if (mounted && resolved && !credentials) void navigate({ to: "/", replace: true });
  }, [mounted, resolved, credentials, navigate]);

  const catalog = useXtreamCatalog(mounted ? credentials : null);
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [mobileSelectedCat, setMobileSelectedCat] = useState<string | null>(null);

  const categories = kind === "movie" ? catalog.vodCategories : catalog.seriesCategories;

  const grouped = useMemo(() => {
    const byCat = new Map<string, RailItem[]>();
    if (kind === "movie") {
      for (const s of catalog.vodStreams) {
        const image = proxiedImage(s.stream_icon);
        const ext = s.container_extension ?? "mp4";
        const params = new URLSearchParams({ ext, title: s.name });
        if (image) params.set("image", image);
        const item: RailItem = {
          id: `vod-${s.stream_id}`,
          title: s.name,
          image,
          href: `/movie/${s.stream_id}?${params.toString()}`,
          favorite: { kind: "movie", contentId: s.stream_id },
        };
        const list = byCat.get(s.category_id) ?? [];
        list.push(item);
        byCat.set(s.category_id, list);
      }
    } else {
      for (const s of catalog.series) {
        const item: RailItem = {
          id: `series-${s.series_id}`,
          title: s.name,
          image: proxiedImage(s.cover),
          href: `/series/${s.series_id}`,
          favorite: { kind: "series", contentId: s.series_id },
        };
        const list = byCat.get(s.category_id) ?? [];
        list.push(item);
        byCat.set(s.category_id, list);
      }
    }
    return byCat;
  }, [kind, catalog.vodStreams, catalog.series]);

  const populatedCategories = useMemo(
    () => categories.filter((c) => (grouped.get(c.category_id)?.length ?? 0) > 0),
    [categories, grouped],
  );

  // Seleciona a primeira categoria automaticamente no Desktop
  useEffect(() => {
    if (!activeCat && populatedCategories.length > 0) {
      setActiveCat(populatedCategories[0].category_id);
    }
  }, [activeCat, populatedCategories]);

  // Desktop active items
  const currentItems = activeCat ? (grouped.get(activeCat) ?? []) : [];
  const rawCurrentName =
    populatedCategories.find((c) => c.category_id === activeCat)?.category_name ?? "";
  const currentName = rawCurrentName.includes("|")
    ? (rawCurrentName.split("|").pop()?.trim() ?? rawCurrentName)
    : rawCurrentName;

  // Mobile selected items
  const mobileCurrentItems = mobileSelectedCat ? (grouped.get(mobileSelectedCat) ?? []) : [];
  const rawMobileCurrentName =
    populatedCategories.find((c) => c.category_id === mobileSelectedCat)?.category_name ?? "";
  const mobileCurrentName = rawMobileCurrentName.includes("|")
    ? (rawMobileCurrentName.split("|").pop()?.trim() ?? rawMobileCurrentName)
    : rawMobileCurrentName;

  const themeColor = activeProfile?.color || "var(--primary)";

  return (
    <div className="min-h-screen bg-background text-foreground no-scrollbar">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-[1600px] px-3.5 py-3 md:px-10 md:py-6">
        {!mounted || catalog.isLoading ? (
          <p className="py-8 text-center text-xs text-muted-foreground md:text-left md:text-sm">
            Carregando catálogo…
          </p>
        ) : catalog.error ? (
          <p className="py-8 text-center text-xs text-primary md:text-left md:text-sm">
            Não foi possível carregar: {catalog.error.message}
          </p>
        ) : populatedCategories.length === 0 ? (
          <p className="py-8 text-center text-xs text-muted-foreground md:text-left md:text-sm">
            Nenhuma categoria disponível.
          </p>
        ) : (
          <>
            {/* ========================================================================= */}
            {/* VERSÃO MOBILE: Grade de 3 cards por linha de categorias + Drill-down 2 colunas */}
            {/* ========================================================================= */}
            <div className="block md:hidden">
              {mobileSelectedCat ? (
                /* Visualização dos conteúdos da categoria selecionada no Mobile (2 banners por linha) */
                <div className="space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between gap-2 border-b border-border/40 pb-2.5">
                    <button
                      type="button"
                      onClick={() => setMobileSelectedCat(null)}
                      className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/15 px-3 py-1.5 text-xs font-bold text-primary shadow-xs transition active:scale-95"
                    >
                      <ChevronLeft className="size-4" />
                      <span>Categorias</span>
                    </button>
                    <div className="text-right">
                      <h2 className="max-w-[180px] truncate font-display text-sm font-bold text-foreground">
                        {mobileCurrentName}
                      </h2>
                      <p className="text-[10px] font-semibold text-muted-foreground">
                        {mobileCurrentItems.length} {kind === "movie" ? "filmes" : "séries"}
                      </p>
                    </div>
                  </div>

                  <ContentRail
                    id={`mobile-${mobileSelectedCat}`}
                    items={mobileCurrentItems}
                    layout="grid"
                    kind={kind}
                  />
                </div>
              ) : (
                /* Visualização principal: Grade de 3 cards de categorias por linha */
                <div className="space-y-3">
                  {/* Grade de 3 categorias por linha */}
                  <div className="grid grid-cols-3 gap-2 pt-0.5">
                    {populatedCategories.map((c) => {
                      const displayName = c.category_name.includes("|")
                        ? (c.category_name.split("|").pop()?.trim() ?? c.category_name)
                        : c.category_name;
                      const count = grouped.get(c.category_id)?.length ?? 0;

                      return (
                        <button
                          key={c.category_id}
                          type="button"
                          onClick={() => {
                            setMobileSelectedCat(c.category_id);
                            window.scrollTo({ top: 0, behavior: "smooth" });
                          }}
                          className="group relative flex min-h-[82px] flex-col items-center justify-center rounded-2xl border border-border/70 bg-surface/85 px-2 py-3 text-center shadow-xs transition-all hover:border-primary/60 hover:bg-surface active:scale-95"
                        >
                          <p className="line-clamp-2 font-display text-xs font-bold uppercase leading-tight tracking-tight text-foreground transition-colors group-hover:text-primary">
                            {displayName}
                          </p>
                          <span className="mt-1.5 rounded-full bg-background/60 px-2 py-0.5 text-[9px] font-bold tabular-nums text-muted-foreground/80">
                            {count}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* ========================================================================= */}
            {/* VERSÃO DESKTOP: Barra vertical 50x50 + grade de catálogo à direita       */}
            {/* ========================================================================= */}
            <div className="hidden md:grid md:grid-cols-[60px_1fr] md:gap-6">
              <aside className="md:sticky md:top-24 md:self-start">
                <nav
                  aria-label="Categorias Desktop"
                  className="flex max-h-[calc(100vh-10rem)] flex-col gap-2 overflow-y-auto no-scrollbar pr-1"
                >
                  {populatedCategories.map((c) => {
                    const active = c.category_id === activeCat;
                    const displayName = c.category_name.includes("|")
                      ? (c.category_name.split("|").pop()?.trim() ?? c.category_name)
                      : c.category_name;

                    return (
                      <button
                        key={c.category_id}
                        type="button"
                        onClick={() => setActiveCat(c.category_id)}
                        title={c.category_name}
                        style={{
                          borderColor: active ? themeColor : "transparent",
                          backgroundColor: active ? `${themeColor}20` : undefined,
                        }}
                        className={cn(
                          "group relative flex size-[50px] shrink-0 items-center justify-center rounded-xl border-2 text-center transition-all duration-200",
                          active
                            ? "shadow-lg shadow-primary/10"
                            : "border-border/40 bg-surface/40 text-muted-foreground hover:border-border hover:bg-surface/80 hover:text-foreground",
                        )}
                      >
                        <span className="line-clamp-2 px-1 text-[9px] font-bold leading-[1.1] uppercase tracking-tighter">
                          {displayName}
                        </span>

                        {active && (
                          <div
                            className="absolute -right-1 -top-1 size-2 rounded-full"
                            style={{ backgroundColor: themeColor }}
                          />
                        )}
                      </button>
                    );
                  })}
                </nav>
              </aside>

              {/* Grid de conteúdos da categoria ativa no Desktop */}
              <section className="min-w-0">
                {activeCat && currentItems.length > 0 && (
                  <div key={activeCat} className="animate-fade-in">
                    <div className="mb-2.5 flex items-baseline justify-between gap-4 md:mb-3">
                      <h2 className="font-display text-sm font-bold tracking-tight md:text-xl">
                        {currentName}
                        <span className="ml-2 text-[11px] font-semibold text-muted-foreground md:text-xs">
                          {currentItems.length} {kind === "movie" ? "filmes" : "séries"}
                        </span>
                      </h2>
                    </div>

                    <ContentRail
                      id={`cat-${activeCat}`}
                      items={currentItems}
                      layout="grid"
                      kind={kind}
                    />
                  </div>
                )}
              </section>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
