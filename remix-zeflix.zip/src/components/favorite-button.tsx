import { useCallback } from "react";
import { Heart } from "lucide-react";
import { useFavorites } from "@/hooks/use-library";
import { toggleFavorite, type FavoriteEntry, type MediaKind } from "@/lib/library";
import { cn } from "@/lib/utils";

export interface FavoriteButtonProps {
  entry: Omit<FavoriteEntry, "addedAt">;
  className?: string;
  /** Compact icon-only (default) vs labelled. */
  variant?: "icon" | "labelled";
}

/**
 * Toggles a tile's favorite state. Self-contained: reads the live favorites
 * list from the library hook so the UI updates everywhere on click.
 */
export function FavoriteButton({ entry, className, variant = "icon" }: FavoriteButtonProps) {
  const favorites = useFavorites();
  const active = favorites.some((f) => f.key === entry.key);

  const handleClick = useCallback(
    (event: React.MouseEvent) => {
      // Stop the parent <Link> from navigating when the heart is clicked.
      event.preventDefault();
      event.stopPropagation();
      toggleFavorite(entry);
    },
    [entry],
  );

  if (variant === "labelled") {
    return (
      <button
        type="button"
        onClick={handleClick}
        aria-pressed={active}
        className={cn(
          "inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-2 text-sm font-semibold backdrop-blur-md transition-colors",
          active
            ? "border-primary/60 bg-primary/15 text-primary"
            : "text-foreground hover:border-primary/40 hover:text-primary",
          className,
        )}
      >
        <Heart className={cn("size-4", active && "fill-current")} aria-hidden />
        {active ? "Favorited" : "Add to favorites"}
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={
        active ? `Remove ${entry.title} from favorites` : `Add ${entry.title} to favorites`
      }
      aria-pressed={active}
      className={cn(
        "grid size-9 place-items-center rounded-full border border-border/60 bg-background/70 text-foreground backdrop-blur-md transition-all",
        "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100",
        active && "border-primary/60 bg-primary/20 text-primary opacity-100",
        className,
      )}
    >
      <Heart className={cn("size-4", active && "fill-current")} aria-hidden />
    </button>
  );
}

/** Convenience: build a FavoriteEntry payload from rail-friendly fields. */
export function favoriteEntryFor(input: {
  kind: MediaKind;
  id: number;
  episodeId?: number;
  title: string;
  image?: string;
  href: string;
}): Omit<FavoriteEntry, "addedAt"> {
  return {
    key:
      input.episodeId != null
        ? `${input.kind}:${input.id}:e${input.episodeId}`
        : `${input.kind}:${input.id}`,
    kind: input.kind,
    id: input.id,
    episodeId: input.episodeId,
    title: input.title,
    image: input.image,
    href: input.href,
  };
}
