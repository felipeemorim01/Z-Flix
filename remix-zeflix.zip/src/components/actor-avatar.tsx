import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

/** Deterministic fallback avatar built from the actor's name (ui-avatars.com). */
export function fallbackActorAvatar(name: string): string {
  const palette = ["7c3aed", "dc2626", "0ea5e9", "059669", "d97706", "db2777"];
  const hash = Array.from(name).reduce((a, c) => a + c.charCodeAt(0), 0);
  const bg = palette[hash % palette.length];
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=${bg}&color=fff&size=160&bold=true&format=png`;
}

/**
 * Splits an Xtream `cast`/`actors` string (comma or slash separated) into a
 * clean list of unique actor names.
 */
export function parseCast(raw: string | undefined | null): string[] {
  if (!raw) return [];
  return Array.from(
    new Set(
      raw
        .split(/[,/;]+/)
        .map((n) => n.trim())
        .filter((n) => n.length > 1),
    ),
  ).slice(0, 20);
}

/**
 * Fetches a real actor photo via Wikipedia REST summary (pt → en fallback).
 * Wikipedia enables CORS, so it works client-side without any API key.
 */
async function fetchActorPhoto(name: string): Promise<string | null> {
  for (const lang of ["pt", "en"] as const) {
    try {
      const r = await fetch(
        `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(name)}?redirect=true`,
      );
      if (!r.ok) continue;
      const j = (await r.json()) as {
        thumbnail?: { source?: string };
        originalimage?: { source?: string };
      };
      const src = j.originalimage?.source ?? j.thumbnail?.source;
      if (src) return src;
    } catch {
      /* tenta próximo idioma */
    }
  }
  return null;
}

export function ActorAvatar({ name }: { name: string }) {
  const q = useQuery({
    queryKey: ["actor-photo", name],
    queryFn: () => fetchActorPhoto(name),
    staleTime: 24 * 60 * 60 * 1000,
    gcTime: 24 * 60 * 60 * 1000,
    retry: 0,
  });
  const src = q.data ?? fallbackActorAvatar(name);
  return (
    <img
      src={src}
      alt={name}
      loading="lazy"
      decoding="async"
      onError={(e) => {
        const img = e.currentTarget;
        const fb = fallbackActorAvatar(name);
        if (img.src !== fb) img.src = fb;
      }}
      className="size-full object-cover"
    />
  );
}

/** Renders a horizontal, scrollable actor rail with real photos. */
export function CastRail({
  cast,
  activeActor,
  onSelectActor,
}: {
  cast: string[];
  activeActor?: string | null;
  onSelectActor?: (name: string) => void;
}) {
  if (cast.length === 0) return null;
  return (
    <section aria-labelledby="cast-heading">
      <h2 id="cast-heading" className="mb-4 font-display text-xl font-semibold">
        Elenco
      </h2>
      <ul className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
        {cast.map((name) => (
          <li key={name} className="w-24 shrink-0 text-center">
            <button
              type="button"
              onClick={() => onSelectActor?.(name)}
              disabled={!onSelectActor}
              aria-pressed={activeActor === name}
              className={cn(
                "mx-auto block size-24 overflow-hidden rounded-full border bg-surface transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                activeActor === name
                  ? "border-primary shadow-glow"
                  : "border-border hover:border-primary/60",
                !onSelectActor && "pointer-events-none",
              )}
            >
              <ActorAvatar name={name} />
            </button>
            <p className="mt-2 line-clamp-2 text-xs font-medium text-muted-foreground">{name}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
