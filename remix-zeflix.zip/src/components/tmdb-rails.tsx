import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ContentRail } from "@/components/content-rail";
import { useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { matchTmdbListToRailItems } from "@/lib/catalog-match";
import { getTmdbTrending, getTmdbRecommendations } from "@/lib/tmdb.functions";
import { useFavorites } from "@/hooks/use-library";

/**
 * Rails da home alimentadas pelo TMDB. Sem chave definida, os fetchers
 * retornam listas vazias e nada é renderizado — as rails simplesmente
 * desaparecem, sem quebrar a página.
 */

// Referência estável para o fallback vazio, evita invalidar useMemo abaixo
// sempre que `data?.items ?? []` seria recalculado.
const EMPTY: readonly [] = [];

export function TmdbTrendingRail() {
  const credentials = useStoredCredentials();
  const catalog = useXtreamCatalog(credentials);
  const fetchTrending = useServerFn(getTmdbTrending);
  const { data } = useQuery({
    queryKey: ["tmdb", "trending"],
    queryFn: () => fetchTrending(),
    staleTime: 1000 * 60 * 60 * 24, // 24h
    gcTime: 1000 * 60 * 60 * 24 * 7,
  });

  const matched = useMemo(
    () =>
      matchTmdbListToRailItems(data?.items ?? (EMPTY as never), {
        movies: catalog.vodStreams,
        series: catalog.series,
      }),
    [data?.items, catalog.vodStreams, catalog.series],
  );

  if (data?.hasKey === false) {
    return (
      <div className="rounded-3xl border border-border/60 bg-surface px-4 py-4 text-sm text-muted-foreground">
        A seção “Em alta” exige a chave TMDB configurada no servidor. Sem ela, não há dados para
        exibir.
      </div>
    );
  }

  const movies = matched.filter((i) => i.id.startsWith("movie-")).slice(0, 10);
  const series = matched.filter((i) => i.id.startsWith("series-")).slice(0, 10);

  if (movies.length === 0 && series.length === 0) return null;

  return (
    <>
      {movies.length > 0 && (
        <ContentRail
          id="tmdb-trending-movies"
          title="Em alta — Filmes"
          kind="poster"
          items={movies}
          layout="swarm"
        />
      )}
      {series.length > 0 && (
        <ContentRail
          id="tmdb-trending-series"
          title="Em alta — Séries"
          kind="poster"
          items={series}
          layout="swarm"
        />
      )}
    </>
  );
}

export function TmdbRecommendationsRail() {
  const credentials = useStoredCredentials();
  const catalog = useXtreamCatalog(credentials);
  const favorites = useFavorites();
  const fetchRecs = useServerFn(getTmdbRecommendations);

  // Usa APENAS o favorito mais recente como semente. Agregar vários favoritos
  // fazia a lista ficar praticamente idêntica a cada novo favorito, e o rótulo
  // ("porque você curtiu X") não correspondia aos itens exibidos.
  const seeds = useMemo(() => {
    const latest = favorites
      .filter((f) => f.kind === "movie" || f.kind === "series")
      .slice()
      .sort((a, b) => b.addedAt - a.addedAt)[0];
    if (!latest) return [];
    return [
      {
        title: latest.title,
        kind: latest.kind === "series" ? ("tv" as const) : ("movie" as const),
      },
    ];
  }, [favorites]);

  const seedsKey = seeds.map((s) => `${s.kind}:${s.title}`).join("|");

  const { data } = useQuery({
    queryKey: ["tmdb", "recommendations", seedsKey],
    queryFn: () => fetchRecs({ data: { seeds } }),
    enabled: seeds.length > 0,
    staleTime: 1000 * 60 * 60 * 24,
    gcTime: 1000 * 60 * 60 * 24 * 7,
  });

  const items = useMemo(
    () =>
      matchTmdbListToRailItems(data?.items ?? (EMPTY as never), {
        movies: catalog.vodStreams,
        series: catalog.series,
      }).slice(0, 10),
    [data?.items, catalog.vodStreams, catalog.series],
  );
  if (items.length === 0) return null;
  const title = data?.seedTitle
    ? `Porque você curtiu "${data.seedTitle}"`
    : "Recomendados para você";
  return <ContentRail id="tmdb-recs" title={title} kind="poster" items={items} layout="swarm" />;
}
