import { useState } from "react";
import {
  Cast,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  SkipForward,
  Tv,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { useCast } from "@/hooks/use-cast";
import { cn } from "@/lib/utils";
import type { MediaKind } from "@/lib/library";

export interface CastRemoteOverlayProps {
  title: string;
  kind?: MediaKind;
  image?: string;
  isHls?: boolean;
  nextHref?: string | null;
  onNext?: (() => void) | null;
  onExit?: () => void;
}

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

export function CastRemoteOverlay({
  title,
  kind,
  image,
  isHls,
  nextHref,
  onNext,
  onExit,
}: CastRemoteOverlayProps) {
  const cast = useCast();
  const [seekingValue, setSeekingValue] = useState<number | null>(null);

  const isLive = isHls || kind === "live";
  const duration = cast.duration || 0;
  const currentTime = seekingValue !== null ? seekingValue : cast.currentTime || 0;
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isPlaying = cast.playerState === "PLAYING";
  const isBuffering = cast.playerState === "BUFFERING";

  const handleSeekCommit = (time: number) => {
    setSeekingValue(null);
    cast.seekTo(time);
  };

  const handleStep = (seconds: number) => {
    if (isLive || !duration) return;
    const target = Math.max(0, Math.min(duration, (cast.currentTime || 0) + seconds));
    cast.seekTo(target);
  };

  return (
    <div
      className="relative flex min-h-screen size-full flex-col justify-between overflow-y-auto bg-background/95 p-4 text-foreground backdrop-blur-2xl md:p-10"
      role="region"
      aria-label="Controle Remoto de Transmissão"
    >
      {/* Background artwork blur */}
      {image && (
        <div
          className="pointer-events-none absolute inset-0 -z-10 opacity-25 blur-3xl"
          style={{
            backgroundImage: `url(${image})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
      )}

      {/* Top bar */}
      <header className="flex items-center justify-between gap-3 border-b border-border/40 pb-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <div className="relative flex size-9 shrink-0 items-center justify-center rounded-xl border border-primary/40 bg-primary/20 text-primary shadow-sm shadow-primary/20">
            <Tv className="size-4" />
            <span className="absolute -right-0.5 -top-0.5 flex size-2.5">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex size-2.5 rounded-full bg-primary" />
            </span>
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              Transmitindo para
            </p>
            <h2 className="truncate font-display text-sm font-bold text-foreground md:text-base">
              {cast.deviceName || "Smart TV / Mi TV Stick"}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => cast.endSession(true)}
            className="flex items-center gap-1 rounded-full border border-border/60 bg-surface/60 px-3 py-1.5 text-xs font-semibold text-muted-foreground transition hover:border-destructive/60 hover:bg-destructive/10 hover:text-destructive active:scale-95"
            title="Desconectar da TV"
          >
            <Cast className="size-3.5" />
            <span className="hidden sm:inline">Desconectar</span>
          </button>

          {onExit && (
            <button
              type="button"
              onClick={onExit}
              className="flex size-8 items-center justify-center rounded-full border border-border/60 bg-surface/60 text-muted-foreground transition hover:bg-surface hover:text-foreground active:scale-95 md:size-9"
              title="Voltar ao catálogo"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
      </header>

      {/* Central content info & Poster */}
      <main className="my-auto flex flex-col items-center justify-center py-4 text-center">
        {image && (
          <div className="relative mb-4 aspect-video w-full max-w-[240px] overflow-hidden rounded-2xl border border-border/60 shadow-2xl sm:max-w-[280px] md:max-w-[340px]">
            <img
              src={image}
              alt={title}
              className="size-full object-cover"
              referrerPolicy="no-referrer"
            />
            {isBuffering && (
              <div className="absolute inset-0 grid place-items-center bg-black/60 backdrop-blur-xs">
                <div className="flex items-center gap-2 rounded-full bg-background/80 px-3.5 py-1 text-xs font-semibold text-primary">
                  <span className="size-2 animate-ping rounded-full bg-primary" />
                  Carregando na TV…
                </div>
              </div>
            )}
          </div>
        )}

        <div className="max-w-md px-2">
          {kind && (
            <span className="inline-block rounded-full bg-primary/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-primary md:text-xs">
              {kind === "live" ? "Canal ao Vivo" : kind === "series" ? "Série" : "Filme"}
            </span>
          )}
          <h1 className="mt-1.5 font-display text-lg font-bold tracking-tight text-foreground sm:text-xl md:text-3xl">
            {title}
          </h1>
          <p className="mt-1 text-[11px] text-muted-foreground md:text-xs">
            {isBuffering
              ? "Sincronizando stream com a TV…"
              : isPlaying
                ? "Reproduzindo direto na TV"
                : "Pausado na Smart TV"}
          </p>
        </div>
      </main>

      {/* Bottom controls remote dock */}
      <footer className="mx-auto w-full max-w-xl rounded-2xl border border-border/60 bg-surface/85 p-3.5 shadow-xl backdrop-blur-md md:p-6">
        {/* Progress & Scrubbing (only for non-live) */}
        {!isLive && duration > 0 && (
          <div className="mb-3">
            <div className="relative flex items-center py-1">
              <input
                type="range"
                min={0}
                max={duration}
                step={1}
                value={currentTime}
                onChange={(e) => setSeekingValue(Number(e.target.value))}
                onMouseUp={() => handleSeekCommit(currentTime)}
                onTouchEnd={() => handleSeekCommit(currentTime)}
                className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-white/10 accent-primary focus:outline-none"
              />
            </div>
            <div className="mt-1 flex justify-between text-[11px] font-semibold tabular-nums text-muted-foreground md:text-xs">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
        )}

        {/* Action buttons with handheld ergonomics */}
        <div className="flex flex-col gap-3">
          {/* Main playback control cluster */}
          <div className="flex items-center justify-center gap-4 sm:gap-6">
            {!isLive && (
              <button
                type="button"
                onClick={() => handleStep(-10)}
                className="flex size-11 items-center justify-center rounded-2xl border border-border/40 bg-background/80 text-foreground shadow-sm transition hover:scale-105 hover:border-primary active:scale-95 sm:size-12"
                title="Voltar 10 segundos"
              >
                <RotateCcw className="size-4 sm:size-5" />
              </button>
            )}

            <button
              type="button"
              onClick={() => cast.togglePlayPause()}
              className="flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30 transition hover:scale-105 active:scale-95 sm:size-16"
              title={isPlaying ? "Pausar" : "Reproduzir"}
            >
              {isPlaying ? (
                <Pause className="size-6 fill-current sm:size-7" />
              ) : (
                <Play className="ml-0.5 size-6 fill-current sm:size-7" />
              )}
            </button>

            {!isLive && (
              <button
                type="button"
                onClick={() => handleStep(10)}
                className="flex size-11 items-center justify-center rounded-2xl border border-border/40 bg-background/80 text-foreground shadow-sm transition hover:scale-105 hover:border-primary active:scale-95 sm:size-12"
                title="Avançar 10 segundos"
              >
                <RotateCw className="size-4 sm:size-5" />
              </button>
            )}
          </div>

          {/* Secondary bar: Volume & Next Episode */}
          <div className="flex items-center justify-between gap-3 border-t border-border/40 pt-2.5">
            {/* Volume controls */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => cast.setVolume(cast.isMuted ? 0.8 : 0)}
                className="flex size-8 items-center justify-center rounded-xl bg-background/60 text-muted-foreground transition hover:text-foreground active:scale-95"
                title={cast.isMuted ? "Ativar áudio" : "Mutar"}
              >
                {cast.isMuted || cast.volume === 0 ? (
                  <VolumeX className="size-4 text-destructive" />
                ) : (
                  <Volume2 className="size-4" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={cast.isMuted ? 0 : cast.volume}
                onChange={(e) => cast.setVolume(Number(e.target.value))}
                className="h-1.5 w-16 cursor-pointer appearance-none rounded-full bg-white/15 accent-primary sm:w-24 md:w-28"
              />
            </div>

            {/* Next Episode button */}
            {(nextHref || onNext) && (
              <button
                type="button"
                onClick={() => {
                  if (onNext) onNext();
                  else if (nextHref && typeof window !== "undefined") {
                    window.location.href = nextHref;
                  }
                }}
                className="flex items-center gap-1.5 rounded-xl border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary shadow-sm transition hover:bg-primary hover:text-primary-foreground active:scale-95"
              >
                <SkipForward className="size-3.5" />
                <span>Próximo</span>
              </button>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
