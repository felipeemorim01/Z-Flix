import { memo } from "react";
import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { PosterFallback } from "@/components/poster-fallback";
import type { MediaKind } from "@/lib/library";

export interface RailItem {
  id: string;
  title: string;
  /** Already proxied through /api/public/proxy when possible. */
  image?: string;
  /** Internal navigation target, e.g. /watch/live/123. */
  href?: string;
  /**
   * Alternative to href: renders the card as a button that runs this
   * handler on click. Useful for the home's "Continuar assistindo" rail,
   * which opens the inline player without navigating away.
   */
  onSelect?: () => void;
  /** Optional progress 0-1 for live-card variant. */
  progress?: number;
  /** Optional secondary label such as year, season, or source. */
  meta?: string;
  /** TMDB approval/vote average, from 0 to 10. */
  vote?: number;
  /** Data needed to favorite this tile. Omit to hide the heart. */
  favorite?: {
    kind: MediaKind;
    contentId: number;
    episodeId?: number;
  };
  /** When set, renders a "mark as watched" overlay that calls this. */
  onMarkWatched?: () => void;
}

export interface ContentRailProps {
  id: string;
  title: string;
  kind: "live" | "poster";
  items: RailItem[];
  /** Optional label rendered when items.length === 0. */
  emptyLabel?: string;
  /** Internal link to a "see all" page for this rail. */
  seeAllHref?: string;
  /**
   * `grid` (default) — grade responsiva.
   * `row` — carrossel horizontal com scroll-snap (leve, sem JS).
   * `swarm` — grade densa multi-linhas (usa cards menores).
   */
  layout?: "grid" | "row" | "swarm";
}

/**
 * Rail de conteúdos. Layout `row` renderiza um carrossel puro CSS com
 * scroll-snap — sem observer de cursor, sem transformações em tempo real.
 * Layout `swarm` mantém o nome mas agora é uma grade densa (várias linhas
 * de cards pequenos) sem efeito de mouse.
 */
export function ContentRail({
  id,
  title,
  kind,
  items,
  emptyLabel,
  seeAllHref,
  layout = "grid",
}: ContentRailProps) {
  // Largura dos slots alinhada à grade da página Pride (grid de 5/6 colunas em
  // telas grandes), para que o cartaz tenha o MESMO tamanho em todas as páginas.
  const slotClass =
    layout === "row"
      ? kind === "live"
        ? "shrink-0 snap-start w-[48%] sm:w-[32%] md:w-[24%] lg:w-[23%] xl:w-[19%]"
        : "shrink-0 snap-start w-[31%] sm:w-[28%] md:w-[23%] lg:w-[19%] xl:w-[16%]"
      : "";

  return (
    <section
      aria-labelledby={`rail-${id}`}
      className="space-y-2 md:space-y-3"
      style={{ contentVisibility: "auto", containIntrinsicSize: "auto 260px" }}
    >
      {title ? (
        <div className="flex items-center justify-between gap-4">
          <h3
            id={`rail-${id}`}
            className="flex items-center gap-2 font-display text-xs font-semibold uppercase tracking-[0.18em] text-foreground/85 md:text-sm md:font-medium"
          >
            {kind === "live" && (
              <span aria-hidden className="size-1.5 animate-pulse rounded-full bg-primary" />
            )}
            {title}
          </h3>
          {seeAllHref && (
            <Link
              to={seeAllHref}
              className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
            >
              Ver tudo
            </Link>
          )}
        </div>
      ) : null}

      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground">{emptyLabel ?? "Nothing here yet."}</p>
      ) : layout === "row" ? (
        <div
          className={cn(
            "flex snap-x snap-mandatory gap-2.5 overflow-x-auto pb-2 no-scrollbar md:gap-3",
            "[scroll-padding-inline:0.75rem] md:[scroll-padding-inline:1rem]",
          )}
        >
          {items.map((item) => (
            <div key={item.id} className={slotClass}>
              {kind === "live" ? <LiveCard item={item} /> : <PosterCard item={item} />}
            </div>
          ))}
        </div>
      ) : layout === "swarm" ? (
        <div
          className={cn(
            "grid gap-2.5 sm:gap-3 md:gap-4",
            kind === "live"
              ? "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5"
              : "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6",
          )}
        >
          {items.map((item) =>
            kind === "live" ? (
              <LiveCard key={item.id} item={item} />
            ) : (
              <PosterCard key={item.id} item={item} />
            ),
          )}
        </div>
      ) : (
        <div
          className={cn(
            "grid gap-2.5 sm:gap-4 md:gap-6",
            kind === "live"
              ? "grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5"
              : "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6",
          )}
        >
          {items.map((item) =>
            kind === "live" ? (
              <LiveCard key={item.id} item={item} />
            ) : (
              <PosterCard key={item.id} item={item} />
            ),
          )}
        </div>
      )}
    </section>
  );
}

function CardLink({
  href,
  onSelect,
  ariaLabel,
  children,
}: {
  href?: string;
  onSelect?: () => void;
  ariaLabel: string;
  children: React.ReactNode;
}) {
  const className = "group relative block text-left focus:outline-none";
  if (onSelect) {
    return (
      <button
        type="button"
        onClick={onSelect}
        aria-label={ariaLabel}
        className={cn(className, "w-full")}
      >
        {children}
      </button>
    );
  }
  if (href) {
    return (
      <Link to={href} aria-label={ariaLabel} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <div aria-label={ariaLabel} className={className}>
      {children}
    </div>
  );
}

function MarkWatchedOverlay({ item }: { item: RailItem }) {
  if (!item.onMarkWatched) return null;
  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        item.onMarkWatched?.();
      }}
      aria-label={`Marcar "${item.title}" como assistido`}
      title="Marcar como assistido"
      className="absolute left-1.5 top-1.5 z-10 grid size-7 place-items-center rounded-full border border-white/15 bg-black/55 text-white/80 opacity-0 backdrop-blur-sm transition-all hover:bg-primary hover:text-primary-foreground hover:opacity-100 focus-visible:opacity-100 group-hover:opacity-100 group-focus-visible:opacity-100"
    >
      <Check className="size-3.5" aria-hidden />
    </button>
  );
}

const LiveCard = memo(function LiveCard({ item }: { item: RailItem }) {
  const progress = item.progress ?? 0;
  return (
    <CardLink href={item.href} onSelect={item.onSelect} ariaLabel={`Watch ${item.title}`}>
      <MarkWatchedOverlay item={item} />
      <div
        className={cn(
          "cv-card relative aspect-video w-full overflow-hidden rounded-md border border-border/60 bg-surface",
          "transition-all duration-300 group-hover:border-primary/50",
          "group-focus-visible:border-primary/50",
        )}
      >
        {item.image ? (
          <img
            src={item.image}
            alt=""
            loading="lazy"
            decoding="async"
            fetchPriority="low"
            className="absolute inset-0 size-full object-contain p-3"
          />
        ) : (
          <PosterFallback title={item.title} variant="live" />
        )}
      </div>
      <p className="mt-2 truncate text-xs font-medium text-foreground/90">{item.title}</p>
      {progress > 0 && (
        <div className="mt-1.5 h-0.5 w-full overflow-hidden rounded-full bg-border">
          <div className="h-full bg-primary" style={{ width: `${Math.round(progress * 100)}%` }} />
        </div>
      )}
    </CardLink>
  );
});

const PosterCard = memo(function PosterCard({ item }: { item: RailItem }) {
  // O hook useActiveProfile será usado dinamicamente se necessário,
  // mas para manter a performance e evitar imports cíclicos em componentes puros,
  // usaremos uma abordagem baseada em CSS variables se possível ou passaremos via props.
  // Por enquanto, manteremos o padrão de cor primária para hover.

  const progress = item.progress ?? 0;
  const approval =
    typeof item.vote === "number" && item.vote > 0 ? Math.round(item.vote * 10) : null;
  return (
    <CardLink href={item.href} onSelect={item.onSelect} ariaLabel={`Open ${item.title}`}>
      <MarkWatchedOverlay item={item} />
      <div
        className={cn(
          "cv-poster relative aspect-[2/3] w-full overflow-hidden rounded-md border border-border/60 bg-surface",
          "transition-all duration-300 group-hover:border-primary/50 group-focus-visible:border-primary/50",
        )}
      >
        {item.image ? (
          <img
            src={item.image}
            alt=""
            loading="lazy"
            decoding="async"
            fetchPriority="low"
            className="absolute inset-0 size-full object-cover"
          />
        ) : (
          <PosterFallback title={item.title} />
        )}
        {progress > 0 && (
          <div className="absolute inset-x-0 bottom-0 h-0.5 bg-black/40">
            <div
              className="h-full bg-primary"
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </div>
        )}
        {approval !== null && (
          <div className="absolute right-1.5 top-1.5 rounded-full bg-black/70 px-1.5 py-0.5 text-[9px] font-semibold tabular-nums text-white/90 backdrop-blur-sm">
            {approval}
          </div>
        )}
      </div>
      <p className="mt-1.5 truncate text-[11px] font-medium text-foreground/85 transition-colors group-hover:text-foreground md:mt-2 md:text-xs">
        {item.title}
      </p>
      {item.meta && (
        <p className="truncate text-[9px] font-medium tabular-nums text-muted-foreground/70 md:text-[10px]">
          {item.meta}
        </p>
      )}
    </CardLink>
  );
});
