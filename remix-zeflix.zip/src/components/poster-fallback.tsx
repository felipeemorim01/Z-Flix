import { useMemo } from "react";
import { cn } from "@/lib/utils";

/**
 * Capa padrão para itens sem imagem. Gera um gradiente sutil determinístico
 * (baseado no título) e centraliza o nome. Mantém o mesmo aspect-ratio do
 * card pai — o consumidor apenas garante o container.
 */
export function PosterFallback({
  title,
  variant = "poster",
  className,
}: {
  title: string;
  variant?: "poster" | "live";
  className?: string;
}) {
  const { hue, initials } = useMemo(() => {
    const h = Array.from(title).reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
    const words = title.trim().split(/\s+/).filter(Boolean);
    const ini = (words[0]?.[0] ?? "?") + (words[1]?.[0] ?? "");
    return { hue: h, initials: ini.toUpperCase().slice(0, 2) };
  }, [title]);

  return (
    <div
      aria-hidden
      className={cn(
        "absolute inset-0 flex flex-col items-center justify-center overflow-hidden",
        className,
      )}
      style={{
        background: `linear-gradient(145deg,
          oklch(0.22 0.04 ${hue}) 0%,
          oklch(0.14 0.02 ${hue}) 60%,
          oklch(0.11 0 0) 100%)`,
      }}
    >
      <span
        className={cn(
          "font-display font-black tracking-tight text-foreground/70",
          variant === "live" ? "text-4xl" : "text-5xl",
        )}
      >
        {initials}
      </span>
      <span className="mt-2 line-clamp-2 px-3 text-center text-[11px] font-medium uppercase tracking-widest text-muted-foreground/70">
        {title}
      </span>
    </div>
  );
}
