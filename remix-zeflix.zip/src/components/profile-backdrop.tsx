import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { getActiveProfile, subscribeProfiles } from "@/lib/profile";

export interface ProfileBackdropProps {
  className?: string;
}

/**
 * Fundo esmaecido com a foto do perfil ativo.
 *
 * Usado apenas nas abas padrão do menu (home, pesquisar, catálogos, etc.).
 * Páginas de conteúdo (filme/série/player) têm o próprio fundo e NÃO devem
 * renderizar este componente.
 *
 * Renderização defensiva: sem perfil ativo ou sem avatar, nada é pintado.
 */
export function ProfileBackdrop({ className }: ProfileBackdropProps) {
  const [avatar, setAvatar] = useState<string | null>(null);

  useEffect(() => {
    const sync = (): void => {
      setAvatar(getActiveProfile()?.avatar ?? null);
    };
    sync();
    return subscribeProfiles(sync);
  }, []);

  if (!avatar) return null;

  return (
    <div
      aria-hidden="true"
      className={cn(
        "pointer-events-none fixed inset-0 -z-10 overflow-hidden select-none",
        className,
      )}
    >
      <img
        src={avatar}
        alt=""
        loading="lazy"
        decoding="async"
        className="h-full w-full scale-110 object-cover opacity-[0.15] blur-3xl saturate-150"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
    </div>
  );
}
