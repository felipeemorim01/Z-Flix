import { Link, useRouterState } from "@tanstack/react-router";
import { Cast, Clapperboard, Film, Heart, Home, Search, Sparkles, Tv } from "lucide-react";
import { useCast } from "@/hooks/use-cast";
import { cn } from "@/lib/utils";

const MOBILE_NAV_ITEMS = [
  { to: "/browse", label: "Início", icon: Home },
  { to: "/recommendations", label: "Para Você", icon: Sparkles },
  { to: "/search", label: "Buscar", icon: Search },
  { to: "/movies", label: "Filmes", icon: Film },
  { to: "/series", label: "Séries", icon: Clapperboard },
  { to: "/tv", label: "TV", icon: Tv },
  { to: "/favorites", label: "Favoritos", icon: Heart },
] as const;

export function MobileRemoteDock() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const cast = useCast();

  // If in active fullscreen watch route, the player itself handles the remote view
  const isWatchPage = pathname.startsWith("/watch/");
  if (isWatchPage) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 block md:hidden">
      {/* Mini Cast Remote Bar if connected to Mi TV Stick / Chromecast */}
      {cast.isConnected && (
        <div className="mx-2 mb-2 flex items-center justify-between gap-3 rounded-2xl border border-primary/40 bg-surface/95 p-3 shadow-2xl backdrop-blur-xl">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="relative flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
              <Tv className="size-4" />
              <span className="absolute -right-0.5 -top-0.5 flex size-2.5">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary-foreground opacity-75" />
                <span className="relative inline-flex size-2.5 rounded-full bg-primary-foreground" />
              </span>
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-primary">
                Conectado na TV
              </p>
              <p className="truncate text-xs font-semibold text-foreground">
                {cast.deviceName || "Mi TV Stick / Smart TV"}
              </p>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-1.5">
            <button
              type="button"
              onClick={() => cast.togglePlayPause()}
              className="flex size-9 items-center justify-center rounded-xl bg-primary/20 text-primary transition active:scale-95"
              title="Play / Pause na TV"
            >
              <span className="text-xs font-bold">
                {cast.playerState === "PLAYING" ? "Pausar" : "Play"}
              </span>
            </button>
            <button
              type="button"
              onClick={() => cast.endSession(true)}
              className="flex size-9 items-center justify-center rounded-xl border border-border/60 bg-background/60 text-muted-foreground transition hover:text-destructive active:scale-95"
              title="Desconectar da TV"
            >
              <Cast className="size-4 text-destructive" />
            </button>
          </div>
        </div>
      )}

      {/* Main bottom navigation bar */}
      <nav
        aria-label="Navegação Principal"
        className="flex items-center justify-around border-t border-border/60 bg-background/95 px-2 py-2 shadow-2xl backdrop-blur-2xl"
      >
        {MOBILE_NAV_ITEMS.map((item) => {
          const active = pathname === item.to;
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-w-[48px] flex-col items-center justify-center gap-1 rounded-xl px-1.5 py-1 text-[11px] font-semibold transition-all active:scale-95",
                active ? "text-primary" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <div
                className={cn(
                  "flex size-8 items-center justify-center rounded-xl transition-all",
                  active
                    ? "bg-primary/20 text-primary shadow-sm shadow-primary/20"
                    : "bg-transparent text-muted-foreground",
                )}
              >
                <Icon className="size-4" aria-hidden />
              </div>
              <span className="truncate leading-none">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
