import { Link, useNavigate, useRouter, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Heart,
  Search,
  Film,
  Tv,
  Clapperboard,
  Users,
  Sparkles,
  Cast,
  RefreshCw,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { resetCredentialsCache } from "@/lib/credentials";
import { resetLibraryCache } from "@/lib/library";
import { getActiveProfile, setActiveProfile } from "@/lib/profile";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useCast } from "@/hooks/use-cast";
import { useXtreamRefresh } from "@/hooks/use-xtream";

const NAV_LINKS = [
  { to: "/recommendations", label: "Para Você", icon: Sparkles },
  { to: "/search", label: "Pesquisar", icon: Search },
  { to: "/favorites", label: "Favoritos", icon: Heart },
  { to: "/movies", label: "Filmes", icon: Film },
  { to: "/series", label: "Séries", icon: Clapperboard },
  { to: "/tv", label: "TV", icon: Tv },
  { to: "/pride", label: "Pride", icon: Heart },
] as const;

export interface SiteNavProps {
  className?: string;
  showNavLinks?: boolean;
}

export function SiteNav({ className, showNavLinks = true }: SiteNavProps) {
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();
  const cast = useCast();
  const { isRefreshing, refresh } = useXtreamRefresh();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [profileName, setProfileName] = useState<string | null>(null);
  const [profileAvatar, setProfileAvatar] = useState<string | null>(null);
  const [profileColor, setProfileColor] = useState<string | null>(null);
  const homeLinkRef = useRef<HTMLAnchorElement | null>(null);

  // Pré-carrega rotas principais em idle: navegação vira quase instantânea.
  useEffect(() => {
    const idle =
      (window as unknown as { requestIdleCallback?: (cb: () => void) => number })
        .requestIdleCallback ?? ((cb: () => void) => window.setTimeout(cb, 200));
    idle(() => {
      for (const to of [
        "/recommendations",
        "/search",
        "/favorites",
        "/movies",
        "/series",
        "/tv",
        "/pride",
      ] as const) {
        void router.preloadRoute({ to }).catch(() => {});
      }
    });
  }, [router]);

  useEffect(() => {
    if (pathname !== "/browse" || !homeLinkRef.current) return;
    const active = document.activeElement as HTMLElement | null;
    if (!active || active === document.body || active === document.documentElement) {
      homeLinkRef.current.focus();
    }
    // Só no primeiro mount da rota /browse
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const active = getActiveProfile();
    setProfileName(active?.name ?? null);
    setProfileAvatar(active?.avatar ?? null);
    setProfileColor(active?.color ?? null);
  }, [pathname]);

  const initials = (profileName ?? "?").slice(0, 2).toUpperCase();

  /** Volta para a seleção de perfis, sem apagar os perfis salvos. */
  async function handleSwitchProfile() {
    await queryClient.cancelQueries();
    queryClient.clear();
    setActiveProfile(null);
    resetCredentialsCache();
    resetLibraryCache();
    void navigate({ to: "/", replace: true });
  }

  return (
    <header
      className={cn(
        "sticky top-0 z-40 border-b border-border/50 bg-background/80 backdrop-blur-xl",
        className,
      )}
    >
      <div className="mx-auto flex h-14 max-w-[1600px] items-center justify-between gap-3 px-3.5 md:h-20 md:px-8">
        <div className="flex items-center gap-3">
          {showNavLinks && (
            <Avatar className="size-9 rounded-2xl border border-primary/20 shadow-sm md:size-12">
              {profileAvatar ? (
                <AvatarImage src={profileAvatar} alt={profileName ?? "Perfil"} />
              ) : (
                <AvatarFallback>{initials}</AvatarFallback>
              )}
            </Avatar>
          )}
          <div className="flex flex-col">
            <Link
              to="/browse"
              ref={homeLinkRef}
              aria-label="Início — ZéFlix"
              className="inline-flex items-center gap-1 font-display text-base font-extrabold tracking-tighter text-primary md:text-xl"
            >
              <span>
                Zé<span className="text-foreground">Flix</span>
              </span>
            </Link>
            {showNavLinks && (
              <span
                className="font-display text-[10px] font-black tracking-widest uppercase md:text-sm"
                style={{ color: profileColor || "var(--primary)" }}
                data-profile-color={profileColor}
              >
                {profileName}
              </span>
            )}
          </div>
        </div>

        {showNavLinks ? (
          <nav className="hidden flex-1 items-center justify-center gap-1 md:flex">
            {NAV_LINKS.map((link) => {
              const active = pathname === link.to;
              const Icon = link.icon;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary/15 text-foreground"
                      : "text-muted-foreground hover:bg-surface hover:text-foreground",
                  )}
                >
                  <Icon className="size-4" aria-hidden />
                  {link.label}
                </Link>
              );
            })}
          </nav>
        ) : null}

        <div className="flex items-center gap-2 md:gap-3">
          {/* Quick Refresh Playlist Button */}
          {showNavLinks && (
            <button
              type="button"
              onClick={() => void refresh()}
              disabled={isRefreshing}
              aria-label={isRefreshing ? "Atualizando catálogo IPTV..." : "Atualizar catálogo IPTV"}
              title={isRefreshing ? "Atualizando catálogo..." : "Atualizar lista IPTV"}
              className={cn(
                "flex items-center justify-center rounded-2xl border p-2 text-muted-foreground transition-all hover:border-primary/40 hover:bg-surface hover:text-foreground active:scale-95 disabled:opacity-60 md:p-3",
                isRefreshing
                  ? "border-primary/60 bg-primary/20 text-primary shadow-sm shadow-primary/25"
                  : "border-border/60 bg-surface/70",
              )}
            >
              <RefreshCw
                className={cn("size-4 md:size-5", isRefreshing && "animate-spin text-primary")}
                aria-hidden
              />
            </button>
          )}

          {/* Quick Cast Connect Button */}
          {showNavLinks && (
            <button
              type="button"
              onClick={() => {
                if (cast.isConnected) {
                  cast.endSession(true);
                } else {
                  void cast.requestSession();
                }
              }}
              aria-label={
                cast.isConnected
                  ? `Conectado à TV (${cast.deviceName || "Mi TV Stick"}). Toque para desconectar.`
                  : "Conectar à Smart TV / Mi TV Stick"
              }
              title={
                cast.isConnected
                  ? `Transmitindo para ${cast.deviceName || "TV"}`
                  : "Transmitir para Smart TV / Mi TV Stick"
              }
              className={cn(
                "relative flex items-center justify-center rounded-2xl border p-2 text-xs font-semibold transition-all active:scale-95 md:p-3",
                cast.isConnected
                  ? "border-primary/60 bg-primary/20 text-primary shadow-sm shadow-primary/25"
                  : "border-border/60 bg-surface/70 text-muted-foreground hover:border-primary/40 hover:text-foreground",
              )}
            >
              <Cast className="size-4 md:size-5" aria-hidden />
              {cast.isConnected && (
                <span className="absolute -right-0.5 -top-0.5 flex size-2">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex size-2 rounded-full bg-primary" />
                </span>
              )}
            </button>
          )}

          {showNavLinks && (
            <button
              type="button"
              onClick={handleSwitchProfile}
              aria-label="Trocar perfil"
              className="flex items-center justify-center rounded-2xl border border-border/60 bg-surface/70 p-2 text-muted-foreground transition-all hover:border-primary/40 hover:bg-surface hover:text-foreground md:p-3"
            >
              <Users className="size-4 md:size-5" aria-hidden />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
