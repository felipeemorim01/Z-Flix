import { useEffect, useState } from "react";
import {
  castMedia,
  castSeekTo,
  castSetVolume,
  castTogglePlayPause,
  endCastSession,
  getCastState,
  initCastFramework,
  requestCastSession,
  subscribeCastState,
  type CastMediaPayload,
  type CastState,
} from "@/lib/cast";

export function useCast() {
  const [state, setState] = useState<CastState>(getCastState);

  useEffect(() => {
    initCastFramework();
    const unsubscribe = subscribeCastState(setState);
    return unsubscribe;
  }, []);

  return {
    ...state,
    requestSession: requestCastSession,
    endSession: endCastSession,
    castMedia: (payload: CastMediaPayload) => castMedia(payload),
    togglePlayPause: castTogglePlayPause,
    seekTo: castSeekTo,
    setVolume: castSetVolume,
  };
}
