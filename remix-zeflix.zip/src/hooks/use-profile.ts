import { useEffect, useState } from "react";
import { getActiveProfile, subscribeProfiles, type Profile } from "@/lib/profile";
import { useRouterState } from "@tanstack/react-router";

/**
 * Hook para obter o perfil ativo e escutar mudanças.
 */
export function useActiveProfile() {
  const [profile, setProfile] = useState<Profile | null>(() => getActiveProfile());
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    // Atualiza quando o perfil muda via eventos locais
    const unsubscribe = subscribeProfiles(() => {
      setProfile(getActiveProfile());
    });

    // Também atualiza na navegação (garante sincronia com SiteNav)
    setProfile(getActiveProfile());

    return unsubscribe;
  }, [pathname]);

  return profile;
}
