import { useCallback, useEffect, useState } from "react";
import { useQuery, useQueries, useQueryClient, useIsFetching } from "@tanstack/react-query";

import {
  fetchLiveCategories,
  fetchLiveStreams,
  fetchSeries,
  fetchSeriesCategories,
  fetchVodCategories,
  fetchVodStreams,
  setBustXtreamCache,
  type XtreamCategory,
  type XtreamLiveStream,
  type XtreamSeries,
  type XtreamVodStream,
} from "@/lib/xtream";
import {
  ensureCredentialsLoaded,
  getCachedCredentials,
  isCredentialsLoaded,
  subscribeCredentials,
  type XtreamCredentials,
} from "@/lib/credentials";

/**
 * Credenciais sincronizadas com a Cloud. Inicia como `null` (SSR-safe) e
 * hidrata após o mount, re-renderizando ao receber a resposta do backend.
 */
export function useStoredCredentials(): XtreamCredentials | null {
  const [value, setValue] = useState<XtreamCredentials | null>(() => getCachedCredentials());
  useEffect(() => {
    ensureCredentialsLoaded();
    setValue(getCachedCredentials());
    return subscribeCredentials(() => setValue(getCachedCredentials()));
  }, []);
  return value;
}

/**
 * Indica se o cache de credenciais já foi resolvido (consulta ao backend
 * concluída). Use para gatear redirects/renders enquanto carregamos.
 */
export function useCredentialsResolved(): boolean {
  const [resolved, setResolved] = useState<boolean>(() => isCredentialsLoaded());
  useEffect(() => {
    ensureCredentialsLoaded();
    setResolved(isCredentialsLoaded());
    return subscribeCredentials(() => setResolved(isCredentialsLoaded()));
  }, []);
  return resolved;
}

const STALE = 15 * 60 * 1000;

/**
 * Opções compartilhadas por todas as queries do catálogo Xtream:
 * - `staleTime` de 15min evita refetches enxutos no dia a dia.
 * - `refetchOnWindowFocus` / `refetchOnReconnect` garantem dados frescos
 *   quando o app volta ao foco (TV Box saindo do standby, troca de HDMI)
 *   ou quando a rede reconecta, sem custo perceptível.
 */
const CATALOG_QUERY_OPTS = {
  staleTime: STALE,
  refetchOnWindowFocus: true,
  refetchOnReconnect: true,
} as const;

export function useXtreamCatalog(creds: XtreamCredentials | null) {
  const queries = useQueries({
    queries: [
      {
        queryKey: ["xtream", "live-categories", creds?.serverUrl, creds?.username],
        queryFn: () => fetchLiveCategories(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
      {
        queryKey: ["xtream", "live-streams", creds?.serverUrl, creds?.username],
        queryFn: () => fetchLiveStreams(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
      {
        queryKey: ["xtream", "vod-categories", creds?.serverUrl, creds?.username],
        queryFn: () => fetchVodCategories(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
      {
        queryKey: ["xtream", "vod-streams", creds?.serverUrl, creds?.username],
        queryFn: () => fetchVodStreams(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
      {
        queryKey: ["xtream", "series-categories", creds?.serverUrl, creds?.username],
        queryFn: () => fetchSeriesCategories(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
      {
        queryKey: ["xtream", "series", creds?.serverUrl, creds?.username],
        queryFn: () => fetchSeries(creds!),
        enabled: !!creds,
        ...CATALOG_QUERY_OPTS,
      },
    ],
  });

  const [liveCategoriesQ, liveStreamsQ, vodCategoriesQ, vodStreamsQ, seriesCategoriesQ, seriesQ] =
    queries;

  const isLoading = queries.some((q) => q.isLoading);
  const error = queries.find((q) => q.error)?.error as Error | undefined;
  const dataUpdatedAt = queries.reduce(
    (min, q) => (q.dataUpdatedAt > 0 ? Math.min(min, q.dataUpdatedAt) : min),
    Date.now(),
  );

  // Desliga o bust global após a primeira leva de fetches completar —
  // navegações seguintes voltam ao caminho leve com cache do WebView.
  const allSettled = queries.every((q) => !q.isLoading && q.fetchStatus === "idle");
  useEffect(() => {
    if (allSettled) setBustXtreamCache(false);
  }, [allSettled]);

  return {
    isLoading,
    error,
    dataUpdatedAt,
    liveCategories: (liveCategoriesQ.data ?? []) as XtreamCategory[],
    liveStreams: (liveStreamsQ.data ?? []) as XtreamLiveStream[],
    vodCategories: (vodCategoriesQ.data ?? []) as XtreamCategory[],
    vodStreams: (vodStreamsQ.data ?? []) as XtreamVodStream[],
    seriesCategories: (seriesCategoriesQ.data ?? []) as XtreamCategory[],
    series: (seriesQ.data ?? []) as XtreamSeries[],
  };
}

/**
 * Retorna um par [isRefreshing, refresh()] que invalida todo o cache Xtream
 * — usado pelo chip "Atualizar" na home. Aciona cache-busting agressivo
 * (query string única + `cache: "no-store"`) para derrotar o HTTP cache do
 * WebView da TV Box durante essa rodada de refetch e volta ao normal em
 * seguida, preservando a leveza do carregamento cotidiano.
 */
export function useXtreamRefresh(): { isRefreshing: boolean; refresh: () => Promise<void> } {
  const qc = useQueryClient();
  const fetching = useIsFetching({ queryKey: ["xtream"] });
  const refresh = useCallback(async () => {
    setBustXtreamCache(true);
    try {
      await qc.refetchQueries({ queryKey: ["xtream"], exact: false, type: "active" });
    } finally {
      setBustXtreamCache(false);
    }
  }, [qc]);
  return { isRefreshing: fetching > 0, refresh };
}

export function useXtreamConnectivity(creds: XtreamCredentials | null) {
  return useQuery({
    queryKey: ["xtream", "ping", creds?.serverUrl, creds?.username],
    queryFn: () => fetchLiveCategories(creds!),
    enabled: !!creds,
    retry: false,
    staleTime: STALE,
  });
}
