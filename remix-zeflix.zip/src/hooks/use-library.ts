import { useEffect, useState } from "react";
import {
  loadFavorites,
  loadProgress,
  subscribeLibrary,
  type FavoriteEntry,
  type ProgressEntry,
} from "@/lib/library";

/**
 * Library readers via plain useState + useEffect. Starts empty (matches SSR)
 * and hydrates on mount + on every library mutation. This sidesteps the
 * snapshot-stability requirements of useSyncExternalStore that were causing
 * "Maximum update depth exceeded" during hydration.
 */

export function useFavorites(): FavoriteEntry[] {
  const [value, setValue] = useState<FavoriteEntry[]>([]);
  useEffect(() => {
    setValue(loadFavorites());
    return subscribeLibrary(() => setValue(loadFavorites()));
  }, []);
  return value;
}

export function useProgressList(): ProgressEntry[] {
  const [value, setValue] = useState<ProgressEntry[]>([]);
  useEffect(() => {
    setValue(loadProgress());
    return subscribeLibrary(() => setValue(loadProgress()));
  }, []);
  return value;
}
