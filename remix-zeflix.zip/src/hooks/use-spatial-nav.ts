import { useEffect } from "react";
import { useRouterState } from "@tanstack/react-router";
import { initSounds, playMove, playSelect } from "@/lib/sounds";

/**
 * Spatial keyboard navigation for Android TV remotes (D-pad).
 *
 * - Arrow keys move focus to the nearest focusable element in that direction
 *   based on bounding-rect geometry (works across rails, nav, buttons).
 * - Enter / OK is handled natively by the focused element (links, buttons).
 * - Skips when the user is typing in an input/textarea/contentEditable.
 * - Auto-scrolls the new focus into view (centered).
 */

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([disabled]):not([type='hidden'])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

type Dir = "left" | "right" | "up" | "down";

function isTypingTarget(el: Element | null): boolean {
  if (!el) return false;
  const tag = el.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") {
    const t = (el as HTMLInputElement).type;
    // Text-like inputs consume arrow keys for caret movement.
    return tag !== "INPUT" || !["button", "submit", "checkbox", "radio"].includes(t);
  }
  return (el as HTMLElement).isContentEditable === true;
}

function isVisible(el: HTMLElement): boolean {
  if (el.hidden) return false;
  if (!el.isConnected) return false;
  const rect = el.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return false;
  const style = window.getComputedStyle(el);
  return style.visibility !== "hidden" && style.display !== "none";
}

function getFocusableElements(): HTMLElement[] {
  return Array.from(document.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(isVisible);
}

function isUsableFocusedElement(el: HTMLElement | null): boolean {
  return Boolean(el && el !== document.body && el !== document.documentElement && isVisible(el));
}

function findLinkByPath(pathname: string, elements: HTMLElement[]): HTMLElement | null {
  for (const el of elements) {
    if (!(el instanceof HTMLAnchorElement)) continue;
    try {
      if (new URL(el.href).pathname === pathname) return el;
    } catch {
      // href inválido não deve quebrar a navegação por controle remoto.
    }
  }
  return null;
}

function pickDefaultFocus(pathname: string): HTMLElement | null {
  const elements = getFocusableElements();
  if (elements.length === 0) return null;

  if (pathname === "/") {
    return elements.find((el) => el instanceof HTMLInputElement) ?? elements[0];
  }

  if (pathname === "/search") {
    return (
      elements.find((el) => el instanceof HTMLInputElement) ??
      findLinkByPath(pathname, elements) ??
      elements[0]
    );
  }

  if (pathname === "/browse") {
    return findLinkByPath("/browse", elements) ?? elements[0];
  }

  const routeLink = findLinkByPath(pathname, elements);
  if (routeLink) return routeLink;

  const backControl = elements.find((el) => {
    const label = `${el.getAttribute("aria-label") ?? ""} ${el.textContent ?? ""}`.toLowerCase();
    return label.includes("voltar");
  });
  if (backControl) return backControl;

  return elements[0];
}

function pickNext(current: HTMLElement, dir: Dir): HTMLElement | null {
  const all = Array.from(document.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    (el) => el !== current && isVisible(el),
  );
  if (all.length === 0) return null;

  const cur = current.getBoundingClientRect();
  const cx = cur.left + cur.width / 2;
  const tol = 8;
  const horizontal = dir === "left" || dir === "right";

  if (horizontal) {
    let best: HTMLElement | null = null;
    let bestScore = Infinity;
    for (const el of all) {
      const r = el.getBoundingClientRect();
      const ex = r.left + r.width / 2;
      const dx = ex - cx;
      const dy = r.top + r.height / 2 - (cur.top + cur.height / 2);

      let primary: number;
      if (dir === "right") {
        if (dx <= tol) continue;
        primary = dx;
      } else {
        if (dx >= -tol) continue;
        primary = -dx;
      }
      // Mesma linha: exigimos sobreposição vertical para não pular de rail.
      const overlap = Math.min(cur.bottom, r.bottom) - Math.max(cur.top, r.top);
      if (overlap < Math.min(cur.height, r.height) * 0.35) continue;
      const score = primary + Math.abs(dy) * 4;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }
    return best;
  }

  // Vertical: primeiro identificamos a "linha" mais próxima na direção do
  // movimento (menor distância vertical); depois, dentro dessa linha,
  // escolhemos o candidato com menor Δx. Isso evita saltar uma linha inteira
  // só porque um item alinhado horizontalmente existe mais longe.
  interface Cand {
    el: HTMLElement;
    primary: number;
    dx: number;
    height: number;
  }
  const cands: Cand[] = [];
  for (const el of all) {
    const r = el.getBoundingClientRect();
    const ex = r.left + r.width / 2;
    const dx = ex - cx;
    let primary: number;
    if (dir === "down") {
      if (r.top < cur.bottom - tol) continue;
      primary = r.top - cur.bottom;
    } else {
      if (r.bottom > cur.top + tol) continue;
      primary = cur.top - r.bottom;
    }
    cands.push({ el, primary, dx, height: r.height });
  }
  if (cands.length === 0) return null;

  const minPrimary = cands.reduce((m, c) => Math.min(m, c.primary), Infinity);
  // Tolerância generosa para agrupar itens da mesma "linha" mesmo com
  // pequenas variações de altura entre botões, avatares e cards.
  const rowTol = Math.max(40, cur.height * 0.6);
  const sameRow = cands.filter((c) => c.primary <= minPrimary + rowTol);
  sameRow.sort((a, b) => Math.abs(a.dx) - Math.abs(b.dx));
  return sameRow[0].el;
}

export function useSpatialNav(): void {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    initSounds();
    // Garante um ponto de foco inicial — sem isso, o D-pad da TV não tem "âncora".
    function focusFirst(options: { force?: boolean; smooth?: boolean } = {}) {
      const active = document.activeElement as HTMLElement | null;
      if (!options.force && isUsableFocusedElement(active)) return;
      const first = pickDefaultFocus(pathname);
      if (first) {
        first.focus({ preventScroll: false });
        first.scrollIntoView({
          block: "center",
          inline: "center",
          behavior: options.smooth ? "smooth" : "auto",
        });
      }
    }

    // Rotas novas, retorno do player e listas carregadas async podem derrubar o
    // foco para o body. Reancoramos em pequenos atrasos para pegar o DOM final.
    const focusTimers = [0, 80, 240, 600].map((delay) =>
      window.setTimeout(() => focusFirst({ smooth: delay > 0 }), delay),
    );

    // (Removido) MutationObserver em document.body: disparava a cada frame
    // do efeito fisheye (que muda style inline dos slots), consumindo CPU.
    // O foco perdido já é reancorado pelos handlers focusout / pageshow /
    // popstate / fullscreenchange abaixo.

    function resolveDir(event: KeyboardEvent): Dir | null {
      const km: Record<string, Dir> = {
        ArrowLeft: "left",
        ArrowRight: "right",
        ArrowUp: "up",
        ArrowDown: "down",
        Left: "left",
        Right: "right",
        Up: "up",
        Down: "down",
      };
      if (km[event.key]) return km[event.key];
      const cm: Record<number, Dir> = { 37: "left", 38: "up", 39: "right", 40: "down" };
      return cm[event.keyCode] ?? null;
    }

    // Trava anti-repetição: um clique no D-pad estava movendo 2-3 quadros
    // porque escutávamos keydown+keyup e o auto-repeat do sistema.
    let lock = false;
    let lockTimer: number | null = null;
    const pressed = new Set<string>();

    function releaseLock() {
      lock = false;
      if (lockTimer) {
        window.clearTimeout(lockTimer);
        lockTimer = null;
      }
    }

    function handleDown(event: KeyboardEvent) {
      const dir = resolveDir(event);
      if (!dir) return;

      // Bloqueia auto-repeat do SO ao segurar a tecla.
      if (event.repeat) {
        event.preventDefault();
        return;
      }
      const code = event.code || event.key;
      // Bloqueia enquanto a mesma tecla ainda não foi solta.
      if (pressed.has(code)) {
        event.preventDefault();
        return;
      }
      pressed.add(code);

      if (lock) {
        event.preventDefault();
        return;
      }
      lock = true;
      lockTimer = window.setTimeout(releaseLock, 180);

      const active = (document.activeElement as HTMLElement | null) ?? document.body;
      if (isTypingTarget(active)) {
        // Permite escapar do input com as setas: ArrowUp/Down sempre navegam;
        // ArrowLeft/Right só navegam quando o caret está na borda do texto.
        const input = active as HTMLInputElement | HTMLTextAreaElement;
        const value = typeof input.value === "string" ? input.value : "";
        const start = input.selectionStart ?? 0;
        const end = input.selectionEnd ?? 0;
        const atStart = start === 0 && end === 0;
        const atEnd = start === value.length && end === value.length;
        const canEscape =
          dir === "up" ||
          dir === "down" ||
          (dir === "left" && atStart) ||
          (dir === "right" && atEnd);
        if (!canEscape) {
          releaseLock();
          return;
        }
        input.blur();
      }

      if (active === document.body || active === document.documentElement) {
        const first = pickDefaultFocus(pathname);
        if (first) {
          event.preventDefault();
          first.focus({ preventScroll: false });
          first.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
        }
        return;
      }

      const next = pickNext(active, dir);
      if (next) {
        event.preventDefault();
        next.focus({ preventScroll: true });
        next.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
        playMove();
      } else {
        event.preventDefault();
        const dy = dir === "down" ? 240 : dir === "up" ? -240 : 0;
        const dx = dir === "right" ? 240 : dir === "left" ? -240 : 0;
        window.scrollBy({ top: dy, left: dx, behavior: "smooth" });
      }
    }

    function handleUp(event: KeyboardEvent) {
      pressed.delete(event.code || event.key);
    }

    // Feedback sonoro para "seleção" (Enter/OK do controle + clique de mouse).
    function handleSelect(event: KeyboardEvent) {
      if (event.key === "Enter" || event.key === " ") {
        const active = document.activeElement as HTMLElement | null;
        if (active && !isTypingTarget(active)) playSelect();
      }
    }
    function handleClick(event: MouseEvent) {
      const target = event.target as HTMLElement | null;
      if (!target) return;
      if (target.closest(FOCUSABLE_SELECTOR)) playSelect();
    }

    // Se por qualquer motivo o foco cair no body (clique fora, Esc, blur), reancoramos.
    function handleFocusOut() {
      window.setTimeout(() => {
        const a = document.activeElement as HTMLElement | null;
        if (!isUsableFocusedElement(a)) {
          focusFirst();
        }
      }, 0);
    }

    function handleRestoreFocus() {
      window.setTimeout(() => focusFirst({ smooth: true }), 80);
    }

    window.addEventListener("keydown", handleDown);
    window.addEventListener("keyup", handleUp);
    window.addEventListener("keydown", handleSelect);
    window.addEventListener("click", handleClick);
    window.addEventListener("focusout", handleFocusOut);
    window.addEventListener("popstate", handleRestoreFocus);
    window.addEventListener("pageshow", handleRestoreFocus);
    window.addEventListener("fullscreenchange", handleRestoreFocus);
    return () => {
      focusTimers.forEach((timer) => window.clearTimeout(timer));
      if (lockTimer) window.clearTimeout(lockTimer);
      window.removeEventListener("keydown", handleDown);
      window.removeEventListener("keyup", handleUp);
      window.removeEventListener("keydown", handleSelect);
      window.removeEventListener("click", handleClick);
      window.removeEventListener("focusout", handleFocusOut);
      window.removeEventListener("popstate", handleRestoreFocus);
      window.removeEventListener("pageshow", handleRestoreFocus);
      window.removeEventListener("fullscreenchange", handleRestoreFocus);
    };
  }, [pathname]);
}
