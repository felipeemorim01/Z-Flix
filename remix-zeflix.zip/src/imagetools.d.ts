declare module "*.jpg?format=webp&quality=72&w=1920" {
  const src: string;
  export default src;
}
declare module "*.png?format=webp&quality=72&w=1920" {
  const src: string;
  export default src;
}
