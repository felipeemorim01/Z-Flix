import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Play } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { BackButton } from "@/components/back-button";
import { FavoriteButton, favoriteEntryFor } from "@/components/favorite-button";
import { ContentRail } from "@/components/content-rail";
import { CastRail, parseCast } from "@/components/actor-avatar";
import { InlinePlayer } from "@/components/inline-player";
import { useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { buildSeriesEpisodeUrl, fetchSeriesInfo, proxiedImage } from "@/lib/xtream";
import { matchTmdbListToRailItems } from "@/lib/catalog-match";
import { getTmdbPersonCredits, getTmdbRecommendations } from "@/lib/tmdb.functions";
import { favoriteKey, getProgress, isWatched, loadProgress, subscribeLibrary } from "@/lib/library";

import { cn } from "@/lib/utils";

export const Route = createFileRoute("/series/$id")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Série" },
      {
        name: "description",
        content: "Detalhes da série, temporadas, elenco e séries relacionadas.",
      },
    ],
  }),
  component: SeriesPage,
});

/**
 * Subscribes to the shared library store so components re-render when
 * progress/favorites change (e.g. after finishing an episode).
 */
function useLibraryTick(): void {
  useSyncExternalStore(
    subscribeLibrary,
    () => loadProgress().length + loadProgress().reduce((a, p) => a + p.updatedAt, 0),
    () => 0,
  );
}

function SeriesPage() {
  const { id } = Route.useParams();
  const credentials = useStoredCredentials();
  const navigate = useNavigate();
  const seriesId = Number.parseInt(id, 10);
  const [activeActor, setActiveActor] = useState<string | null>(null);
  const fetchRecs = useServerFn(getTmdbRecommendations);
  const fetchPersonCredits = useServerFn(getTmdbPersonCredits);
  useLibraryTick();

  useEffect(() => {
    if (!credentials) void navigate({ to: "/", replace: true });
  }, [credentials, navigate]);

  const { data, isLoading, error } = useQuery({
    queryKey: ["xtream", "series-info", seriesId],
    queryFn: () => fetchSeriesInfo(credentials!, seriesId),
    enabled: !!credentials && !Number.isNaN(seriesId),
    staleTime: 5 * 60 * 1000,
  });

  const catalog = useXtreamCatalog(credentials);

  const seasons = useMemo(() => {
    const map = data?.episodes ?? {};
    return Object.keys(map)
      .map((k) => Number.parseInt(k, 10))
      .filter((n) => !Number.isNaN(n))
      .sort((a, b) => a - b);
  }, [data]);

  // Temporadas começam RECOLHIDAS: só mostra episódios após o clique.
  // Por padrão, focamos a primeira temporada.
  const [activeSeason, setActiveSeason] = useState<number | null>(null);

  useEffect(() => {
    if (seasons.length > 0) {
      const firstSeasonBtn = document.getElementById(`season-btn-${seasons[0]}`);
      if (firstSeasonBtn) firstSeasonBtn.focus();
    }
  }, [seasons]);

  const episodes = activeSeason != null ? (data?.episodes?.[String(activeSeason)] ?? []) : [];

  // Estado do player inline (overlay em tela cheia sobre esta página).
  const [playingEp, setPlayingEp] = useState<{
    epId: number;
    epNum: number;
    season: number;
    title: string;
    image?: string;
    ext: string;
  } | null>(null);

  const cover = proxiedImage(data?.info?.cover) ?? proxiedImage(data?.seasons?.[0]?.cover_big);
  const title = data?.info?.name ?? `Série #${seriesId}`;
  const cast = useMemo(() => parseCast(data?.info?.cast), [data]);

  const tmdbRelated = useQuery({
    queryKey: ["tmdb", "series-related", title],
    queryFn: () => fetchRecs({ data: { seeds: [{ title, kind: "tv" }] } }),
    enabled: !!title && title !== `Série #${seriesId}`,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 6,
  });

  const relatedItems = useMemo(
    () =>
      matchTmdbListToRailItems(tmdbRelated.data?.items ?? [], {
        movies: catalog.vodStreams,
        series: catalog.series,
      })
        .filter((item) => item.id !== `series-${seriesId}`)
        .slice(0, 18),
    [tmdbRelated.data?.items, catalog.vodStreams, catalog.series, seriesId],
  );

  const actorCredits = useQuery({
    queryKey: ["tmdb", "actor-credits", activeActor],
    queryFn: () => fetchPersonCredits({ data: { name: activeActor ?? "" } }),
    enabled: !!activeActor,
    staleTime: 1000 * 60 * 60 * 24,
    gcTime: 1000 * 60 * 60 * 24,
  });

  const actorItems = useMemo(
    () =>
      matchTmdbListToRailItems(actorCredits.data?.items ?? [], {
        movies: catalog.vodStreams,
        series: catalog.series,
      })
        .filter((item) => item.id !== `series-${seriesId}`)
        .slice(0, 18),
    [actorCredits.data?.items, catalog.vodStreams, catalog.series, seriesId],
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteNav />
      <main className="pb-24">
        {/* Hero */}
        <section className="relative">
          {cover ? (
            <div className="fixed inset-0 -z-10 overflow-hidden">
              <img
                src={cover}
                alt=""
                className="size-full object-cover opacity-20 blur-2xl scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/20" />
            </div>
          ) : null}
          <div className="mx-auto max-w-6xl px-6 pt-8 md:px-12">
            <BackButton fallback="/series" label="Voltar ao catálogo" />
          </div>
          <div className="mx-auto grid max-w-6xl gap-8 px-6 py-12 md:grid-cols-[220px_1fr] md:px-12">
            <div className="aspect-[2/3] w-full max-w-[220px] overflow-hidden rounded-xl border border-border bg-surface">
              {cover ? <img src={cover} alt="" className="size-full object-cover" /> : null}
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-primary">Série</p>
              <h1 className="mt-2 font-display text-4xl font-extrabold tracking-tight md:text-5xl">
                {title}
              </h1>
              {data?.info?.genre && (
                <p className="mt-2 text-sm text-muted-foreground">{data.info.genre}</p>
              )}
              {data?.info?.plot && (
                <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                  {data.info.plot}
                </p>
              )}
              <div className="mt-6 flex flex-wrap items-center gap-2">
                <FavoriteButton
                  variant="labelled"
                  entry={favoriteEntryFor({
                    kind: "series",
                    id: seriesId,
                    title,
                    image: cover,
                    href: `/series/${seriesId}`,
                  })}
                />
                {seasons.map((n) => {
                  const active = n === activeSeason;
                  return (
                    <button
                      key={n}
                      id={`season-btn-${n}`}
                      type="button"
                      onClick={() => setActiveSeason(active ? null : n)}
                      aria-expanded={active}
                      className={cn(
                        "rounded-full border px-4 py-2 text-sm font-semibold transition-colors focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
                        active
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-surface text-muted-foreground hover:text-foreground",
                      )}
                    >
                      T{n}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <div className="mx-auto max-w-6xl space-y-12 px-6 md:px-12">
          {error ? (
            <p role="alert" className="text-sm text-primary">
              {(error as Error).message}
            </p>
          ) : isLoading ? (
            <p className="text-sm text-muted-foreground">Carregando episódios…</p>
          ) : seasons.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum episódio disponível.</p>
          ) : (
            <section aria-label="Episódios">
              {activeSeason == null ? null : (
                <ul className="space-y-3">
                  {episodes.map((ep) => {
                    const epImage = proxiedImage(ep.info?.movie_image) ?? cover;
                    const epTitle = ep.title || `Episódio ${ep.episode_num}`;
                    const ext = ep.container_extension || "mp4";

                    const pKey = favoriteKey("series", seriesId, Number(ep.id));
                    const prog = getProgress(pKey);
                    const pct =
                      prog && prog.duration > 0
                        ? Math.min(100, (prog.position / prog.duration) * 100)
                        : 0;
                    const watched = pct >= 95 || isWatched(pKey);

                    return (
                      <li key={ep.id}>
                        <button
                          type="button"
                          onClick={() =>
                            setPlayingEp({
                              epId: Number(ep.id),
                              epNum: ep.episode_num,
                              season: activeSeason!,
                              title: `${title} — T${activeSeason}E${ep.episode_num}`,
                              image: epImage,
                              ext,
                            })
                          }
                          className={cn(
                            "group flex w-full items-center gap-4 rounded-xl border border-border bg-surface p-3 text-left transition-colors",
                            "hover:border-primary/40 hover:bg-surface-elevated",
                            watched && "border-primary/30 bg-primary/5",
                          )}
                        >
                          <div className="relative aspect-video w-32 shrink-0 overflow-hidden rounded-lg bg-background sm:w-44">
                            {epImage ? (
                              <img
                                src={epImage}
                                alt=""
                                className={cn("size-full object-cover", watched && "opacity-60")}
                              />
                            ) : null}
                            <div className="absolute inset-0 grid place-items-center bg-background/40 opacity-0 transition-opacity group-hover:opacity-100">
                              <Play className="size-8" aria-hidden />
                            </div>
                            {watched && (
                              <div className="absolute right-1.5 top-1.5 flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground shadow">
                                <Check className="size-3" aria-hidden />
                                Assistido
                              </div>
                            )}
                            {(pct > 0 || watched) && (
                              <div className="absolute inset-x-0 bottom-0 h-1 bg-black/60">
                                <div
                                  className="h-full bg-primary"
                                  style={{ width: `${watched ? 100 : pct}%` }}
                                />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                              Episódio {ep.episode_num}
                              {watched && <span className="ml-2 text-primary">· Assistido</span>}
                            </p>

                            <p className="mt-1 truncate font-display text-base font-semibold">
                              {epTitle}
                            </p>
                            {ep.info?.plot && (
                              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                                {ep.info.plot}
                              </p>
                            )}
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          )}

          {cast.length > 0 && (
            <CastRail
              cast={cast}
              activeActor={activeActor}
              onSelectActor={(name) =>
                setActiveActor((current) => (current === name ? null : name))
              }
            />
          )}

          {(tmdbRelated.data?.hasKey === false || actorCredits.data?.hasKey === false) && (
            <div className="rounded-3xl border border-border/60 bg-surface px-4 py-3 text-sm text-muted-foreground">
              A chave TMDB não está configurada. Relacionados e créditos de elenco dependem dela.
            </div>
          )}

          {activeActor && actorItems.length > 0 && (
            <ContentRail
              id="actor-credits"
              title={`Com ${activeActor}`}
              kind="poster"
              items={actorItems}
              layout="row"
            />
          )}

          {relatedItems.length > 0 && (
            <ContentRail
              id="tmdb-related"
              title="Relacionados disponíveis"
              kind="poster"
              items={relatedItems}
              layout="row"
            />
          )}
        </div>
      </main>

      {playingEp && credentials
        ? (() => {
            // Descobre o próximo episódio: primeiro tenta o próximo na temporada atual,
            // se não houver, pega o primeiro episódio da próxima temporada.
            const epsThisSeason = data?.episodes?.[String(playingEp.season)] ?? [];
            const idx = epsThisSeason.findIndex((e) => Number(e.id) === playingEp.epId);
            let nextRaw = idx >= 0 ? epsThisSeason[idx + 1] : undefined;
            let nextSeason = playingEp.season;
            if (!nextRaw) {
              const seasonIdx = seasons.indexOf(playingEp.season);
              const upcoming = seasonIdx >= 0 ? seasons[seasonIdx + 1] : undefined;
              if (upcoming != null) {
                const list = data?.episodes?.[String(upcoming)] ?? [];
                nextRaw = list[0];
                nextSeason = upcoming;
              }
            }
            const nextEp = nextRaw
              ? {
                  epId: Number(nextRaw.id),
                  epNum: nextRaw.episode_num,
                  season: nextSeason,
                  title: `${title} — T${nextSeason}E${nextRaw.episode_num}`,
                  image: proxiedImage(nextRaw.info?.movie_image) ?? cover,
                  ext: nextRaw.container_extension || "mp4",
                }
              : null;
            return (
              <InlinePlayer
                open={true}
                onClose={() => setPlayingEp(null)}
                src={buildSeriesEpisodeUrl(credentials, playingEp.epId, playingEp.ext)}
                isHls={false}
                trackingKey={favoriteKey("series", seriesId, playingEp.epId)}
                onNext={nextEp ? () => setPlayingEp(nextEp) : null}
                entry={{
                  kind: "series",
                  id: seriesId,
                  episodeId: playingEp.epId,
                  title: playingEp.title,
                  image: playingEp.image,
                  href: `/watch/series/${playingEp.epId}?ext=${playingEp.ext}&seriesId=${seriesId}&title=${encodeURIComponent(playingEp.title)}${playingEp.image ? `&image=${encodeURIComponent(playingEp.image)}` : ""}`,
                }}
              />
            );
          })()
        : null}
    </div>
  );
}
