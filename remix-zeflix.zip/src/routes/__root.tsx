import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { useSpatialNav } from "@/hooks/use-spatial-nav";
import { getActiveProfile, subscribeProfiles, type Profile } from "@/lib/profile";
import { getProfileColor } from "@/lib/profile-colors";
import { MobileRemoteDock } from "@/components/mobile-remote-dock";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#0a0a0a" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "ZéFlix" },
      { name: "mobile-web-app-capable", content: "yes" },
      { title: "ZéFlix" },

      {
        name: "description",
        content: "ZéFlix é o seu hub IPTV com filmes, séries e TV ao vivo, no estilo Netflix.",
      },
      { name: "author", content: "ZéFlix" },
      { property: "og:title", content: "ZéFlix" },
      {
        property: "og:description",
        content: "ZéFlix é o seu hub IPTV com filmes, séries e TV ao vivo, no estilo Netflix.",
      },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "ZéFlix" },
      { property: "og:image", content: "https://zeflix.lovable.app/banner_tv.png" },
      { property: "og:image:width", content: "320" },
      { property: "og:image:height", content: "180" },
      { property: "og:image:alt", content: "Banner do ZéFlix para Android TV" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "ZéFlix" },
      {
        name: "twitter:description",
        content: "ZéFlix é o seu hub IPTV com filmes, séries e TV ao vivo, no estilo Netflix.",
      },
      { name: "twitter:image", content: "https://zeflix.lovable.app/banner_tv.png" },
      { name: "twitter:image:alt", content: "Banner do ZéFlix para Android TV" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "shortcut icon", type: "image/png", href: "/icon-192.png" },
      { rel: "icon", type: "image/png", sizes: "192x192", href: "/icon-192.png" },
      { rel: "icon", type: "image/png", sizes: "512x512", href: "/icon-512.png" },
      { rel: "apple-touch-icon", sizes: "192x192", href: "/icon-192.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@600;800&family=Inter:wght@400;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  useSpatialNav();
  const [activeProfile, setActiveProfileState] = useState<Profile | null>(null);

  useEffect(() => {
    const applyThemeFromProfile = (profile: Profile | null) => {
      const root = document.documentElement;
      if (!profile) {
        root.style.removeProperty("--background");
        root.style.removeProperty("--surface");
        root.style.removeProperty("--card");
        root.style.removeProperty("--primary");
        root.style.removeProperty("--ring"); // Limpa a cor do foco
        root.style.removeProperty("--primary-foreground");
        root.style.removeProperty("--foreground");
        root.style.removeProperty("--muted");
        root.style.removeProperty("--profile-bg-image");
        return;
      }

      // Use fixed pastel colors based on colorIndex
      const colorIndex = profile.colorIndex ?? 0;
      const colors = getProfileColor(colorIndex);

      root.style.setProperty("--background", colors.background);
      root.style.setProperty("--surface", colors.surface);
      root.style.setProperty("--card", colors.card);
      root.style.setProperty("--primary", colors.primary);
      root.style.setProperty("--ring", colors.primary); // Aplica cor do perfil no foco
      root.style.setProperty("--primary-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--secondary-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--accent-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--destructive-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--card-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--popover-foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--foreground", "oklch(0.985 0 0)");
      root.style.setProperty("--muted", "oklch(0.21 0 0)");
      root.style.setProperty("--muted-foreground", "oklch(0.7 0 0)");
    };

    const applyActiveProfile = () => {
      const profile = getActiveProfile();
      setActiveProfileState(profile);
      applyThemeFromProfile(profile);
    };

    applyActiveProfile();
    const unsubscribe = subscribeProfiles(() => applyActiveProfile());
    return unsubscribe;
  }, []);

  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (pathname === "/" && !activeProfile) {
      document.documentElement.style.setProperty("--background", "oklch(0.13 0 0)");
    }
  }, [pathname, activeProfile]);
  const showProfileBg = pathname === "/" || pathname === "/browse";
  // Removed bgImage application to prevent profile avatar from appearing as background overlay

  return (
    <QueryClientProvider client={queryClient}>
      <div className="profile-bg relative min-h-screen pb-20 md:pb-0">
        <Outlet />
        <MobileRemoteDock />
      </div>
    </QueryClientProvider>
  );
}
