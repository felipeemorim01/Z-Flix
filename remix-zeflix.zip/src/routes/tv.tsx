import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useCredentialsResolved, useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { proxiedImage } from "@/lib/xtream";

export const Route = createFileRoute("/tv")({
  head: () => ({
    meta: [
      { title: "ZéFlix — TV ao vivo" },
      {
        name: "description",
        content: "Assista aos canais de TV ao vivo do seu provedor IPTV no ZéFlix.",
      },
      { property: "og:title", content: "ZéFlix — TV ao vivo" },
      {
        property: "og:description",
        content: "Assista aos canais de TV ao vivo do seu provedor IPTV no ZéFlix.",
      },
    ],
  }),
  component: TvPage,
});

function TvPage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const credentials = useStoredCredentials();
  const resolved = useCredentialsResolved();
  const navigate = useNavigate();

  useEffect(() => {
    if (mounted && resolved && !credentials) void navigate({ to: "/", replace: true });
  }, [mounted, resolved, credentials, navigate]);

  const catalog = useXtreamCatalog(mounted ? credentials : null);

  const liveItems: RailItem[] = catalog.liveStreams.map((s) => ({
    id: `live-${s.stream_id}`,
    title: s.name,
    image: proxiedImage(s.stream_icon),
    href: `/watch/live/${s.stream_id}?title=${encodeURIComponent(s.name)}`,
    favorite: { kind: "live", contentId: s.stream_id },
  }));

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-[1600px] px-6 py-6 md:px-12 md:py-8">
        {!mounted || catalog.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando canais…</p>
        ) : catalog.error ? (
          <p className="text-sm text-primary">
            Não foi possível carregar os canais: {catalog.error.message}
          </p>
        ) : liveItems.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nenhum canal reportado pelo seu provedor.</p>
        ) : (
          <ContentRail
            id="tv-all"
            title={`${liveItems.length} canais`}
            kind="live"
            items={liveItems}
          />
        )}
      </main>
    </div>
  );
}
