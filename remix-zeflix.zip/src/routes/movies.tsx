import { createFileRoute } from "@tanstack/react-router";
import { CatalogPage } from "@/components/catalog-page";

export const Route = createFileRoute("/movies")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Filmes" },
      {
        name: "description",
        content: "Catálogo completo de filmes do seu provedor IPTV, por categoria.",
      },
      { property: "og:title", content: "ZéFlix — Filmes" },
      {
        property: "og:description",
        content: "Catálogo completo de filmes do seu provedor IPTV, por categoria.",
      },
    ],
  }),
  component: () => (
    <CatalogPage
      kind="movie"
      title="Filmes"
      subtitle="Todo o catálogo do seu provedor, organizado por categoria."
    />
  ),
});
