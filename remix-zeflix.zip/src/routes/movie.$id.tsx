import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Cast, Play } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { BackButton } from "@/components/back-button";
import { FavoriteButton, favoriteEntryFor } from "@/components/favorite-button";
import { ContentRail } from "@/components/content-rail";
import { CastRail, parseCast } from "@/components/actor-avatar";
import { InlinePlayer } from "@/components/inline-player";
import { useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { buildVodStreamUrl, fetchVodInfo, proxiedImage } from "@/lib/xtream";
import { favoriteKey } from "@/lib/library";
import { matchTmdbListToRailItems } from "@/lib/catalog-match";
import { getTmdbPersonCredits, getTmdbRecommendations } from "@/lib/tmdb.functions";

interface MovieSearch {
  ext?: string;
  title?: string;
  image?: string;
  autoplay?: string;
}

export const Route = createFileRoute("/movie/$id")({
  validateSearch: (s: Record<string, unknown>): MovieSearch => ({
    ext: typeof s.ext === "string" ? s.ext : undefined,
    title: typeof s.title === "string" ? s.title : undefined,
    image: typeof s.image === "string" ? s.image : undefined,
    autoplay: typeof s.autoplay === "string" ? s.autoplay : undefined,
  }),
  head: () => ({
    meta: [
      { title: "ZéFlix — Filme" },
      { name: "description", content: "Detalhes do filme, elenco e títulos relacionados." },
    ],
  }),
  component: MoviePage,
});

function MoviePage() {
  const { id } = Route.useParams();
  const search = useSearch({ from: "/movie/$id" });
  const credentials = useStoredCredentials();
  const navigate = useNavigate();
  const vodId = Number.parseInt(id, 10);
  const [activeActor, setActiveActor] = useState<string | null>(null);
  const playButtonRef = useEffect(() => {
    const btn = document.getElementById("movie-play-button");
    if (btn) btn.focus();
  }, [id]);

  const fetchRecs = useServerFn(getTmdbRecommendations);
  const fetchPersonCredits = useServerFn(getTmdbPersonCredits);

  useEffect(() => {
    if (!credentials) void navigate({ to: "/", replace: true });
  }, [credentials, navigate]);

  const info = useQuery({
    queryKey: ["xtream", "vod-info", vodId],
    queryFn: () => fetchVodInfo(credentials!, vodId),
    enabled: !!credentials && !Number.isNaN(vodId),
    staleTime: 5 * 60 * 1000,
  });

  // Já temos o catálogo em cache (mesmo staleTime) — reaproveitamos p/ relacionados.
  const catalog = useXtreamCatalog(credentials);

  const data = info.data;
  const title = data?.info?.name ?? search.title ?? `Filme #${vodId}`;
  const cover =
    proxiedImage(data?.info?.movie_image) ?? proxiedImage(data?.info?.cover_big) ?? search.image;
  const backdrop = (() => {
    const b = data?.info?.backdrop_path;
    if (Array.isArray(b) && b[0]) return proxiedImage(b[0]);
    if (typeof b === "string") return proxiedImage(b);
    return cover;
  })();
  const plot = data?.info?.plot ?? data?.info?.description ?? "";
  const cast = useMemo(() => parseCast(data?.info?.cast ?? data?.info?.actors), [data]);
  const ext = data?.movie_data?.container_extension ?? search.ext ?? "mp4";
  const tmdbRelated = useQuery({
    queryKey: ["tmdb", "movie-related", title],
    queryFn: () => fetchRecs({ data: { seeds: [{ title, kind: "movie" }] } }),
    enabled: !!title && title !== `Filme #${vodId}`,
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 6,
  });

  const relatedItems = useMemo(
    () =>
      matchTmdbListToRailItems(tmdbRelated.data?.items ?? [], {
        movies: catalog.vodStreams,
        series: catalog.series,
      })
        .filter((item) => item.id !== `movie-${vodId}`)
        .slice(0, 18),
    [tmdbRelated.data?.items, catalog.vodStreams, catalog.series, vodId],
  );

  const actorCredits = useQuery({
    queryKey: ["tmdb", "actor-credits", activeActor],
    queryFn: () => fetchPersonCredits({ data: { name: activeActor ?? "" } }),
    enabled: !!activeActor,
    staleTime: 1000 * 60 * 60 * 24,
    gcTime: 1000 * 60 * 60 * 24,
  });

  const actorItems = useMemo(
    () =>
      matchTmdbListToRailItems(actorCredits.data?.items ?? [], {
        movies: catalog.vodStreams,
        series: catalog.series,
      })
        .filter((item) => item.id !== `movie-${vodId}`)
        .slice(0, 18),
    [actorCredits.data?.items, catalog.vodStreams, catalog.series, vodId],
  );

  const [playing, setPlaying] = useState(false);
  // Auto-abre o player quando aberto pelo "Continuar assistindo".
  useEffect(() => {
    if (search.autoplay === "1") setPlaying(true);
  }, [search.autoplay]);
  const playerSrc = credentials ? buildVodStreamUrl(credentials, vodId, ext) : "";
  const playerHref = (() => {
    const p = new URLSearchParams({ ext, title });
    if (cover) p.set("image", cover);
    return `/watch/movie/${vodId}?${p.toString()}`;
  })();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteNav />
      <main className="pb-24">
        {/* Hero */}
        <section className="relative">
          {cover || backdrop ? (
            <div className="fixed inset-0 -z-10 overflow-hidden">
              <img
                src={cover || backdrop}
                alt=""
                className="size-full object-cover opacity-20 blur-2xl scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/20" />
            </div>
          ) : null}
          <div className="mx-auto max-w-6xl px-6 pt-8 md:px-12">
            <BackButton fallback="/movies" label="Voltar ao catálogo" />
          </div>
          <div className="mx-auto grid max-w-6xl gap-8 px-6 py-12 md:grid-cols-[220px_1fr] md:px-12">
            <div className="aspect-[2/3] w-full max-w-[220px] overflow-hidden rounded-xl border border-border bg-surface">
              {cover ? <img src={cover} alt="" className="size-full object-cover" /> : null}
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-primary">Filme</p>
              <h1 className="mt-2 font-display text-4xl font-extrabold tracking-tight md:text-5xl">
                {title}
              </h1>
              {(data?.info?.genre || data?.info?.releasedate || data?.info?.duration) && (
                <p className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-sm text-muted-foreground">
                  {data?.info?.genre && <span>{data.info.genre}</span>}
                  {data?.info?.releasedate && <span>· {data.info.releasedate}</span>}
                  {data?.info?.duration && <span>· {data.info.duration}</span>}
                </p>
              )}
              {plot && (
                <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                  {plot}
                </p>
              )}
              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => setPlaying(true)}
                  id="movie-play-button"
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03] focus-visible:scale-[1.03] focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
                >
                  <Cast className="size-4" aria-hidden />
                  Transmitir para TV
                </button>

                <FavoriteButton
                  variant="labelled"
                  entry={favoriteEntryFor({
                    kind: "movie",
                    id: vodId,
                    title,
                    image: cover,
                    href: `/movie/${vodId}`,
                  })}
                />
              </div>
            </div>
          </div>
        </section>

        <div className="mx-auto max-w-6xl space-y-12 px-6 md:px-12">
          {info.isLoading && <p className="text-sm text-muted-foreground">Carregando detalhes…</p>}

          {cast.length > 0 && (
            <CastRail
              cast={cast}
              activeActor={activeActor}
              onSelectActor={(name) =>
                setActiveActor((current) => (current === name ? null : name))
              }
            />
          )}

          {(tmdbRelated.data?.hasKey === false || actorCredits.data?.hasKey === false) && (
            <div className="rounded-3xl border border-border/60 bg-surface px-4 py-3 text-sm text-muted-foreground">
              A chave TMDB não está configurada. Relacionados e créditos de elenco dependem dela.
            </div>
          )}

          {activeActor && actorItems.length > 0 && (
            <ContentRail
              id="actor-credits"
              title={`Com ${activeActor}`}
              kind="poster"
              items={actorItems}
              layout="row"
            />
          )}

          {relatedItems.length > 0 && (
            <ContentRail
              id="tmdb-related"
              title="Relacionados disponíveis"
              kind="poster"
              items={relatedItems}
              layout="row"
            />
          )}
        </div>
      </main>

      <InlinePlayer
        open={playing && !!playerSrc}
        onClose={() => setPlaying(false)}
        src={playerSrc}
        isHls={false}
        trackingKey={favoriteKey("movie", vodId)}
        entry={{
          kind: "movie",
          id: vodId,
          title,
          image: cover,
          href: playerHref,
        }}
      />
    </div>
  );
}
