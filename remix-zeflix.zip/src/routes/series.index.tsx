import { createFileRoute } from "@tanstack/react-router";
import { CatalogPage } from "@/components/catalog-page";

export const Route = createFileRoute("/series/")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Séries" },
      {
        name: "description",
        content: "Catálogo completo de séries do seu provedor IPTV, por categoria.",
      },
      { property: "og:title", content: "ZéFlix — Séries" },
      {
        property: "og:description",
        content: "Catálogo completo de séries do seu provedor IPTV, por categoria.",
      },
    ],
  }),
  component: () => (
    <CatalogPage
      kind="series"
      title="Séries"
      subtitle="Todo o catálogo do seu provedor, organizado por categoria."
    />
  ),
});
