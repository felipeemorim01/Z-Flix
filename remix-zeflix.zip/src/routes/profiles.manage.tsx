import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import useEmblaCarousel from "embla-carousel-react";
import {
  ArrowLeft,
  Check,
  Globe,
  KeyRound,
  Lock,
  Pencil,
  Play,
  Sparkles,
  Trash2,
  User,
  UserPlus,
} from "lucide-react";
import {
  createProfile,
  getProfileAvatarSlots,
  listProfiles,
  normalizeServerUrl,
  setActiveProfile,
  updateProfile,
  deleteProfile,
  type Profile,
  type XtreamCredentials,
} from "@/lib/profile";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SiteNav } from "@/components/site-nav";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/profiles/manage")({
  head: () => ({
    meta: [{ title: "Gerenciar perfis — ZéFlix" }],
  }),
  component: ManageProfilesPage,
});

interface FormState extends XtreamCredentials {
  name: string;
  color?: string;
}

function ManageProfilesPage() {
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [avatarSlots, setAvatarSlots] = useState<string[]>(() => getProfileAvatarSlots());
  const [selectedAvatarSlot, setSelectedAvatarSlot] = useState(0);
  const [form, setForm] = useState<FormState>({
    name: "",
    serverUrl: "",
    username: "",
    password: "",
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Profile | null>(null);
  const [showDelete, setShowDelete] = useState(false);

  const formSectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setProfiles(listProfiles());
    setAvatarSlots(getProfileAvatarSlots());
  }, []);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((p) => ({ ...p, [key]: value }));
  }

  function handleEdit(p: Profile) {
    setEditingId(p.id);
    setForm({
      name: p.name,
      serverUrl: p.credentials.serverUrl,
      username: p.credentials.username,
      password: p.credentials.password,
    });
    const idx = avatarSlots.findIndex((s) => s && p.avatar === s);
    const targetIdx = idx >= 0 ? idx : 0;
    setSelectedAvatarSlot(targetIdx);

    // Scroll to form smoothly
    if (formSectionRef.current) {
      formSectionRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function handleCancelEdit() {
    setEditingId(null);
    setForm({ name: "", serverUrl: "", username: "", password: "" });
    setSelectedAvatarSlot(0);
    setError(null);
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const name = form.name.trim();
    const serverUrl = normalizeServerUrl(form.serverUrl);
    const username = form.username.trim();
    const password = form.password;
    const avatar = avatarSlots[selectedAvatarSlot] || undefined;

    if (!name || !serverUrl || !username || !password) {
      setError("Preencha todos os campos para continuar.");
      return;
    }
    try {
      new URL(serverUrl);
    } catch {
      setError("O servidor precisa ser um endereço http(s) válido.");
      return;
    }

    setSaving(true);
    try {
      if (editingId) {
        updateProfile(editingId, name, { serverUrl, username, password }, avatar);
        toast.success(`Perfil de ${name} atualizado com sucesso!`);
        setProfiles(listProfiles());
        setEditingId(null);
        setForm({ name: "", serverUrl: "", username: "", password: "" });
        setSaving(false);
        return;
      }

      createProfile(name, { serverUrl, username, password }, avatar);
      toast.success(`Perfil de ${name} criado com sucesso!`);
      void navigate({ to: "/browse", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível salvar o perfil.");
      setSaving(false);
    }
  }

  return (
    <div className="relative min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Ambient background glow without harsh lines */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 h-[450px] w-[700px] rounded-full bg-primary/10 blur-[130px]" />
        <div className="absolute top-1/2 right-[-100px] h-[350px] w-[350px] rounded-full bg-primary/5 blur-[120px]" />
      </div>

      <SiteNav showNavLinks={false} />

      <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6 md:py-10">
        <div className="space-y-8">
          {/* Top Bar with Back action */}
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => void navigate({ to: "/" })}
              className="inline-flex items-center gap-2 rounded-full bg-surface/60 hover:bg-surface px-4 py-2.5 text-xs font-bold text-muted-foreground hover:text-foreground transition-all active:scale-95"
            >
              <ArrowLeft className="size-4" />
              <span>Voltar</span>
            </button>

            {editingId && (
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-bold text-primary">
                  Editando perfil
                </span>
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="rounded-full bg-surface/60 hover:bg-surface px-3 py-1 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
                >
                  Cancelar
                </button>
              </div>
            )}
          </div>

          {/* Perfis Existentes (se houver) */}
          {profiles.length > 0 && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {profiles.map((p) => {
                const isCurrentlyEditing = editingId === p.id;
                return (
                  <div
                    key={p.id}
                    className={cn(
                      "group relative flex flex-col justify-between rounded-3xl bg-surface/40 p-4 backdrop-blur-md transition-all duration-200 hover:bg-surface/70",
                      isCurrentlyEditing && "ring-2 ring-primary/80 bg-surface/80 shadow-glow",
                    )}
                  >
                    <div className="flex items-center gap-3.5">
                      <Avatar className="size-14 shrink-0 rounded-2xl shadow-md transition-transform duration-300 group-hover:scale-105">
                        {p.avatar ? (
                          <AvatarImage src={p.avatar} alt={p.name} className="object-cover" />
                        ) : (
                          <AvatarFallback className="rounded-2xl bg-surface-elevated font-display text-sm font-black">
                            {p.name.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-display text-base font-bold text-foreground">
                          {p.name}
                        </div>
                        <div className="truncate text-[11px] text-muted-foreground/70">
                          {p.credentials.serverUrl}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveProfile(p.id);
                          void navigate({ to: "/browse", replace: true });
                        }}
                        className="flex items-center justify-center gap-1 rounded-xl bg-primary px-2 py-2 text-xs font-bold text-primary-foreground shadow-glow transition-all hover:bg-primary/90 active:scale-95"
                        title="Entrar com este perfil"
                      >
                        <Play className="size-3 fill-current" />
                        <span>Entrar</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleEdit(p)}
                        className={cn(
                          "flex items-center justify-center gap-1 rounded-xl bg-surface/80 hover:bg-surface-elevated px-2 py-2 text-xs font-semibold text-foreground transition-all active:scale-95",
                          isCurrentlyEditing && "bg-primary/20 text-primary font-bold",
                        )}
                        title="Editar perfil"
                      >
                        <Pencil className="size-3" />
                        <span>Editar</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDeleteTarget(p);
                          setShowDelete(true);
                        }}
                        className="flex items-center justify-center gap-1 rounded-xl bg-destructive/10 hover:bg-destructive/20 px-2 py-2 text-xs font-semibold text-destructive transition-all active:scale-95"
                        title="Excluir perfil"
                      >
                        <Trash2 className="size-3" />
                        <span>Excluir</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Card Principal: Carrossel + Inputs (Clean, sem ruído visual) */}
          <div
            ref={formSectionRef}
            className="relative rounded-3xl bg-surface/35 p-6 backdrop-blur-xl sm:p-8 shadow-2xl transition-all"
          >
            {/* Carrossel Infinito de Avatares */}
            <div className="mb-6">
              <AvatarInfiniteCarousel
                avatars={avatarSlots}
                selectedIndex={selectedAvatarSlot}
                onSelectIndex={setSelectedAvatarSlot}
              />
            </div>

            {/* Formulário Minimalista */}
            <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
              <div className="grid gap-3.5 sm:grid-cols-2">
                <CleanField
                  id="name"
                  type="text"
                  icon={User}
                  autoComplete="nickname"
                  placeholder="Nome do perfil"
                  value={form.name}
                  onChange={(v) => update("name", v)}
                />

                <CleanField
                  id="serverUrl"
                  type="url"
                  icon={Globe}
                  autoComplete="url"
                  placeholder="Servidor IPTV (http://...)"
                  value={form.serverUrl}
                  onChange={(v) => update("serverUrl", v)}
                />
              </div>

              <div className="grid gap-3.5 sm:grid-cols-2">
                <CleanField
                  id="username"
                  type="text"
                  icon={KeyRound}
                  autoComplete="username"
                  placeholder="Usuário IPTV"
                  value={form.username}
                  onChange={(v) => update("username", v)}
                />

                <CleanField
                  id="password"
                  type="password"
                  icon={Lock}
                  autoComplete="current-password"
                  placeholder="Senha IPTV"
                  value={form.password}
                  onChange={(v) => update("password", v)}
                />
              </div>

              {error ? (
                <div
                  role="alert"
                  className="rounded-2xl bg-destructive/15 px-4 py-3 text-xs font-semibold text-destructive animate-fade-in"
                >
                  {error}
                </div>
              ) : null}

              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                <button
                  type="submit"
                  disabled={saving}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 px-6 text-sm font-extrabold text-primary-foreground shadow-glow transition-all duration-200 hover:bg-primary/90 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50",
                  )}
                >
                  {saving ? (
                    <span>Salvando...</span>
                  ) : editingId ? (
                    <>
                      <Check className="size-4" />
                      <span>Salvar alterações</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="size-4" />
                      <span>Salvar e entrar</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>

      {/* Modal de confirmação de exclusão Clean */}
      <Dialog open={showDelete} onOpenChange={setShowDelete}>
        <DialogContent className="rounded-3xl border-0 bg-surface/95 p-6 backdrop-blur-2xl shadow-2xl">
          <DialogHeader className="space-y-2">
            <DialogTitle className="font-display text-xl font-bold text-foreground">
              Excluir perfil
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm text-muted-foreground">
              Tem certeza que deseja excluir o perfil
              {deleteTarget ? ` "${deleteTarget.name}"` : ""}? Todas as credenciais e
              personalizações deste perfil serão removidas deste dispositivo.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <div className="flex w-full items-center justify-end gap-2">
              <button
                type="button"
                className="rounded-full bg-surface/80 hover:bg-surface px-4 py-2.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => setShowDelete(false)}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="rounded-full bg-destructive px-5 py-2.5 text-xs font-bold text-destructive-foreground hover:opacity-90 active:scale-95 transition-all shadow-md"
                onClick={() => {
                  if (!deleteTarget) return;
                  deleteProfile(deleteTarget.id);
                  setProfiles(listProfiles());
                  toast.success("Perfil excluído.");
                  setShowDelete(false);
                  setDeleteTarget(null);
                }}
              >
                Excluir perfil
              </button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/**
 * Carrossel infinito com rotação suave e avatares ampliados em destaque
 */
function AvatarInfiniteCarousel({
  avatars,
  selectedIndex,
  onSelectIndex,
}: {
  avatars: string[];
  selectedIndex: number;
  onSelectIndex: (index: number) => void;
}) {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: "center",
    skipSnaps: false,
    dragFree: false,
  });

  // Sincroniza o slide selecionado quando o carrossel se move para qualquer snap
  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    const snapIndex = emblaApi.selectedScrollSnap();
    onSelectIndex(snapIndex);
  }, [emblaApi, onSelectIndex]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("settle", onSelect);
    emblaApi.on("reInit", onSelect);
    return () => {
      emblaApi.off("select", onSelect);
      emblaApi.off("settle", onSelect);
      emblaApi.off("reInit", onSelect);
    };
  }, [emblaApi, onSelect]);

  // Se o selectedIndex mudar externamente (ex: clicando em editar perfil), rola até ele
  useEffect(() => {
    if (!emblaApi) return;
    if (emblaApi.selectedScrollSnap() !== selectedIndex) {
      emblaApi.scrollTo(selectedIndex);
    }
  }, [selectedIndex, emblaApi]);

  // Navegação por D-pad / Teclado (setas < e > mudam o avatar central selecionado)
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        e.stopPropagation();
        emblaApi?.scrollPrev();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        e.stopPropagation();
        emblaApi?.scrollNext();
      }
    },
    [emblaApi],
  );

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      className="relative w-full overflow-hidden rounded-3xl bg-surface/20 py-8 sm:py-10 backdrop-blur-md select-none focus:outline-none focus:ring-2 focus:ring-primary/40 [mask-image:linear-gradient(to_right,transparent_0%,black_8%,black_92%,transparent_100%)] [-webkit-mask-image:linear-gradient(to_right,transparent_0%,black_8%,black_92%,transparent_100%)]"
    >
      {/* Viewport do Carrossel contínuo de ponta a ponta */}
      <div ref={emblaRef} className="w-full overflow-hidden cursor-grab active:cursor-grabbing">
        <div className="flex items-center -ml-3 sm:-ml-5 py-6 sm:py-8">
          {avatars.map((avatarUrl, index) => {
            const isSelected = selectedIndex === index;

            return (
              <div
                key={index}
                className="min-w-0 shrink-0 grow-0 basis-[46%] sm:basis-[34%] md:basis-[26%] pl-3 sm:pl-5 flex items-center justify-center"
              >
                <button
                  type="button"
                  tabIndex={0}
                  onClick={() => {
                    onSelectIndex(index);
                    emblaApi?.scrollTo(index);
                  }}
                  onFocus={() => {
                    onSelectIndex(index);
                    emblaApi?.scrollTo(index);
                  }}
                  onKeyDown={handleKeyDown}
                  aria-label={`Avatar ${index + 1}`}
                  className={cn(
                    "group relative aspect-square w-28 sm:w-36 md:w-44 rounded-full overflow-hidden bg-surface-elevated transition-all duration-300 ease-out focus:outline-none focus:ring-4 focus:ring-primary",
                    isSelected
                      ? "scale-110 sm:scale-120 ring-4 ring-primary shadow-[0_0_35px_rgba(249,56,34,0.5)] z-10 opacity-100"
                      : "scale-85 sm:scale-90 opacity-40 hover:opacity-80 hover:scale-95",
                  )}
                >
                  {avatarUrl ? (
                    <img
                      src={avatarUrl}
                      alt={`Avatar ${index + 1}`}
                      className="size-full object-cover object-center rounded-full transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                  ) : (
                    <div className="flex size-full items-center justify-center bg-surface-elevated font-display text-2xl font-black text-muted-foreground">
                      {index + 1}
                    </div>
                  )}

                  {/* Badge de Selecionado */}
                  {isSelected && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end justify-center pb-2.5 sm:pb-3">
                      <div className="flex size-6 sm:size-7 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg">
                        <Check className="size-3.5 sm:size-4 stroke-[3]" />
                      </div>
                    </div>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/**
 * Campo de formulário moderno, sem bordas rígidas e com ícones elegantes
 */
function CleanField({
  id,
  type,
  value,
  onChange,
  placeholder,
  autoComplete,
  icon: Icon,
}: {
  id: string;
  type: "text" | "url" | "password";
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  autoComplete?: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="group flex items-center gap-3 rounded-2xl bg-surface/60 hover:bg-surface/80 focus-within:bg-surface-elevated focus-within:ring-2 focus-within:ring-primary/60 px-4 py-3.5 sm:py-4 transition-all duration-200">
      <Icon className="size-4 shrink-0 text-muted-foreground/60 transition-colors group-focus-within:text-primary" />
      <input
        id={id}
        type={type}
        autoComplete={autoComplete}
        placeholder={placeholder}
        aria-label={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border-0 bg-transparent p-0 text-sm sm:text-base text-foreground placeholder:text-muted-foreground/45 focus:outline-none focus:ring-0"
      />
    </div>
  );
}
