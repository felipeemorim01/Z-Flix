import { useEffect, useState, useMemo } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useCredentialsResolved, useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { loadFavorites, type FavoriteEntry } from "@/lib/library";
import { getTmdbRecommendations } from "@/lib/tmdb.functions";
import type { TmdbItem } from "@/lib/tmdb-types";
import { matchTmdbListToRailItems } from "@/lib/catalog-match";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/recommendations")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Recomendações" },
      {
        name: "description",
        content: "Conteúdos recomendados especialmente para você com base no seu gosto.",
      },
      { property: "og:title", content: "ZéFlix — Recomendações" },
      {
        property: "og:description",
        content: "Conteúdos recomendados especialmente para você com base no seu gosto.",
      },
    ],
  }),
  component: RecommendationsPage,
});

function RecommendationsPage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const credentials = useStoredCredentials();
  const resolved = useCredentialsResolved();
  const navigate = useNavigate();

  useEffect(() => {
    if (mounted && resolved && !credentials) void navigate({ to: "/", replace: true });
  }, [mounted, resolved, credentials, navigate]);

  const catalog = useXtreamCatalog(mounted ? credentials : null);

  // Busca favoritos para servir de base
  const favorites = useMemo(() => {
    if (!mounted) return [];
    return loadFavorites();
  }, [mounted]);

  // Busca recomendações do TMDB
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery({
    queryKey: ["tmdb-recommendations", favorites.map((f: FavoriteEntry) => f.key)],
    queryFn: async () => {
      if (favorites.length === 0) return [];

      // Pega os 3 favoritos mais recentes para servir de base
      const baseFavorites = favorites.slice(-3).reverse();
      const results = await getTmdbRecommendations({
        data: {
          seeds: baseFavorites.map((f: FavoriteEntry) => ({
            title: f.title,
            kind: (f.kind === "series" ? "tv" : "movie") as "tv" | "movie",
          })),
        },
      });

      const items: TmdbItem[] = results.items || [];

      // Achata e remove duplicados
      const seen = new Set<number>();
      return items.filter((item: TmdbItem) => {
        if (seen.has(item.id)) return false;
        seen.add(item.id);
        return true;
      });
    },
    enabled: mounted && favorites.length > 0,
  });

  const matchedItems = useMemo(() => {
    if (!mounted || !recommendations || catalog.isLoading) return [];

    return matchTmdbListToRailItems(recommendations, {
      movies: catalog.vodStreams,
      series: catalog.series,
    });
  }, [mounted, recommendations, catalog.isLoading, catalog.vodStreams, catalog.series]);

  const isLoading = !mounted || catalog.isLoading || recommendationsLoading;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-[1600px] px-6 py-6 md:px-12 md:py-8">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Gerando recomendações personalizadas…</p>
        ) : favorites.length === 0 ? (
          <div className="rounded-2xl border border-border p-12 text-center">
            <p className="text-lg text-muted-foreground">
              Adicione filmes ou séries aos seus favoritos para receber recomendações!
            </p>
          </div>
        ) : matchedItems.length === 0 ? (
          <div className="rounded-2xl border border-border p-12 text-center">
            <p className="text-lg text-muted-foreground">
              Ainda não encontramos conteúdos similares na sua lista IPTV.
            </p>
          </div>
        ) : (
          <div className="space-y-12">
            <ContentRail
              id="recommendations-rail"
              title="Baseado no seu gosto"
              kind="poster"
              items={matchedItems}
            />
          </div>
        )}
      </main>
    </div>
  );
}
