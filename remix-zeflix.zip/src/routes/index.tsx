import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Plus, Settings } from "lucide-react";
import { getActiveProfile, listProfiles, setActiveProfile, type Profile } from "@/lib/profile";
import { SiteNav } from "@/components/site-nav";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Quem vai assistir?" },
      {
        name: "description",
        content:
          "Escolha seu perfil ou crie um novo para assistir filmes, séries e canais ao vivo.",
      },
      { property: "og:title", content: "ZéFlix — Quem vai assistir?" },
      {
        property: "og:description",
        content:
          "Escolha seu perfil ou crie um novo para assistir filmes, séries e canais ao vivo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const navigate = useNavigate();
  const [hydrated, setHydrated] = useState(false);
  const [profiles, setProfiles] = useState<Profile[]>([]);

  useEffect(() => {
    const active = getActiveProfile();
    if (active) {
      void navigate({ to: "/browse", replace: true });
      return;
    }
    setProfiles(listProfiles());
    setHydrated(true);
  }, [navigate]);

  if (!hydrated) {
    return (
      <div className="grid min-h-screen place-items-center bg-background text-muted-foreground">
        Carregando...
      </div>
    );
  }
  return <ProfileSelection profiles={profiles} />;
}

function ProfileSelection({ profiles }: { profiles: Profile[] }) {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen bg-background text-foreground overflow-hidden flex flex-col justify-between">
      {/* Background Montage */}
      <div className="absolute inset-0 -z-10 opacity-[0.20] blur-[3px] grayscale">
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-4 p-4 rotate-12 scale-150">
          {[...Array(40)].map((_, i) => {
            const movieImg = `https://images.unsplash.com/photo-${
              [
                "1536440136628-849c177e76a1", // Action
                "1485846234645-a62644f84728", // Movie general
                "1598899134739-24c46f58b8c0", // Cinema
                "1626814026160-2237a95fc5a0", // Action/Thriller
                "1535016120720-40c646be44da", // Drama
                "1518709268805-4e9042af9f23", // Sci-fi
                "1509248961158-e54f6934749c", // Horror
                "1594908900066-3f47337549d8", // Action
              ][i % 8]
            }?w=300&h=450&fit=crop`;

            return (
              <div
                key={i}
                className="aspect-[2/3] w-full rounded-lg bg-surface/20 shadow-lg overflow-hidden border border-border/10"
              >
                <img src={movieImg} alt="" className="size-full object-cover" loading="lazy" />
              </div>
            );
          })}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background" />
      </div>

      <SiteNav showNavLinks={false} />

      <main className="relative flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-5xl animate-fade-in space-y-12">
          <div className="text-center">
            <h1 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight">
              Quem vai assistir?
            </h1>
          </div>

          {profiles.length > 0 ? (
            <div className="flex flex-wrap items-center justify-center gap-8 sm:gap-12 md:gap-14">
              {profiles.map((p) => (
                <div key={p.id} className="group flex min-w-0 flex-col items-center gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveProfile(p.id);
                      void navigate({ to: "/browse", replace: true });
                    }}
                    aria-label={`Entrar como ${p.name}`}
                    className="relative aspect-square size-36 sm:size-44 md:size-48 lg:size-52 overflow-hidden rounded-full bg-surface-elevated shadow-2xl transition-all duration-300 group-hover:scale-110 group-hover:ring-4 group-hover:ring-primary group-hover:shadow-[0_0_35px_rgba(249,56,34,0.45)] focus-visible:outline-none focus-visible:scale-110 focus-visible:ring-4 focus-visible:ring-primary focus-visible:shadow-[0_0_35px_rgba(249,56,34,0.45)] active:scale-95"
                  >
                    {p.avatar ? (
                      <img
                        src={p.avatar}
                        alt={p.name}
                        className="size-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex size-full items-center justify-center font-display text-3xl sm:text-4xl font-extrabold text-muted-foreground">
                        {p.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </button>
                  <span className="w-full max-w-[14rem] truncate text-center font-display text-base sm:text-lg font-bold tracking-tight text-foreground transition-colors group-hover:text-primary">
                    {p.name}
                  </span>
                </div>
              ))}

              {/* Botão de adicionar novo perfil */}
              <div className="group flex min-w-0 flex-col items-center gap-4">
                <button
                  type="button"
                  onClick={() => void navigate({ to: "/profiles/manage" })}
                  aria-label="Criar novo perfil"
                  className="relative flex aspect-square size-36 sm:size-44 md:size-48 lg:size-52 items-center justify-center rounded-full border-2 border-dashed border-muted-foreground/30 bg-surface/30 text-muted-foreground backdrop-blur-md transition-all duration-300 group-hover:scale-110 group-hover:border-primary group-hover:bg-surface/60 group-hover:text-primary group-hover:shadow-[0_0_35px_rgba(249,56,34,0.3)] focus-visible:outline-none focus-visible:scale-110 focus-visible:border-primary focus-visible:text-primary focus-visible:ring-4 focus-visible:ring-primary active:scale-95"
                >
                  <Plus className="size-12 sm:size-16 stroke-[1.75] transition-transform duration-300 group-hover:scale-110" />
                </button>
                <span className="font-display text-base sm:text-lg font-bold tracking-tight text-muted-foreground transition-colors group-hover:text-foreground">
                  Adicionar perfil
                </span>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-6">
              <p className="text-muted-foreground">Nenhum perfil criado ainda.</p>
              <button
                type="button"
                onClick={() => void navigate({ to: "/profiles/manage" })}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-extrabold text-primary-foreground shadow-glow transition-all hover:bg-primary/90 active:scale-95"
              >
                <Plus className="size-5" />
                <span>Criar primeiro perfil</span>
              </button>
            </div>
          )}

          {profiles.length > 0 && (
            <div className="pt-4 text-center">
              <button
                type="button"
                onClick={() => void navigate({ to: "/profiles/manage" })}
                className="inline-flex items-center gap-2 rounded-full bg-surface/60 hover:bg-surface px-6 py-2.5 text-xs sm:text-sm font-semibold text-muted-foreground hover:text-foreground backdrop-blur-md transition-all active:scale-95"
              >
                <Settings className="size-4" />
                <span>Gerenciar perfis</span>
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
