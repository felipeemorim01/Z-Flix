import { useEffect, useMemo } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useFavorites } from "@/hooks/use-library";
import { useStoredCredentials } from "@/hooks/use-xtream";

export const Route = createFileRoute("/favorites")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Favoritos" },
      { name: "description", content: "Seus canais, filmes e séries favoritos." },
    ],
  }),

  component: FavoritesPage,
});

function FavoritesPage() {
  const credentials = useStoredCredentials();
  const navigate = useNavigate();

  useEffect(() => {
    if (!credentials) void navigate({ to: "/", replace: true });
  }, [credentials, navigate]);

  const favorites = useFavorites();

  const { liveItems, movieItems, seriesItems } = useMemo(() => {
    const toItem = (kind: "live" | "movie" | "series") =>
      favorites
        .filter((f) => f.kind === kind)
        .map<RailItem>((f) => ({
          id: f.key,
          title: f.title,
          image: f.image,
          href: f.href,
          favorite: { kind: f.kind, contentId: f.id, episodeId: f.episodeId },
        }));
    return {
      liveItems: toItem("live"),
      movieItems: toItem("movie"),
      seriesItems: toItem("series"),
    };
  }, [favorites]);

  const empty = favorites.length === 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-6xl px-6 py-6 md:px-12 md:py-8">
        {empty ? (
          <div className="mt-16 rounded-2xl border border-dashed border-border p-12 text-center">
            <p className="font-display text-lg font-semibold">Nenhum favorito ainda</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Toque no coração de qualquer card para salvar aqui.
            </p>
            <Link
              to="/browse"
              className="mt-6 inline-block rounded bg-primary px-6 py-3 font-semibold text-primary-foreground"
            >
              Ir para o catálogo
            </Link>
          </div>
        ) : (
          <div className="mt-10 space-y-12">
            {liveItems.length > 0 && (
              <ContentRail id="f-live" title="Canais ao vivo" kind="live" items={liveItems} />
            )}
            {movieItems.length > 0 && (
              <ContentRail id="f-movies" title="Filmes" kind="poster" items={movieItems} />
            )}
            {seriesItems.length > 0 && (
              <ContentRail id="f-series" title="Séries" kind="poster" items={seriesItems} />
            )}
          </div>
        )}
      </main>
    </div>
  );
}
