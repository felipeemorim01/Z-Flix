import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { TmdbTrendingRail } from "@/components/tmdb-rails";
import { InlinePlayer } from "@/components/inline-player";
import { useCredentialsResolved, useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { useProgressList } from "@/hooks/use-library";
import {
  favoriteKey,
  getLatestSeriesEpisodeProgress,
  removeProgress,
  type MediaKind,
} from "@/lib/library";
import { buildSeriesEpisodeUrl, buildVodStreamUrl, proxiedImage } from "@/lib/xtream";
import { playExplosion } from "@/lib/sounds";

export const Route = createFileRoute("/browse")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Início" },
      { name: "description", content: "Explore filmes e séries do seu provedor IPTV no ZéFlix." },
      { property: "og:title", content: "ZéFlix — Início" },
      {
        property: "og:description",
        content: "Explore filmes e séries do seu provedor IPTV no ZéFlix.",
      },
    ],
  }),
  component: BrowsePage,
});

function extFromHref(href: string): string {
  try {
    const q = href.split("?")[1] ?? "";
    return new URLSearchParams(q).get("ext") || "mp4";
  } catch {
    return "mp4";
  }
}

interface PlayingConfig {
  src: string;
  isHls: boolean;
  trackingKey: string;
  entry: {
    kind: MediaKind;
    id: number;
    episodeId?: number;
    title: string;
    image?: string;
    href: string;
  };
}

function BrowsePage() {
  const credentials = useStoredCredentials();
  const credentialsResolved = useCredentialsResolved();
  const navigate = useNavigate();

  useEffect(() => {
    if (credentialsResolved && !credentials) {
      void navigate({ to: "/", replace: true });
    }
  }, [credentials, credentialsResolved, navigate]);

  useEffect(() => {
    playExplosion();
  }, []);

  const progress = useProgressList();
  const catalog = useXtreamCatalog(credentials);
  const [playing, setPlaying] = useState<PlayingConfig | null>(null);

  // Recentemente adicionados — separados por tipo, porque a lista IPTV traz
  // campos distintos (`added` em filmes, `last_modified` em séries) e misturar
  // os dois fazia os filmes dominarem e as séries novas sumirem.
  // Fallback: quando o provedor não envia timestamp, usamos o id (crescente
  // conforme a ordem de inserção no painel Xtream).
  const recentMovies: RailItem[] = useMemo(() => {
    return catalog.vodStreams
      .map((m) => {
        const ts = Number(m.added) * 1000;
        const image = proxiedImage(m.stream_icon);
        const ext = m.container_extension ?? "mp4";
        const p = new URLSearchParams({ ext, title: m.name });
        if (image) p.set("image", image);
        return {
          ts: Number.isFinite(ts) && ts > 0 ? ts : 0,
          id: m.stream_id,
          item: {
            id: `movie-${m.stream_id}`,
            title: m.name,
            image,
            href: `/movie/${m.stream_id}?${p.toString()}`,
            favorite: { kind: "movie" as const, contentId: m.stream_id },
          } satisfies RailItem,
        };
      })
      .sort((a, b) => b.ts - a.ts || b.id - a.id)
      .slice(0, 10)
      .map((x) => x.item);
  }, [catalog.vodStreams]);

  const recentSeries: RailItem[] = useMemo(() => {
    return catalog.series
      .map((s) => {
        const ts = Number(s.last_modified) * 1000;
        return {
          ts: Number.isFinite(ts) && ts > 0 ? ts : 0,
          id: s.series_id,
          item: {
            id: `series-${s.series_id}`,
            title: s.name,
            image: proxiedImage(s.cover),
            href: `/series/${s.series_id}`,
            favorite: { kind: "series" as const, contentId: s.series_id },
          } satisfies RailItem,
        };
      })
      .sort((a, b) => b.ts - a.ts || b.id - a.id)
      .slice(0, 10)
      .map((x) => x.item);
  }, [catalog.series]);

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      <ProfileBackdrop />
      <SiteNav />

      <main className="pb-20">
        <div className="relative z-10 space-y-10 px-4 pt-6 md:px-10">
          {progress.length > 0 && (
            <ContentRail
              id="continue"
              title="Continuar assistindo"
              kind="poster"
              layout="swarm"
              items={progress.slice(0, 20).map((p) => ({
                id: `progress-${p.key}`,
                title: p.title,
                image: p.image,
                progress: p.duration > 0 ? p.position / p.duration : 0,
                onMarkWatched: () => removeProgress(p.key),
                onSelect: () => {
                  if (!credentials) return;
                  if (p.kind === "movie") {
                    const ext = extFromHref(p.href);
                    setPlaying({
                      src: buildVodStreamUrl(credentials, p.id, ext),
                      isHls: false,
                      trackingKey: favoriteKey("movie", p.id),
                      entry: {
                        kind: "movie",
                        id: p.id,
                        title: p.title,
                        image: p.image,
                        href: p.href,
                      },
                    });
                    return;
                  }
                  if (p.kind === "series") {
                    const ep = p.episodeId != null ? p : getLatestSeriesEpisodeProgress(p.id);
                    if (!ep || ep.episodeId == null) {
                      void navigate({ to: p.href });
                      return;
                    }
                    const ext = extFromHref(ep.href);
                    setPlaying({
                      src: buildSeriesEpisodeUrl(credentials, ep.episodeId, ext),
                      isHls: false,
                      trackingKey: favoriteKey("series", p.id, ep.episodeId),
                      entry: {
                        kind: "series",
                        id: p.id,
                        episodeId: ep.episodeId,
                        title: ep.title,
                        image: ep.image ?? p.image,
                        href: ep.href,
                      },
                    });
                    return;
                  }
                  void navigate({ to: p.href });
                },
              }))}
            />
          )}

          <TmdbTrendingRail />

          {recentMovies.length > 0 && (
            <ContentRail
              id="recent-movies"
              title="Filmes adicionados recentemente"
              kind="poster"
              layout="swarm"
              items={recentMovies}
            />
          )}

          {recentSeries.length > 0 && (
            <ContentRail
              id="recent-series"
              title="Séries adicionadas recentemente"
              kind="poster"
              layout="swarm"
              items={recentSeries}
            />
          )}
        </div>
      </main>

      {playing ? (
        <InlinePlayer
          open={true}
          onClose={() => setPlaying(null)}
          src={playing.src}
          isHls={playing.isHls}
          trackingKey={playing.trackingKey}
          entry={playing.entry}
        />
      ) : null}
    </div>
  );
}
