import { createFileRoute } from "@tanstack/react-router";

/**
 * Generic CORS-bypass proxy for Xtream Codes providers.
 *
 *   GET /api/public/proxy?url=<encoded absolute URL>
 *
 * Why this exists:
 *   - Most IPTV providers do NOT send `Access-Control-Allow-Origin`, so the
 *     browser cannot call `player_api.php` or fetch `.m3u8` playlists directly.
 *   - We forward the request server-side, stream the response back, and add
 *     permissive CORS headers.
 *
 * For HLS playlists (`.m3u8`) we additionally rewrite every URI inside the
 * manifest to also flow through this proxy, so segment requests don't trigger
 * CORS either.
 *
 * Security notes:
 *   - Only http/https targets are allowed.
 *   - No credentials are persisted on the server; the URL itself carries the
 *     Xtream user/pass exactly as the user typed it.
 *   - This endpoint sits under /api/public/* and is intentionally unauthenticated
 *     (the user wants to stream from their own provider with no account here).
 */

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Range, Accept",
  "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
  "Access-Control-Max-Age": "86400",
} as const;

function withCors(headers: HeadersInit = {}): Headers {
  const h = new Headers(headers);
  for (const [k, v] of Object.entries(CORS_HEADERS)) h.set(k, v);
  return h;
}

function badRequest(message: string): Response {
  return new Response(JSON.stringify({ error: message }), {
    status: 400,
    headers: withCors({ "Content-Type": "application/json" }),
  });
}

function buildProxiedUrl(origin: string, target: string): string {
  return `${origin}/api/public/proxy?url=${encodeURIComponent(target)}`;
}

/**
 * Rewrite a HLS manifest so every URI (segments + nested playlists) points
 * back through this proxy. Handles both absolute and relative URIs, and the
 * common attribute-style URIs (URI="...").
 */
function rewriteM3u8(body: string, baseUrl: string, proxyOrigin: string): string {
  const base = new URL(baseUrl);

  const resolve = (raw: string): string => {
    try {
      return new URL(raw, base).toString();
    } catch {
      return raw;
    }
  };

  return body
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;

      // Attribute-style URIs (EXT-X-KEY, EXT-X-MAP, etc.)
      if (trimmed.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (_m, uri: string) => {
          return `URI="${buildProxiedUrl(proxyOrigin, resolve(uri))}"`;
        });
      }

      // Plain URI line (segment or nested playlist).
      return buildProxiedUrl(proxyOrigin, resolve(trimmed));
    })
    .join("\n");
}

export const Route = createFileRoute("/api/public/proxy")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: withCors() }),

      GET: async ({ request }) => {
        const incoming = new URL(request.url);
        const target = incoming.searchParams.get("url");
        if (!target) return badRequest("Missing 'url' query parameter.");

        let targetUrl: URL;
        try {
          targetUrl = new URL(target);
        } catch {
          return badRequest("Invalid target URL.");
        }
        if (targetUrl.protocol !== "http:" && targetUrl.protocol !== "https:") {
          return badRequest("Only http/https targets are allowed.");
        }

        // Forward Range header so video seeking works.
        const forwardHeaders = new Headers();
        const range = request.headers.get("range");
        if (range) forwardHeaders.set("Range", range);
        // Alguns provedores Xtream validam User-Agent e/ou Referer no
        // endpoint de mídia (/movie, /series, /live). Imitamos um player
        // IPTV nativo e setamos Referer/Origin alinhados ao próprio host
        // do provedor, que costuma passar nas verificações de hotlinking.
        forwardHeaders.set(
          "User-Agent",
          request.headers.get("user-agent") ?? "VLC/3.0.20 LibVLC/3.0.20",
        );
        forwardHeaders.set("Accept", "*/*");
        forwardHeaders.set("Referer", `${targetUrl.protocol}//${targetUrl.host}/`);
        forwardHeaders.set("Origin", `${targetUrl.protocol}//${targetUrl.host}`);

        let upstream: Response;
        try {
          upstream = await fetch(targetUrl.toString(), {
            method: "GET",
            headers: forwardHeaders,
            redirect: "follow",
          });
        } catch (error) {
          return new Response(
            JSON.stringify({
              error: "Upstream request failed",
              detail: error instanceof Error ? error.message : "unknown",
            }),
            { status: 502, headers: withCors({ "Content-Type": "application/json" }) },
          );
        }

        const contentType = upstream.headers.get("content-type") ?? "";
        const isM3u8 =
          /mpegurl|m3u8/i.test(contentType) ||
          /\.m3u8(\?|$)/i.test(targetUrl.pathname + targetUrl.search);

        const responseHeaders = withCors();

        // Cache-Control: Otimização de banda Vercel (Networking Fast Data Transfer).
        // Para segmentos de vídeo e metadados, instruímos o cache a persistir.
        // Se for manifest (.m3u8), usamos cache curto; se for segmento (.ts/.mp4), cache longo.
        if (upstream.ok) {
          if (isM3u8) {
            responseHeaders.set("Cache-Control", "public, s-maxage=10, stale-while-revalidate=60");
          } else {
            // Segmentos de vídeo são imutáveis.
            responseHeaders.set("Cache-Control", "public, s-maxage=31536000, immutable");
          }
        }

        // Copy a curated subset of response headers.
        for (const name of [
          "content-type",
          "content-length",
          "content-range",
          "accept-ranges",
          "etag",
          "last-modified",
        ]) {
          const value = upstream.headers.get(name);
          if (value) responseHeaders.set(name, value);
        }

        if (isM3u8 && upstream.ok) {
          const text = await upstream.text();
          const proxyOrigin = `${incoming.protocol}//${incoming.host}`;
          const rewritten = rewriteM3u8(text, targetUrl.toString(), proxyOrigin);
          responseHeaders.set("content-type", "application/vnd.apple.mpegurl");
          responseHeaders.delete("content-length");
          return new Response(rewritten, {
            status: upstream.status,
            headers: responseHeaders,
          });
        }

        // For everything else (JSON from player_api.php, .ts segments, MP4, etc.)
        // stream the body through unchanged.
        return new Response(upstream.body, {
          status: upstream.status,
          headers: responseHeaders,
        });
      },
    },
  },
});
