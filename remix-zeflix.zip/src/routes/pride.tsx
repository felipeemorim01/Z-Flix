import { useEffect, useState, useMemo } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useCredentialsResolved, useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { matchTmdbListToRailItems } from "@/lib/catalog-match";
import { getTmdbLgbtq } from "@/lib/tmdb.functions";
import { proxiedImage } from "@/lib/xtream";

export const Route = createFileRoute("/pride")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Pride" },
      {
        name: "description",
        content: "Coleção de filmes, séries e canais Pride reunidos para você.",
      },
      { property: "og:title", content: "ZéFlix — Pride" },
      {
        property: "og:description",
        content: "Coleção de filmes, séries e canais Pride reunidos para você.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PridePage,
});

/**
 * Canais ao vivo não existem no TMDB, então continuam por palavra-chave —
 * mas com um conjunto restrito, para reduzir falsos positivos.
 */
const LIVE_KEYWORDS = ["pride", "lgbt", "lgbtq", "gay tv", "queer"];

function isPrideChannel(text: string): boolean {
  const normalized = text.toLowerCase();
  return LIVE_KEYWORDS.some((kw) => normalized.includes(kw));
}

function PridePage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const credentials = useStoredCredentials();
  const resolved = useCredentialsResolved();
  const navigate = useNavigate();

  useEffect(() => {
    if (mounted && resolved && !credentials) void navigate({ to: "/", replace: true });
  }, [mounted, resolved, credentials, navigate]);

  const catalog = useXtreamCatalog(mounted ? credentials : null);

  const fetchLgbtq = useServerFn(getTmdbLgbtq);
  const { data, isLoading: isLoadingTmdb } = useQuery({
    queryKey: ["tmdb", "lgbtq"],
    queryFn: () => fetchLgbtq(),
    staleTime: 1000 * 60 * 60 * 24,
    gcTime: 1000 * 60 * 60 * 24 * 7,
  });

  // Cruzamento TMDB x lista IPTV: só entra o que existe no seu provedor.
  const matched = useMemo(
    () =>
      matchTmdbListToRailItems(data?.items ?? [], {
        movies: catalog.vodStreams,
        series: catalog.series,
      }),
    [data?.items, catalog.vodStreams, catalog.series],
  );

  const movies = useMemo(() => matched.filter((i) => i.id.startsWith("movie-")), [matched]);
  const series = useMemo(() => matched.filter((i) => i.id.startsWith("series-")), [matched]);

  const live: RailItem[] = useMemo(() => {
    if (!mounted || catalog.isLoading) return [];
    return catalog.liveStreams
      .filter((s) => isPrideChannel(s.name))
      .map((s) => ({
        id: `live-${s.stream_id}`,
        title: s.name,
        image: proxiedImage(s.stream_icon),
        href: `/watch/live/${s.stream_id}?title=${encodeURIComponent(s.name)}`,
        favorite: { kind: "live" as const, contentId: s.stream_id },
      }));
  }, [mounted, catalog.isLoading, catalog.liveStreams]);

  const loading = !mounted || catalog.isLoading || isLoadingTmdb;
  const empty = movies.length === 0 && series.length === 0 && live.length === 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-[1600px] px-6 py-6 md:px-12 md:py-8">
        {data?.hasKey === false ? (
          <div className="rounded-2xl border border-border p-12 text-center text-muted-foreground">
            A curadoria Pride depende da chave TMDB configurada no servidor.
          </div>
        ) : loading ? (
          <p className="text-sm text-muted-foreground">Buscando conteúdos Pride…</p>
        ) : empty ? (
          <div className="rounded-2xl border border-border p-12 text-center">
            <p className="text-lg text-muted-foreground">
              Nenhum título LGBTQIA+ do TMDB foi encontrado na sua lista atual.
            </p>
          </div>
        ) : (
          <div className="space-y-12">
            {live.length > 0 && (
              <ContentRail id="pride-live" title="Canais Pride" kind="live" items={live} />
            )}
            {movies.length > 0 && (
              <ContentRail id="pride-movies" title="Filmes Pride" kind="poster" items={movies} />
            )}
            {series.length > 0 && (
              <ContentRail id="pride-series" title="Séries Pride" kind="poster" items={series} />
            )}
          </div>
        )}
      </main>
    </div>
  );
}
