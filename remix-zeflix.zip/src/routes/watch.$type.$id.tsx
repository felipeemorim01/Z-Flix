import { useEffect, useMemo } from "react";
import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteNav } from "@/components/site-nav";
import { BackButton } from "@/components/back-button";
import { FavoriteButton, favoriteEntryFor } from "@/components/favorite-button";
import { VideoPlayer } from "@/components/video-player";
import { useStoredCredentials } from "@/hooks/use-xtream";
import {
  buildLiveStreamUrl,
  buildSeriesEpisodeUrl,
  buildVodStreamUrl,
  fetchSeriesInfo,
  proxiedImage,
} from "@/lib/xtream";
import { favoriteKey, type MediaKind } from "@/lib/library";

type ContentType = MediaKind; // "live" | "movie" | "series"

interface WatchSearch {
  ext?: string;
  /** Display title (sent by caller so the page can show a meaningful header). */
  title?: string;
  /** Poster/thumbnail URL (already proxied). */
  image?: string;
  /** Parent series id when type === "series". */
  seriesId?: number;
}

export const Route = createFileRoute("/watch/$type/$id")({
  validateSearch: (search: Record<string, unknown>): WatchSearch => ({
    ext: typeof search.ext === "string" ? search.ext : undefined,
    title: typeof search.title === "string" ? search.title : undefined,
    image: typeof search.image === "string" ? search.image : undefined,
    seriesId:
      typeof search.seriesId === "number"
        ? search.seriesId
        : typeof search.seriesId === "string"
          ? Number.parseInt(search.seriesId, 10) || undefined
          : undefined,
  }),
  head: () => ({
    meta: [
      { title: "ZéFlix — Assistindo" },
      { name: "description", content: "Assistindo agora no ZéFlix." },
    ],
  }),
  component: WatchPage,
});

function WatchPage() {
  const params = Route.useParams();
  const search = useSearch({ from: "/watch/$type/$id" });
  const credentials = useStoredCredentials();
  const navigate = useNavigate();

  const rawType = params.type as ContentType;
  const id = Number.parseInt(params.id, 10);
  const validType: ContentType | null =
    rawType === "live" || rawType === "movie" || rawType === "series" ? rawType : null;

  useEffect(() => {
    if (!credentials) void navigate({ to: "/", replace: true });
  }, [credentials, navigate]);

  // For series episodes, fetch series info to compute the next episode.
  // Declared before any early return so hook order stays stable.
  const seriesInfoQuery = useQuery({
    queryKey: ["xtream", "series-info", search.seriesId],
    queryFn: () => fetchSeriesInfo(credentials!, search.seriesId!),
    enabled: !!credentials && validType === "series" && !!search.seriesId,
    staleTime: 5 * 60 * 1000,
  });

  const nextEpisode = useMemo(() => {
    if (validType !== "series" || !search.seriesId || !seriesInfoQuery.data) return null;
    const map = seriesInfoQuery.data.episodes ?? {};
    const seasons = Object.keys(map)
      .map((k) => Number.parseInt(k, 10))
      .filter((n) => !Number.isNaN(n))
      .sort((a, b) => a - b);
    for (let i = 0; i < seasons.length; i++) {
      const list = map[String(seasons[i])] ?? [];
      const idx = list.findIndex((ep) => String(ep.id) === String(id));
      if (idx === -1) continue;
      const nextInSeason = list[idx + 1];
      if (nextInSeason) return { ep: nextInSeason, season: seasons[i] };
      const nextSeasonList = map[String(seasons[i + 1])] ?? [];
      const first = nextSeasonList[0];
      if (first) return { ep: first, season: seasons[i + 1] };
      return null;
    }
    return null;
  }, [validType, search.seriesId, seriesInfoQuery.data, id]);

  if (!credentials || !validType || Number.isNaN(id)) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <SiteNav />
        <div className="mx-auto max-w-xl px-6 py-24 text-center">
          <h1 className="font-display text-2xl font-bold">Invalid stream</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We couldn't resolve this content. Go back and pick another tile.
          </p>
          <Link
            to="/browse"
            className="mt-6 inline-block rounded bg-primary px-6 py-3 font-semibold text-primary-foreground"
          >
            Back to browse
          </Link>
        </div>
      </div>
    );
  }

  const ext = search.ext ?? "mp4";
  const src =
    validType === "live"
      ? buildLiveStreamUrl(credentials, id)
      : validType === "series"
        ? buildSeriesEpisodeUrl(credentials, id, ext)
        : buildVodStreamUrl(credentials, id, ext);
  const isHls = validType === "live";

  // Continue-watching key: use series root for series episodes (so the
  // "Continue" rail surfaces ONE entry per series, on the last episode).
  const contentId = validType === "series" && search.seriesId ? search.seriesId : id;
  const episodeId = validType === "series" ? id : undefined;
  const trackingKey = favoriteKey(validType, contentId, episodeId);

  const title = search.title ?? `Stream #${id}`;
  const trackable = validType !== "live";

  const seriesName = seriesInfoQuery.data?.info?.name ?? search.title?.split(" — ")[0] ?? "";
  const nextHref = (() => {
    if (!nextEpisode || !search.seriesId) return null;
    const ext = nextEpisode.ep.container_extension || "mp4";
    const params = new URLSearchParams({
      ext,
      title: `${seriesName} — S${nextEpisode.season}E${nextEpisode.ep.episode_num}`,
      seriesId: String(search.seriesId),
    });
    const epImage = proxiedImage(nextEpisode.ep.info?.movie_image);
    if (epImage) params.set("image", epImage);
    else if (search.image) params.set("image", search.image);
    return `/watch/series/${nextEpisode.ep.id}?${params.toString()}`;
  })();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteNav />
      <main className="px-4 py-8 md:px-12">
        <div className="mx-auto max-w-6xl">
          <div className="mb-4">
            <BackButton
              fallback={
                validType === "series" && search.seriesId
                  ? `/series/${search.seriesId}`
                  : validType === "movie"
                    ? "/movies"
                    : "/browse"
              }
              label="Voltar"
            />
          </div>

          <VideoPlayer
            src={src}
            isHls={isHls}
            trackingKey={trackable ? trackingKey : undefined}
            nextHref={nextHref}
            entry={{
              kind: validType,
              id: contentId,
              episodeId,
              title,
              image: search.image,
              href: `/watch/${validType}/${id}${buildSearchSuffix(search)}`,
            }}
          />
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-primary">
                {validType === "live"
                  ? "Live channel"
                  : validType === "movie"
                    ? "Movie"
                    : "Episode"}
              </p>
              <h1 className="mt-1 font-display text-2xl font-bold">{title}</h1>
            </div>
            <FavoriteButton
              variant="labelled"
              entry={favoriteEntryFor({
                kind: validType,
                id: contentId,
                episodeId,
                title,
                image: search.image,
                href: `/watch/${validType}/${id}${buildSearchSuffix(search)}`,
              })}
            />
          </div>
        </div>
      </main>
    </div>
  );
}

function buildSearchSuffix(s: WatchSearch): string {
  const params = new URLSearchParams();
  if (s.ext) params.set("ext", s.ext);
  if (s.title) params.set("title", s.title);
  if (s.image) params.set("image", s.image);
  if (s.seriesId) params.set("seriesId", String(s.seriesId));
  const str = params.toString();
  return str ? `?${str}` : "";
}
