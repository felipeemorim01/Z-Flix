import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Search as SearchIcon } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { ProfileBackdrop } from "@/components/profile-backdrop";
import { ContentRail, type RailItem } from "@/components/content-rail";
import { useStoredCredentials, useXtreamCatalog } from "@/hooks/use-xtream";
import { proxiedImage } from "@/lib/xtream";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "ZéFlix — Pesquisar" },
      { name: "description", content: "Pesquise em filmes, séries e TV ao vivo." },
    ],
  }),

  component: SearchPage,
});

function SearchPage() {
  const credentials = useStoredCredentials();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!credentials) void navigate({ to: "/", replace: true });
  }, [credentials, navigate]);

  const catalog = useXtreamCatalog(credentials);
  const [query, setQuery] = useState("");

  // D-pad: garante que o input seja incluído na navegação vertical entre
  // o menu do topo e os resultados abaixo — sem isso o spatial-nav pula direto.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
      const active = document.activeElement as HTMLElement | null;
      const input = inputRef.current;
      if (!active || !input) return;
      // Se o foco está no input, ArrowDown desce direto para o PRIMEIRO
      // resultado — antes que o spatial-nav processe o evento e escolha a
      // linha errada com base no elemento recém-focado.
      if (active === input && e.key === "ArrowDown") {
        const first = document.querySelector<HTMLElement>("main a[href], main button");
        if (first) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          input.blur();
          first.focus();
          first.scrollIntoView({ block: "center", behavior: "smooth" });
        }
        return;
      }
      if (active === input) return;
      const header = document.querySelector("header");
      const main = document.querySelector("main");
      const inHeader = header?.contains(active) ?? false;
      const inMain = main?.contains(active) ?? false;
      const inRail =
        inMain && active.closest("[data-rail-item], main a[href], main button") !== null;
      if (e.key === "ArrowDown" && inHeader) {
        e.preventDefault();
        e.stopPropagation();
        input.focus();
        input.scrollIntoView({ block: "center", behavior: "smooth" });
      } else if (e.key === "ArrowUp" && inRail) {
        // Só intercepta se estamos na primeira linha de resultados
        const rect = active.getBoundingClientRect();
        const inputRect = input.getBoundingClientRect();
        if (rect.top - inputRect.bottom < 400) {
          e.preventDefault();
          e.stopPropagation();
          input.focus();
          input.scrollIntoView({ block: "center", behavior: "smooth" });
        }
      }
    }
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  const q = query.trim().toLowerCase();

  const liveResults: RailItem[] = useMemo(() => {
    if (!q) return [];
    return catalog.liveStreams
      .filter((s) => s.name.toLowerCase().includes(q))
      .slice(0, 24)
      .map((s) => ({
        id: `live-${s.stream_id}`,
        title: s.name,
        image: proxiedImage(s.stream_icon),
        href: `/watch/live/${s.stream_id}?title=${encodeURIComponent(s.name)}`,
        favorite: { kind: "live", contentId: s.stream_id },
      }));
  }, [catalog.liveStreams, q]);

  const movieResults: RailItem[] = useMemo(() => {
    if (!q) return [];
    return catalog.vodStreams
      .filter((s) => s.name.toLowerCase().includes(q))
      .slice(0, 24)
      .map((s) => {
        const image = proxiedImage(s.stream_icon);
        const ext = s.container_extension ?? "mp4";
        const params = new URLSearchParams({ ext, title: s.name });
        if (image) params.set("image", image);
        return {
          id: `vod-${s.stream_id}`,
          title: s.name,
          image,
          href: `/movie/${s.stream_id}?${params.toString()}`,
          favorite: { kind: "movie", contentId: s.stream_id },
        };
      });
  }, [catalog.vodStreams, q]);

  const seriesResults: RailItem[] = useMemo(() => {
    if (!q) return [];
    return catalog.series
      .filter((s) => s.name.toLowerCase().includes(q))
      .slice(0, 24)
      .map((s) => ({
        id: `series-${s.series_id}`,
        title: s.name,
        image: proxiedImage(s.cover),
        href: `/series/${s.series_id}`,
        favorite: { kind: "series", contentId: s.series_id },
      }));
  }, [catalog.series, q]);

  const totalResults = liveResults.length + movieResults.length + seriesResults.length;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProfileBackdrop />
      <SiteNav />
      <main className="mx-auto max-w-6xl px-6 py-6 md:px-12 md:py-8">
        <div>
          <label className="relative block">
            <SearchIcon
              aria-hidden
              className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            />
            <input
              ref={inputRef}
              autoFocus
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  e.currentTarget.blur();
                  const first = document.querySelector<HTMLElement>("main a[href]");
                  first?.focus();
                }
              }}

              placeholder="Digite um título…"
              className={cn(
                "w-full rounded-full border border-border bg-surface py-3 pl-11 pr-4 text-sm text-foreground",
                "placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none",
              )}
            />
          </label>
        </div>

        <div className="mt-10 space-y-12">
          {!q ? (
            <p className="text-sm text-muted-foreground">Comece a digitar para pesquisar.</p>
          ) : catalog.isLoading ? (
            <p className="text-sm text-muted-foreground">Carregando catálogo…</p>
          ) : totalResults === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum resultado para “{query}”.</p>
          ) : (
            <>
              {liveResults.length > 0 && (
                <ContentRail id="s-live" title="Canais ao vivo" kind="live" items={liveResults} />
              )}
              {movieResults.length > 0 && (
                <ContentRail id="s-movies" title="Filmes" kind="poster" items={movieResults} />
              )}
              {seriesResults.length > 0 && (
                <ContentRail id="s-series" title="Séries" kind="poster" items={seriesResults} />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}
