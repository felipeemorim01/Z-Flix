import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import fs from "fs";
import path from "path";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      // Simple admin upload endpoint to persist avatars to public/avatars
      const url = new URL(request.url);
      if (url.pathname === "/api/admin/upload-avatar" && request.method === "POST") {
        try {
          const body = await request.json();
          const { filename, dataUrl } = body as { filename?: string; dataUrl?: string };
          if (
            !filename ||
            !dataUrl ||
            typeof filename !== "string" ||
            typeof dataUrl !== "string"
          ) {
            return new Response(JSON.stringify({ error: "invalid payload" }), {
              status: 400,
              headers: { "content-type": "application/json" },
            });
          }
          // sanitize filename
          const safe = path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, "_");
          const targetDir = path.resolve(process.cwd(), "public", "avatars");
          await fs.promises.mkdir(targetDir, { recursive: true });
          const match = dataUrl.match(/^data:(image\/[a-zA-Z+]+);base64,(.*)$/);
          const b64 = match ? match[2] : null;
          if (!b64)
            return new Response(JSON.stringify({ error: "invalid dataUrl" }), {
              status: 400,
              headers: { "content-type": "application/json" },
            });
          const buf = Buffer.from(b64, "base64");
          const outPath = path.join(targetDir, safe);
          await fs.promises.writeFile(outPath, buf);
          return new Response(JSON.stringify({ ok: true, path: `/avatars/${safe}` }), {
            status: 200,
            headers: { "content-type": "application/json" },
          });
        } catch (err) {
          console.error("upload error", err);
          return new Response(JSON.stringify({ error: "upload_failed" }), {
            status: 500,
            headers: { "content-type": "application/json" },
          });
        }
      }

      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};
