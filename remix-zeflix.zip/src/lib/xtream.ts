import type { XtreamCredentials } from "./credentials";

/**
 * Thin client for the Xtream Codes player API.
 * Every call goes through our same-origin CORS proxy at /api/public/proxy,
 * so the browser never speaks to the IPTV provider directly.
 */

export interface XtreamCategory {
  category_id: string;
  category_name: string;
  parent_id?: number;
}

export interface XtreamLiveStream {
  num: number;
  name: string;
  stream_type: "live";
  stream_id: number;
  stream_icon: string;
  epg_channel_id?: string | null;
  category_id: string;
}

export interface XtreamVodStream {
  num: number;
  name: string;
  stream_type: "movie";
  stream_id: number;
  stream_icon: string;
  rating?: string;
  rating_5based?: number;
  added?: string;
  category_id: string;
  container_extension?: string;
}

export interface XtreamSeries {
  num: number;
  name: string;
  series_id: number;
  cover: string;
  plot?: string;
  cast?: string;
  director?: string;
  genre?: string;
  releaseDate?: string;
  last_modified?: string;
  rating?: string;
  rating_5based?: number;
  category_id: string;
}

export type XtreamAction =
  | "get_live_categories"
  | "get_live_streams"
  | "get_vod_categories"
  | "get_vod_streams"
  | "get_series_categories"
  | "get_series"
  | "get_series_info"
  | "get_vod_info";

const PROXY_PATH = "/api/public/proxy";

function proxied(target: string): string {
  return `${PROXY_PATH}?url=${encodeURIComponent(target)}`;
}

/**
 * Mídia (live/VOD/episódios) usa o MESMO proxy same-origin das chamadas de
 * catálogo. Antes apontava para uma edge function do backend; quando esse
 * backend fica indisponível/pausado, toda a reprodução quebrava com
 * "Failed to fetch". O proxy same-origin não tem essa dependência.
 */
function proxiedStream(target: string): string {
  return `${PROXY_PATH}?url=${encodeURIComponent(target)}`;
}

/** Absolute URL to player_api.php with the requested action. */
function buildPlayerApiUrl(
  creds: XtreamCredentials,
  action: XtreamAction,
  extra?: Record<string, string | number>,
): string {
  const url = new URL(`${creds.serverUrl}/player_api.php`);
  url.searchParams.set("username", creds.username);
  url.searchParams.set("password", creds.password);
  url.searchParams.set("action", action);
  if (extra) {
    for (const [k, v] of Object.entries(extra)) {
      url.searchParams.set(k, String(v));
    }
  }
  return url.toString();
}

/**
 * Bandeira global de "bypass total de cache" para as próximas chamadas ao
 * Xtream — ligada pelo botão "Atualizar" na home. Enquanto `true`, cada
 * fetch anexa `&_=timestamp` na URL e envia `cache: "no-store"`, o que
 * derrota tanto o HTTP cache do WebView da TV Box quanto qualquer proxy
 * intermediário. É consumida somente pelas queries do catálogo IPTV — não
 * afeta TMDB, Supabase nem outras origens.
 */
/**
 * Começa em `true`: a primeira leva de fetches após abrir o app ignora o
 * HTTP cache do WebView. `useXtreamCatalog` desliga assim que o catálogo
 * inicial termina de carregar, devolvendo o comportamento leve às
 * navegações seguintes.
 */
let bustXtreamCache = true;
export function setBustXtreamCache(v: boolean) {
  bustXtreamCache = v;
}

async function fetchJson<T>(target: string): Promise<T> {
  const bust = bustXtreamCache;
  const url = bust ? `${target}${target.includes("?") ? "&" : "?"}_=${Date.now()}` : target;
  const res = await fetch(proxied(url), {
    headers: { Accept: "application/json" },
    cache: bust ? "no-store" : "default",
  });
  if (!res.ok) {
    throw new Error(`Upstream request failed (${res.status})`);
  }
  const text = await res.text();
  if (!text) return [] as unknown as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error("Provider returned a non-JSON response.");
  }
}

/* ---- Categories ----------------------------------------------------------- */

export const fetchLiveCategories = (c: XtreamCredentials) =>
  fetchJson<XtreamCategory[]>(buildPlayerApiUrl(c, "get_live_categories"));

export const fetchVodCategories = (c: XtreamCredentials) =>
  fetchJson<XtreamCategory[]>(buildPlayerApiUrl(c, "get_vod_categories"));

export const fetchSeriesCategories = (c: XtreamCredentials) =>
  fetchJson<XtreamCategory[]>(buildPlayerApiUrl(c, "get_series_categories"));

/* ---- Streams -------------------------------------------------------------- */

export const fetchLiveStreams = (c: XtreamCredentials) =>
  fetchJson<XtreamLiveStream[]>(buildPlayerApiUrl(c, "get_live_streams"));

export const fetchVodStreams = (c: XtreamCredentials) =>
  fetchJson<XtreamVodStream[]>(buildPlayerApiUrl(c, "get_vod_streams"));

export const fetchSeries = (c: XtreamCredentials) =>
  fetchJson<XtreamSeries[]>(buildPlayerApiUrl(c, "get_series"));

/* ---- Series detail (seasons + episodes) ---------------------------------- */

export interface XtreamEpisode {
  id: string;
  episode_num: number;
  title: string;
  container_extension: string;
  info?: {
    movie_image?: string;
    plot?: string;
    duration_secs?: number;
    duration?: string;
  };
}

export interface XtreamSeason {
  season_number: number;
  name?: string;
  cover?: string;
  cover_big?: string;
}

export interface XtreamSeriesInfo {
  info?: {
    name?: string;
    cover?: string;
    plot?: string;
    cast?: string;
    director?: string;
    genre?: string;
    releaseDate?: string;
  };
  seasons?: XtreamSeason[];
  /** Map of season number (string) → episode list. */
  episodes?: Record<string, XtreamEpisode[]>;
}

export const fetchSeriesInfo = (c: XtreamCredentials, seriesId: number) =>
  fetchJson<XtreamSeriesInfo>(buildPlayerApiUrl(c, "get_series_info", { series_id: seriesId }));

/* ---- VOD detail ---------------------------------------------------------- */

export interface XtreamVodInfo {
  info?: {
    name?: string;
    movie_image?: string;
    cover_big?: string;
    backdrop_path?: string[] | string;
    plot?: string;
    description?: string;
    cast?: string;
    actors?: string;
    director?: string;
    genre?: string;
    releasedate?: string;
    release_date?: string;
    duration?: string;
    duration_secs?: number;
    rating?: string;
    tmdb_id?: string | number;
    youtube_trailer?: string;
  };
  movie_data?: {
    stream_id?: number;
    name?: string;
    container_extension?: string;
    category_id?: string;
  };
}

export const fetchVodInfo = (c: XtreamCredentials, vodId: number) =>
  fetchJson<XtreamVodInfo>(buildPlayerApiUrl(c, "get_vod_info", { vod_id: vodId }));

/* ---- Playback URLs (already routed through the proxy) -------------------- */

export function buildLiveStreamUrl(c: XtreamCredentials, streamId: number): string {
  const target = `${c.serverUrl}/live/${encodeURIComponent(c.username)}/${encodeURIComponent(c.password)}/${streamId}.m3u8`;
  return proxiedStream(target);
}

export function buildVodStreamUrl(
  c: XtreamCredentials,
  streamId: number,
  extension = "mp4",
): string {
  const target = `${c.serverUrl}/movie/${encodeURIComponent(c.username)}/${encodeURIComponent(c.password)}/${streamId}.${extension}`;
  return proxiedStream(target);
}

export function buildSeriesEpisodeUrl(
  c: XtreamCredentials,
  episodeId: number | string,
  extension = "mp4",
): string {
  const target = `${c.serverUrl}/series/${encodeURIComponent(c.username)}/${encodeURIComponent(c.password)}/${episodeId}.${extension}`;
  return proxiedStream(target);
}

/**
 * Return a thumbnail/poster URL for use in <img> tags.
 *
 * Imagens NÃO precisam passar pelo proxy CORS: o elemento <img> carrega
 * recursos cross-origin sem validação CORS. Roteá-las pelo Worker apenas
 * sobrecarrega o runtime (limite de tempo/CPU) e gera 502 em hosts lentos
 * como `timg.bdta.pro`. Servimos a URL upstream diretamente.
 */
export function proxiedImage(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  if (!/^https?:\/\//i.test(url)) return undefined;
  return url;
}
