export interface TmdbItem {
  id: number;
  title: string;
  image: string | null;
  kind: "movie" | "tv";
  year: string | null;
  vote: number;
}

export interface TmdbSeed {
  title: string;
  kind: "movie" | "tv";
}
