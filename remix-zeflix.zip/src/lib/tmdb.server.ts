import type { TmdbItem, TmdbSeed } from "./tmdb-types";

const IMG_BASE = "https://image.tmdb.org/t/p/w342";

interface RawTmdbResult {
  id: number;
  title?: string;
  name?: string;
  poster_path?: string | null;
  media_type?: string;
  release_date?: string;
  first_air_date?: string;
  vote_average?: number;
}

interface RawTmdbList {
  results?: RawTmdbResult[];
}

interface RawPersonResult {
  id: number;
  name?: string;
  known_for_department?: string;
  popularity?: number;
}

interface RawPersonSearch {
  results?: RawPersonResult[];
}

interface RawCombinedCredits {
  cast?: RawTmdbResult[];
}

const DEFAULT_TMDB_API_KEY = "53f0c173647830c4251fb2cc22b157ec";

function tmdbKey(): string {
  return process.env.TMDB_API_KEY || DEFAULT_TMDB_API_KEY;
}

function authHeaders(key: string): Record<string, string> {
  if (key.startsWith("eyJ")) return { Authorization: `Bearer ${key}`, accept: "application/json" };
  return { accept: "application/json" };
}

function withKey(url: string, key: string): string {
  if (key.startsWith("eyJ")) return url;
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}api_key=${encodeURIComponent(key)}`;
}

function tmdbUrl(path: string, key: string): string {
  const sep = path.includes("?") ? "&" : "?";
  return withKey(`https://api.themoviedb.org/3${path}${sep}language=pt-BR`, key);
}

async function tmdbFetch<T>(path: string): Promise<T> {
  const key = tmdbKey();
  if (!key) {
    console.warn("TMDB_API_KEY is not set — returning empty result");
    return { results: [] } as unknown as T;
  }
  try {
    const res = await fetch(tmdbUrl(path, key), { headers: authHeaders(key) });
    if (!res.ok) throw new Error(`TMDB ${res.status}`);
    return (await res.json()) as T;
  } catch (err) {
    console.warn(`TMDB fetch failed for ${path}:`, err);
    return { results: [] } as unknown as T;
  }
}

function normalize(raw: RawTmdbResult, fallbackKind?: "movie" | "tv"): TmdbItem | null {
  const kind: "movie" | "tv" =
    raw.media_type === "movie" || raw.media_type === "tv"
      ? raw.media_type
      : (fallbackKind ?? "movie");
  const title = raw.title ?? raw.name ?? "";
  if (!title) return null;
  const date = raw.release_date ?? raw.first_air_date ?? "";
  return {
    id: raw.id,
    title,
    image: raw.poster_path ? `${IMG_BASE}${raw.poster_path}` : null,
    kind,
    year: date ? date.slice(0, 4) : null,
    vote: raw.vote_average ?? 0,
  };
}

async function searchSeed(seed: TmdbSeed): Promise<TmdbItem | null> {
  const search = await tmdbFetch<RawTmdbList>(
    `/search/${seed.kind}?query=${encodeURIComponent(seed.title)}&include_adult=false`,
  );
  const first = search.results?.[0];
  return first ? normalize(first, seed.kind) : null;
}

export async function getTrendingItems(): Promise<TmdbItem[]> {
  const data = await tmdbFetch<RawTmdbList>("/trending/all/day");
  return (data.results ?? [])
    .map((r) => normalize(r))
    .filter((x): x is TmdbItem => x !== null && x.image !== null)
    .slice(0, 60);
}

export async function getRecommendationsForSeeds(
  seeds: TmdbSeed[],
): Promise<{ items: TmdbItem[]; seedTitle: string | null; seed: TmdbItem | null }> {
  const scored = new Map<string, { item: TmdbItem; score: number }>();
  let firstSeedTitle: string | null = null;
  let firstSeed: TmdbItem | null = null;
  const sourceKeys = new Set<string>();

  for (const seed of seeds) {
    const found = await searchSeed(seed);
    if (!found) continue;
    sourceKeys.add(`${found.kind}-${found.id}`);
    if (!firstSeedTitle) firstSeedTitle = seed.title;
    if (!firstSeed) firstSeed = found;

    const rec = await tmdbFetch<RawTmdbList>(`/${found.kind}/${found.id}/recommendations`);
    for (const r of rec.results ?? []) {
      const n = normalize(r, found.kind);
      if (!n || !n.image) continue;
      const key = `${n.kind}-${n.id}`;
      if (sourceKeys.has(key)) continue;
      const prev = scored.get(key);
      const bump = 1 + (n.vote ?? 0) / 20;
      scored.set(key, { item: n, score: (prev?.score ?? 0) + bump });
    }
  }

  const items = [...scored.values()]
    .sort((a, b) => b.score - a.score)
    .slice(0, 30)
    .map((x) => x.item);
  return { items, seedTitle: firstSeedTitle, seed: firstSeed };
}

export async function getPersonCreditsByName(name: string): Promise<TmdbItem[]> {
  const search = await tmdbFetch<RawPersonSearch>(
    `/search/person?query=${encodeURIComponent(name)}&include_adult=false`,
  );
  const person = (search.results ?? [])
    .filter((p) => p.name)
    .sort((a, b) => (b.popularity ?? 0) - (a.popularity ?? 0))[0];
  if (!person) return [];

  const credits = await tmdbFetch<RawCombinedCredits>(`/person/${person.id}/combined_credits`);
  const seen = new Set<string>();
  const items: TmdbItem[] = [];
  for (const raw of credits.cast ?? []) {
    const n = normalize(raw);
    if (!n || !n.image) continue;
    const key = `${n.kind}-${n.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push(n);
  }
  return items.sort((a, b) => b.vote - a.vote).slice(0, 60);
}

/**
 * Catálogo LGBTQIA+ curado pelo próprio TMDB (keywords oficiais),
 * em vez de heurística de palavras no título da lista IPTV — que
 * classificava errado boa parte do catálogo.
 *
 * Keywords: 158718 (lgbt), 264386 (gay), 265451 (lesbian),
 * 10183 (queer/independent-ish fallback removido para evitar ruído).
 */
const LGBT_KEYWORDS = "158718|264386|265451";

export async function getLgbtqItems(): Promise<TmdbItem[]> {
  const paths = [
    `/discover/movie?with_keywords=${LGBT_KEYWORDS}&sort_by=popularity.desc&include_adult=false&page=1`,
    `/discover/movie?with_keywords=${LGBT_KEYWORDS}&sort_by=popularity.desc&include_adult=false&page=2`,
    `/discover/tv?with_keywords=${LGBT_KEYWORDS}&sort_by=popularity.desc&page=1`,
    `/discover/tv?with_keywords=${LGBT_KEYWORDS}&sort_by=popularity.desc&page=2`,
  ];

  const items: TmdbItem[] = [];
  const seen = new Set<string>();
  for (const path of paths) {
    let data: RawTmdbList;
    try {
      data = await tmdbFetch<RawTmdbList>(path);
    } catch {
      continue; // falha parcial não deve derrubar a página
    }
    const kind: "movie" | "tv" = path.includes("/discover/tv") ? "tv" : "movie";
    for (const raw of data.results ?? []) {
      const n = normalize(raw, kind);
      if (!n || !n.image) continue;
      const key = `${n.kind}-${n.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      items.push(n);
    }
  }
  return items;
}
