/**
 * Cores pastéis fixas para cada perfil (1-10).
 * Cada cor é definida em oklch para manter consistência com o design system.
 */

export const PROFILE_COLORS = [
  // Perfil 1 - Caramelo
  {
    background: "oklch(0.18 0.02 50)",
    surface: "oklch(0.22 0.08 50)",
    card: "oklch(0.32 0.10 50)",
    primary: "oklch(0.70 0.12 50)",
  },
  // Perfil 2 - Palha
  {
    background: "oklch(0.19 0.02 60)",
    surface: "oklch(0.24 0.08 60)",
    card: "oklch(0.34 0.10 60)",
    primary: "oklch(0.72 0.12 60)",
  },
  // Perfil 3 - Marrom claro
  {
    background: "oklch(0.20 0.02 40)",
    surface: "oklch(0.25 0.08 40)",
    card: "oklch(0.35 0.10 40)",
    primary: "oklch(0.70 0.12 40)",
  },
  // Perfil 4 - Creme
  {
    background: "oklch(0.21 0.02 70)",
    surface: "oklch(0.26 0.06 70)",
    card: "oklch(0.36 0.08 70)",
    primary: "oklch(0.74 0.10 70)",
  },
  // Perfil 5 - Cinza
  {
    background: "oklch(0.17 0.01 0)",
    surface: "oklch(0.22 0.01 0)",
    card: "oklch(0.32 0.01 0)",
    primary: "oklch(0.68 0.02 0)",
  },
  // Perfil 6 - Verde
  {
    background: "oklch(0.19 0.02 140)",
    surface: "oklch(0.24 0.08 140)",
    card: "oklch(0.34 0.10 140)",
    primary: "oklch(0.72 0.12 140)",
  },
  // Perfil 7 - Vinho
  {
    background: "oklch(0.18 0.02 0)",
    surface: "oklch(0.23 0.10 0)",
    card: "oklch(0.33 0.12 0)",
    primary: "oklch(0.68 0.14 0)",
  },
  // Perfil 8 - Laranja
  {
    background: "oklch(0.20 0.02 30)",
    surface: "oklch(0.25 0.10 30)",
    card: "oklch(0.35 0.12 30)",
    primary: "oklch(0.72 0.14 30)",
  },
  // Perfil 9 - Azul
  {
    background: "oklch(0.19 0.02 260)",
    surface: "oklch(0.24 0.08 260)",
    card: "oklch(0.34 0.10 260)",
    primary: "oklch(0.70 0.12 260)",
  },
  // Perfil 10 - Marinho
  {
    background: "oklch(0.17 0.02 250)",
    surface: "oklch(0.20 0.08 250)",
    card: "oklch(0.30 0.10 250)",
    primary: "oklch(0.65 0.12 250)",
  },
] as const;

export function getProfileColor(colorIndex: number) {
  return PROFILE_COLORS[Math.max(0, Math.min(colorIndex, PROFILE_COLORS.length - 1))];
}
