/**
 * Mock content for the FluxTV browse screen.
 * Will be replaced by real Xtream Codes API data in the next iteration.
 */

export interface MediaTile {
  id: string;
  title: string;
  /** Optional progress 0-1 for "continue watching" rails. */
  progress?: number;
}

export interface ContentRail {
  id: string;
  title: string;
  kind: "live" | "poster";
  items: MediaTile[];
}

export const FEATURED = {
  badge: "New Arrival",
  title: "Neon Pulse: The Last Circuit",
  synopsis:
    "In a world where memories are digital commodities, one rogue agent must overwrite the system before the final shutdown.",
};

export const RAILS: ContentRail[] = [
  {
    id: "live",
    title: "Live TV Now",
    kind: "live",
    items: [
      { id: "l1", title: "Global News 24/7", progress: 0.33 },
      { id: "l2", title: "Champions League LIVE", progress: 0.8 },
      { id: "l3", title: "Culinary Masterclass", progress: 0.5 },
      { id: "l4", title: "Late Night Talk", progress: 0.15 },
      { id: "l5", title: "Discovery Wild", progress: 0.62 },
      { id: "l6", title: "Cinema Classics", progress: 0.42 },
    ],
  },
  {
    id: "trending",
    title: "Trending Movies",
    kind: "poster",
    items: [
      { id: "m1", title: "Horizon Drift" },
      { id: "m2", title: "Whisper in the Fog" },
      { id: "m3", title: "Velocity" },
      { id: "m4", title: "Silent Pines" },
      { id: "m5", title: "Neon Soul" },
      { id: "m6", title: "The Descent" },
      { id: "m7", title: "Null Gravity" },
    ],
  },
  {
    id: "series",
    title: "Series You'll Love",
    kind: "poster",
    items: [
      { id: "s1", title: "Chronos Fragment" },
      { id: "s2", title: "The Midnight Echo" },
      { id: "s3", title: "Obsidian Gates" },
      { id: "s4", title: "Cyber Protocol" },
      { id: "s5", title: "Silent Peak" },
      { id: "s6", title: "Last Signal" },
      { id: "s7", title: "Aurora Bound" },
    ],
  },
];
