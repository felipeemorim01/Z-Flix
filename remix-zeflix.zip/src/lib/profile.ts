/**
 * Perfis locais — sem login/cadastro.
 *
 * Cada perfil guarda apenas um nome e as credenciais da lista IPTV, tudo
 * persistido em `localStorage` no próprio aparelho. Não há autenticação,
 * portanto nada é enviado para a nuvem.
 */

export interface XtreamCredentials {
  serverUrl: string;
  username: string;
  password: string;
}

export interface Profile {
  id: string;
  name: string;
  credentials: XtreamCredentials;
  avatar?: string;
  colorIndex?: number;
  /** Cor do perfil em formato hex ou classe CSS. */
  color?: string;
  /** URL livre do perfil — usada futuramente na aba Relax. */
  relaxUrl?: string;
}

const PROFILES_KEY = "zeflix:profiles:v1";
const ACTIVE_KEY = "zeflix:active-profile:v1";
const AVATAR_SLOTS_KEY = "zeflix:profile-avatar-slots:v1";

type Listener = () => void;
const listeners = new Set<Listener>();
function emit() {
  for (const l of listeners) l();
}
export function subscribeProfiles(l: Listener): () => void {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

function hasStorage(): boolean {
  return typeof localStorage !== "undefined";
}

function readProfiles(): Profile[] {
  if (!hasStorage()) return [];
  try {
    const raw = localStorage.getItem(PROFILES_KEY);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (p): p is Profile =>
        !!p &&
        typeof (p as Profile).id === "string" &&
        typeof (p as Profile).name === "string" &&
        !!(p as Profile).credentials,
    );
  } catch {
    return [];
  }
}

function writeProfiles(list: Profile[]): void {
  if (!hasStorage()) return;
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(list));
  } catch {
    /* noop */
  }
}

function normalizeAvatar(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:image/")) return trimmed;
  if (trimmed.startsWith("/") || /^https?:\/\//.test(trimmed)) return trimmed;
  return null;
}

function getDefaultAvatarSlots(): string[] {
  return [
    "/avatars/1__1_.webp",
    "/avatars/1__1_.jpg",
    "/avatars/1__2_.jpg",
    "/avatars/1__3_.jpg",
    "/avatars/1__4_.jpg",
    "/avatars/1__6_.jpg",
    "/avatars/1__7_.jpg",
    "/avatars/1__8_.jpg",
    "/avatars/1__9_.jpg",
    "/avatars/profile-10-avatar.png",
  ];
}

function readAvatarSlots(): string[] {
  if (!hasStorage()) return getDefaultAvatarSlots();
  try {
    const raw = localStorage.getItem(AVATAR_SLOTS_KEY);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    if (!Array.isArray(parsed)) return getDefaultAvatarSlots();
    const slots = parsed.slice(0, 10).map((value) => normalizeAvatar(value) ?? "");
    // if there are no saved avatars, return the defaults so the UI has images to choose
    const hasAny = slots.some(Boolean);
    if (!hasAny) return getDefaultAvatarSlots();
    return [...slots, ...Array.from({ length: 10 - slots.length }, () => "")].slice(0, 10);
  } catch {
    return getDefaultAvatarSlots();
  }
}

function writeAvatarSlots(slots: string[]): void {
  if (!hasStorage()) return;
  try {
    localStorage.setItem(AVATAR_SLOTS_KEY, JSON.stringify(slots.slice(0, 10)));
  } catch {
    /* noop */
  }
}

export function getProfileAvatarSlots(): string[] {
  return readAvatarSlots();
}

export function saveProfileAvatarSlot(index: number, avatar: string | null): void {
  const slots = readAvatarSlots();
  if (index < 0 || index >= 10) return;
  slots[index] = avatar ?? "";
  writeAvatarSlots(slots);
}

export function listProfiles(): Profile[] {
  return readProfiles();
}

export function getActiveProfileId(): string | null {
  if (!hasStorage()) return null;
  try {
    return localStorage.getItem(ACTIVE_KEY);
  } catch {
    return null;
  }
}

export function getActiveProfile(): Profile | null {
  const id = getActiveProfileId();
  if (!id) return null;
  return readProfiles().find((p) => p.id === id) ?? null;
}

export function setActiveProfile(id: string | null): void {
  if (!hasStorage()) return;
  try {
    if (id) localStorage.setItem(ACTIVE_KEY, id);
    else localStorage.removeItem(ACTIVE_KEY);
  } catch {
    /* noop */
  }
  emit();
}

function newId(): string {
  try {
    return crypto.randomUUID();
  } catch {
    return `p_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }
}

/** Cria (ou atualiza, se o nome já existir) um perfil e o torna ativo. */
export function createProfile(
  name: string,
  credentials: XtreamCredentials,
  avatar?: string,
  color?: string,
  relaxUrl?: string,
): Profile {
  const trimmed = name.trim();
  if (!trimmed) throw new Error("Informe um nome para o perfil.");
  const list = readProfiles();
  const existing = list.find((p) => p.name.toLowerCase() === trimmed.toLowerCase());
  const cleanRelax = relaxUrl?.trim() || undefined;
  const profile: Profile = existing
    ? {
        ...existing,
        name: trimmed,
        credentials,
        avatar: avatar ?? existing.avatar,
        color: color ?? existing.color,
        relaxUrl: cleanRelax,
      }
    : { id: newId(), name: trimmed, credentials, avatar, color, relaxUrl: cleanRelax };
  writeProfiles([profile, ...list.filter((p) => p.id !== profile.id)]);
  setActiveProfile(profile.id);
  return profile;
}

/** Atualiza um perfil existente pelo `id`. Não altera o perfil ativo automaticamente. */
export function updateProfile(
  id: string,
  name: string,
  credentials: XtreamCredentials,
  avatar?: string,
  color?: string,
  relaxUrl?: string,
): Profile {
  const trimmed = name.trim();
  if (!trimmed) throw new Error("Informe um nome para o perfil.");
  const list = readProfiles();
  const existing = list.find((p) => p.id === id);
  if (!existing) throw new Error("Perfil não encontrado.");
  const updated: Profile = {
    ...existing,
    name: trimmed,
    credentials,
    avatar: avatar ?? existing.avatar,
    color: color ?? existing.color,
    relaxUrl: relaxUrl?.trim() || undefined,
  };
  writeProfiles([updated, ...list.filter((p) => p.id !== id)]);
  emit();
  return updated;
}

export function updateActiveCredentials(credentials: XtreamCredentials): void {
  const active = getActiveProfile();
  if (!active) return;
  const list = readProfiles().map((p) => (p.id === active.id ? { ...p, credentials } : p));
  writeProfiles(list);
  emit();
}

export function deleteProfile(id: string): void {
  writeProfiles(readProfiles().filter((p) => p.id !== id));
  if (getActiveProfileId() === id) setActiveProfile(null);
  else emit();
}

/** Normaliza a URL do servidor: remove barra final e garante o esquema. */
export function normalizeServerUrl(input: string): string {
  const trimmed = input.trim().replace(/\/+$/, "");
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `http://${trimmed}`;
}
