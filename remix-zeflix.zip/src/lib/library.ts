/**
 * Library (favoritos + progresso + assistidos) — 100% local.
 *
 * Sem login: os dados ficam em `localStorage`, isolados por perfil ativo
 * (`src/lib/profile.ts`). A API síncrona + pub/sub usada pelos componentes
 * permanece a mesma.
 */

import { getActiveProfileId, subscribeProfiles } from "@/lib/profile";

export type MediaKind = "live" | "movie" | "series";

export interface FavoriteEntry {
  key: string;
  kind: MediaKind;
  id: number;
  episodeId?: number;
  title: string;
  image?: string;
  href: string;
  addedAt: number;
}

export interface ProgressEntry {
  key: string;
  kind: MediaKind;
  id: number;
  episodeId?: number;
  title: string;
  image?: string;
  href: string;
  position: number;
  duration: number;
  updatedAt: number;
}

/* ---- pub/sub --------------------------------------------------------------- */

type Listener = () => void;
const listeners = new Set<Listener>();
function emit() {
  for (const l of listeners) l();
}
export function subscribeLibrary(l: Listener): () => void {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

/* ---- persistência ---------------------------------------------------------- */

function scope(): string {
  return getActiveProfileId() ?? "default";
}
function storageKey(bucket: "favorites" | "progress" | "watched"): string {
  return `zeflix:${bucket}:v2:${scope()}`;
}

function readJson<T>(key: string, fallback: T): T {
  if (typeof localStorage === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function writeJson(key: string, value: unknown): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* noop */
  }
}

/* ---- estado em memória ----------------------------------------------------- */

let favorites: FavoriteEntry[] = [];
let progress: ProgressEntry[] = [];
let watchedSet: Set<string> = new Set();
let loaded = false;
let loadedScope: string | null = null;
let unsubscribeProfiles: (() => void) | null = null;

function persistFavorites() {
  writeJson(storageKey("favorites"), favorites);
}
function persistProgress() {
  writeJson(storageKey("progress"), progress);
}
function persistWatched() {
  writeJson(storageKey("watched"), [...watchedSet]);
}

function loadFromStorage(): void {
  const current = scope();
  favorites = readJson<FavoriteEntry[]>(storageKey("favorites"), []);
  progress = readJson<ProgressEntry[]>(storageKey("progress"), []);
  watchedSet = new Set(readJson<string[]>(storageKey("watched"), []));
  progress = progress.filter((p) => !watchedSet.has(p.key));
  loaded = true;
  loadedScope = current;
}

export function ensureLibraryLoaded(): void {
  if (typeof window === "undefined") return;
  if (!loaded || loadedScope !== scope()) {
    loadFromStorage();
    emit();
  }
  if (!unsubscribeProfiles) {
    unsubscribeProfiles = subscribeProfiles(() => {
      if (loadedScope !== scope()) {
        loadFromStorage();
        emit();
      }
    });
  }
}

/** Compatibilidade: o carregamento é síncrono, então resolve na hora. */
export function whenLibraryLoaded(): Promise<void> {
  ensureLibraryLoaded();
  return Promise.resolve();
}

export function resetLibraryCache(): void {
  favorites = [];
  progress = [];
  watchedSet = new Set();
  loaded = false;
  loadedScope = null;
  emit();
}

/* ---- watched --------------------------------------------------------------- */

export function isWatched(key: string): boolean {
  ensureLibraryLoaded();
  return watchedSet.has(key);
}

export function markWatched(key: string): void {
  ensureLibraryLoaded();
  if (watchedSet.has(key)) return;
  watchedSet.add(key);
  persistWatched();
  emit();
}

export function unmarkWatched(key: string): void {
  ensureLibraryLoaded();
  if (!watchedSet.delete(key)) return;
  persistWatched();
  emit();
}

/* ---- key helper ------------------------------------------------------------ */

export function favoriteKey(kind: MediaKind, id: number, episodeId?: number): string {
  return episodeId != null ? `${kind}:${id}:e${episodeId}` : `${kind}:${id}`;
}

/* ---- favorites ------------------------------------------------------------- */

export function loadFavorites(): FavoriteEntry[] {
  ensureLibraryLoaded();
  return favorites;
}

export function isFavorited(key: string): boolean {
  ensureLibraryLoaded();
  return favorites.some((f) => f.key === key);
}

export function toggleFavorite(entry: Omit<FavoriteEntry, "addedAt">): boolean {
  ensureLibraryLoaded();
  if (favorites.some((f) => f.key === entry.key)) {
    favorites = favorites.filter((f) => f.key !== entry.key);
    persistFavorites();
    emit();
    return false;
  }
  favorites = [{ ...entry, addedAt: Date.now() }, ...favorites];
  persistFavorites();
  emit();
  return true;
}

/* ---- continue watching ----------------------------------------------------- */

export function loadProgress(): ProgressEntry[] {
  ensureLibraryLoaded();
  // 1. Nunca listar itens marcados como assistidos.
  // 2. Para séries, colapsar episódios em um card agregado (`series:<id>`).
  const visible = progress.filter((p) => !watchedSet.has(p.key));
  const seriesWithAggregate = new Set(
    visible.filter((p) => p.kind === "series" && p.episodeId == null).map((p) => p.id),
  );
  return visible.filter((p) => {
    if (p.kind !== "series") return true;
    if (p.episodeId == null) return true;
    return !seriesWithAggregate.has(p.id);
  });
}

export function getProgress(key: string): ProgressEntry | undefined {
  ensureLibraryLoaded();
  return progress.find((p) => p.key === key);
}

/** Episódio mais recente com progresso salvo de uma série. */
export function getLatestSeriesEpisodeProgress(seriesId: number): ProgressEntry | undefined {
  ensureLibraryLoaded();
  return progress
    .filter((p) => p.kind === "series" && p.id === seriesId && p.episodeId != null)
    .sort((a, b) => b.updatedAt - a.updatedAt)[0];
}

function upsertSeriesAggregate(entry: {
  seriesId: number;
  episodeTitle: string;
  image?: string;
}): void {
  const key = favoriteKey("series", entry.seriesId);
  const baseTitle = entry.episodeTitle.split(" — ")[0] || entry.episodeTitle;
  const agg: ProgressEntry = {
    key,
    kind: "series",
    id: entry.seriesId,
    episodeId: undefined,
    title: baseTitle,
    image: entry.image,
    href: `/series/${entry.seriesId}`,
    position: 0,
    duration: 0,
    updatedAt: Date.now(),
  };
  progress = [agg, ...progress.filter((p) => p.key !== key)];
  persistProgress();
  emit();
}

export function saveProgress(entry: Omit<ProgressEntry, "updatedAt">): void {
  ensureLibraryLoaded();
  const done = entry.duration > 0 && entry.position / entry.duration >= 0.95;

  if (done || entry.position < 5) {
    progress = progress.filter((p) => p.key !== entry.key);
  } else {
    progress = [
      { ...entry, updatedAt: Date.now() },
      ...progress.filter((p) => p.key !== entry.key),
    ];
  }
  if (done) markWatched(entry.key);

  if (entry.kind === "series" && entry.episodeId != null && (done || entry.position >= 5)) {
    upsertSeriesAggregate({
      seriesId: entry.id,
      episodeTitle: entry.title,
      image: entry.image,
    });
  }

  persistProgress();
  emit();
}

export function removeProgress(key: string): void {
  ensureLibraryLoaded();
  progress = progress.filter((p) => p.key !== key);
  persistProgress();
  emit();
}
