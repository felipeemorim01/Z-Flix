import type { RailItem } from "@/components/content-rail";
import type { TmdbItem } from "@/lib/tmdb-types";
import { proxiedImage, type XtreamSeries, type XtreamVodStream } from "@/lib/xtream";

export interface IptvCatalogMatch {
  kind: "movie" | "series";
  id: number;
  title: string;
  image?: string;
  href: string;
  vote?: number;
  year?: string | null;
}

const YEAR_RE = /(?:^|\D)((?:19|20)\d{2})(?:\D|$)/;
const BRACKETED_RE = /[[({][^\])}]*[\])}]/g;
const QUALITY_TAGS_RE =
  /\b(4k|uhd|fhd|hd|sd|hdr|h264|h265|x264|x265|bluray|blu-ray|webrip|web-dl|dual|dub|dublado|legendado|leg|nacional|cinema)\b/gi;

export function extractYear(value: string | undefined | null): string | null {
  if (!value) return null;
  const match = value.match(YEAR_RE);
  return match?.[1] ?? null;
}

export function normalizeCatalogTitle(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(BRACKETED_RE, " ")
    .replace(YEAR_RE, " ")
    .replace(QUALITY_TAGS_RE, " ")
    .replace(/[^a-zA-Z0-9]+/g, " ")
    .trim()
    .toLowerCase();
}

function scoreTitle(candidate: string, target: string): number {
  if (!candidate || !target) return 0;
  if (candidate === target) return 100;
  if (candidate.includes(target) || target.includes(candidate)) return 84;

  const cTokens = new Set(candidate.split(" ").filter(Boolean));
  const tTokens = target.split(" ").filter(Boolean);
  if (tTokens.length === 0) return 0;
  const overlap = tTokens.filter((token) => cTokens.has(token)).length;
  return Math.round((overlap / tTokens.length) * 76);
}

function movieHref(movie: XtreamVodStream, image?: string): string {
  const params = new URLSearchParams({
    ext: movie.container_extension ?? "mp4",
    title: movie.name,
  });
  if (image) params.set("image", image);
  return `/movie/${movie.stream_id}?${params.toString()}`;
}

function asRailItem(match: IptvCatalogMatch): RailItem {
  return {
    id: `${match.kind}-${match.id}`,
    title: match.title,
    image: match.image,
    href: match.href,
    vote: match.vote,
    meta: match.year ? match.year : undefined,
    favorite: { kind: match.kind, contentId: match.id },
  };
}

export function matchTmdbToCatalog(
  item: TmdbItem,
  catalog: { movies: XtreamVodStream[]; series: XtreamSeries[] },
): IptvCatalogMatch | null {
  const targetTitle = normalizeCatalogTitle(item.title);
  const targetYear = item.year;

  if (item.kind === "movie") {
    let best: {
      score: number;
      movie: XtreamVodStream;
      image?: string;
      year: string | null;
    } | null = null;
    for (const movie of catalog.movies) {
      const candidateYear = extractYear(movie.name) ?? extractYear(movie.added);
      const titleScore = scoreTitle(normalizeCatalogTitle(movie.name), targetTitle);
      // Regra estrita: quando o TMDB traz o ano e o IPTV também traz um ano
      // no nome/metadata, exigimos coincidência (tolerância de ±1 para
      // lançamentos que atravessam anos). Se o IPTV não traz ano, só
      // aceitamos casamento perfeito de título — evita colar pôster de
      // "Filme (2025)" em um "Filme" antigo do provedor.
      if (targetYear && candidateYear) {
        const diff = Math.abs(Number(targetYear) - Number(candidateYear));
        if (Number.isFinite(diff) && diff > 1) continue;
      } else if (targetYear && !candidateYear && titleScore < 100) {
        continue;
      }
      const yearBonus = targetYear && candidateYear === targetYear ? 12 : 0;
      const score = titleScore + yearBonus;
      if (score < 76) continue;
      if (!best || score > best.score) {
        best = { score, movie, image: proxiedImage(movie.stream_icon), year: candidateYear };
      }
    }
    if (!best) return null;
    return {
      kind: "movie",
      id: best.movie.stream_id,
      title: best.movie.name,
      image: best.image ?? item.image ?? undefined,
      href: movieHref(best.movie, best.image ?? item.image ?? undefined),
      vote: item.vote,
      year: best.year ?? item.year,
    };
  }

  let best: { score: number; series: XtreamSeries; image?: string; year: string | null } | null =
    null;
  for (const series of catalog.series) {
    const candidateYear = extractYear(series.name) ?? extractYear(series.releaseDate);
    const titleScore = scoreTitle(normalizeCatalogTitle(series.name), targetTitle);
    if (targetYear && candidateYear) {
      const diff = Math.abs(Number(targetYear) - Number(candidateYear));
      if (Number.isFinite(diff) && diff > 1) continue;
    } else if (targetYear && !candidateYear && titleScore < 100) {
      continue;
    }
    const yearBonus = targetYear && candidateYear === targetYear ? 12 : 0;
    const score = titleScore + yearBonus;
    if (score < 76) continue;
    if (!best || score > best.score) {
      best = { score, series, image: proxiedImage(series.cover), year: candidateYear };
    }
  }
  if (!best) return null;
  return {
    kind: "series",
    id: best.series.series_id,
    title: best.series.name,
    image: best.image ?? item.image ?? undefined,
    href: `/series/${best.series.series_id}`,
    vote: item.vote,
    year: best.year ?? item.year,
  };
}

export function matchTmdbListToRailItems(
  items: TmdbItem[],
  catalog: { movies: XtreamVodStream[]; series: XtreamSeries[] },
): RailItem[] {
  const seen = new Set<string>();
  const matched: RailItem[] = [];
  for (const item of items) {
    const match = matchTmdbToCatalog(item, catalog);
    if (!match) continue;
    const key = `${match.kind}-${match.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    matched.push(asRailItem(match));
  }
  return matched;
}
