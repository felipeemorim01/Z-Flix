/**
 * Google Cast SDK helper and state management for ZéFlix.
 * Allows casting IPTV streams directly from mobile/web to Smart TVs / Mi TV Stick / Chromecast
 * without proxying video traffic through the hosting server.
 */

export interface CastMediaPayload {
  url: string;
  title: string;
  subtitle?: string;
  image?: string;
  isHls: boolean;
  currentTime?: number;
}

export interface CastState {
  isAvailable: boolean;
  isConnected: boolean;
  deviceName: string | null;
  playerState: "IDLE" | "PLAYING" | "PAUSED" | "BUFFERING" | null;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
}

type CastListener = (state: CastState) => void;

let listeners: CastListener[] = [];
let isInitialized = false;

const currentState: CastState = {
  isAvailable: false,
  isConnected: false,
  deviceName: null,
  playerState: null,
  currentTime: 0,
  duration: 0,
  volume: 1,
  isMuted: false,
};

function notify() {
  const stateCopy = { ...currentState };
  for (const fn of listeners) {
    try {
      fn(stateCopy);
    } catch (e) {
      console.warn("[Cast] Listener error:", e);
    }
  }
}

export function subscribeCastState(listener: CastListener): () => void {
  listeners.push(listener);
  listener({ ...currentState });
  return () => {
    listeners = listeners.filter((l) => l !== listener);
  };
}

export function getCastState(): CastState {
  return { ...currentState };
}

/**
 * Initializes Google Cast Framework. Safe to call multiple times.
 */
export function initCastFramework(): void {
  if (typeof window === "undefined" || isInitialized) return;
  isInitialized = true;

  const setupFramework = () => {
    if (!window.cast || !window.cast.framework || !window.chrome?.cast) return;

    try {
      const context = window.cast.framework.CastContext.getInstance();
      context.setOptions({
        receiverApplicationId: window.chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
        autoJoinPolicy: window.chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED,
      });

      const remotePlayer = new window.cast.framework.RemotePlayer();
      const remotePlayerController = new window.cast.framework.RemotePlayerController(remotePlayer);

      currentState.isAvailable = true;
      notify();

      const updateConnected = () => {
        currentState.isConnected = remotePlayer.isConnected;
        if (remotePlayer.isConnected) {
          const session = context.getCurrentSession();
          currentState.deviceName = session?.getCastDevice()?.friendlyName ?? "Smart TV";
        } else {
          currentState.deviceName = null;
          currentState.playerState = null;
        }
        notify();
      };

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.IS_CONNECTED_CHANGED,
        updateConnected,
      );

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.PLAYER_STATE_CHANGED,
        () => {
          currentState.playerState = remotePlayer.playerState as CastState["playerState"];
          notify();
        },
      );

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.CURRENT_TIME_CHANGED,
        () => {
          currentState.currentTime = remotePlayer.currentTime;
          notify();
        },
      );

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.DURATION_CHANGED,
        () => {
          currentState.duration = remotePlayer.duration;
          notify();
        },
      );

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.VOLUME_LEVEL_CHANGED,
        () => {
          currentState.volume = remotePlayer.volumeLevel;
          notify();
        },
      );

      remotePlayerController.addEventListener(
        window.cast.framework.RemotePlayerEventType.IS_MUTED_CHANGED,
        () => {
          currentState.isMuted = remotePlayer.isMuted;
          notify();
        },
      );

      // Check current session immediately if already connected
      updateConnected();
    } catch (err) {
      console.warn("[Cast] Error initializing Cast context:", err);
    }
  };

  window.__onGCastApiAvailable = (isAvailable: boolean) => {
    if (isAvailable) {
      setupFramework();
    }
  };

  // If the SDK script is already loaded and ready
  if (window.cast?.framework) {
    setupFramework();
  }

  // Load SDK script dynamically if not present in the DOM
  if (typeof document !== "undefined" && !document.getElementById("google-cast-sdk")) {
    try {
      const script = document.createElement("script");
      script.id = "google-cast-sdk";
      script.src = "https://www.gstatic.com/cv/js/sender/v1/cast_sender.js?loadCastFramework=1";
      script.async = true;
      script.crossOrigin = "anonymous";
      script.onerror = () => {
        console.warn("[Cast] Could not load Google Cast SDK script.");
      };
      document.head.appendChild(script);
    } catch (e) {
      console.warn("[Cast] Failed to append Cast SDK script:", e);
    }
  }
}

/**
 * Open the native Google Cast device picker prompt (e.g. Mi TV Stick, Chromecast).
 */
export async function requestCastSession(): Promise<boolean> {
  if (typeof window === "undefined" || !window.cast?.framework) return false;
  try {
    const context = window.cast.framework.CastContext.getInstance();
    await context.requestSession();
    return true;
  } catch (err) {
    console.log("[Cast] User dismissed session prompt or error occurred:", err);
    return false;
  }
}

/**
 * Disconnects the active Cast session.
 */
export function endCastSession(stopCastingMedia = true): void {
  if (typeof window === "undefined" || !window.cast?.framework) return;
  try {
    const context = window.cast.framework.CastContext.getInstance();
    context.endCurrentSession(stopCastingMedia);
  } catch (err) {
    console.warn("[Cast] Error ending session:", err);
  }
}

/**
 * Loads and plays a media stream directly on the Cast device.
 */
export async function castMedia(payload: CastMediaPayload): Promise<boolean> {
  if (typeof window === "undefined" || !window.cast?.framework || !window.chrome?.cast) {
    return false;
  }

  const context = window.cast.framework.CastContext.getInstance();
  const session = context.getCurrentSession();
  if (!session) return false;

  const contentType = payload.isHls ? "application/x-mpegurl" : "video/mp4";
  const isLive = payload.isHls && payload.url.includes("/live/");
  const streamType = isLive
    ? window.chrome.cast.media.StreamType.LIVE
    : window.chrome.cast.media.StreamType.BUFFERED;

  const mediaInfo = new window.chrome.cast.media.MediaInfo(payload.url, contentType);
  mediaInfo.streamType = streamType;

  const metadata = new window.chrome.cast.media.GenericMediaMetadata();
  metadata.title = payload.title;
  if (payload.subtitle) metadata.subtitle = payload.subtitle;
  if (payload.image) {
    metadata.images = [new window.chrome.cast.Image(payload.image)];
  }
  mediaInfo.metadata = metadata;

  const request = new window.chrome.cast.media.LoadRequest(mediaInfo);
  request.autoplay = true;
  if (payload.currentTime && payload.currentTime > 0 && !isLive) {
    request.currentTime = payload.currentTime;
  }

  try {
    await session.loadMedia(request);
    return true;
  } catch (err) {
    console.warn("[Cast] Error loading media on Cast receiver:", err);
    return false;
  }
}

/**
 * Play/pause remote media.
 */
export function castTogglePlayPause(): void {
  if (typeof window === "undefined" || !window.cast?.framework) return;
  try {
    const player = new window.cast.framework.RemotePlayer();
    const controller = new window.cast.framework.RemotePlayerController(player);
    controller.playOrPause();
  } catch (err) {
    console.warn("[Cast] Error toggling play/pause:", err);
  }
}

/**
 * Seek remote media to specific timestamp in seconds.
 */
export function castSeekTo(seconds: number): void {
  if (typeof window === "undefined" || !window.cast?.framework) return;
  try {
    const player = new window.cast.framework.RemotePlayer();
    const controller = new window.cast.framework.RemotePlayerController(player);
    player.currentTime = Math.max(0, seconds);
    controller.seek();
  } catch (err) {
    console.warn("[Cast] Error seeking:", err);
  }
}

/**
 * Set remote volume (0.0 to 1.0).
 */
export function castSetVolume(level: number): void {
  if (typeof window === "undefined" || !window.cast?.framework) return;
  try {
    const player = new window.cast.framework.RemotePlayer();
    const controller = new window.cast.framework.RemotePlayerController(player);
    player.volumeLevel = Math.max(0, Math.min(1, level));
    controller.setVolumeLevel();
  } catch (err) {
    console.warn("[Cast] Error setting volume:", err);
  }
}
