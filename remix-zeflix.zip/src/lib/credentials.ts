/**
 * Credenciais Xtream do perfil ativo.
 *
 * Não há mais login: as credenciais vivem no perfil local
 * (`src/lib/profile.ts`, persistido em localStorage). Mantemos a mesma API
 * síncrona + pub/sub usada pelos componentes.
 */

import {
  getActiveProfile,
  subscribeProfiles,
  updateActiveCredentials,
  type XtreamCredentials,
} from "@/lib/profile";

export type { XtreamCredentials };
export { normalizeServerUrl } from "@/lib/profile";

type Listener = () => void;
const listeners = new Set<Listener>();
function emit() {
  for (const l of listeners) l();
}
export function subscribeCredentials(l: Listener): () => void {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

let cached: XtreamCredentials | null = null;
let loaded = false;
let unsubscribeProfiles: (() => void) | null = null;

function readFromProfile(): void {
  cached = getActiveProfile()?.credentials ?? null;
  loaded = true;
}

export function ensureCredentialsLoaded(): void {
  if (typeof window === "undefined") return;
  if (!loaded) readFromProfile();
  if (!unsubscribeProfiles) {
    unsubscribeProfiles = subscribeProfiles(() => {
      readFromProfile();
      emit();
    });
  }
}

export function isCredentialsLoaded(): boolean {
  return loaded;
}

export function getCachedCredentials(): XtreamCredentials | null {
  return cached;
}

export function resetCredentialsCache(): void {
  cached = null;
  loaded = false;
  emit();
}

export function loadCredentials(): XtreamCredentials | null {
  ensureCredentialsLoaded();
  return cached;
}

/** Atualiza as credenciais do perfil ativo. */
export async function saveCredentials(creds: XtreamCredentials): Promise<void> {
  updateActiveCredentials(creds);
  cached = { ...creds };
  loaded = true;
  emit();
}

export async function clearCredentials(): Promise<void> {
  cached = null;
  loaded = true;
  emit();
}
