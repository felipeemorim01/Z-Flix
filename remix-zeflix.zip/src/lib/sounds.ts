/**
 * Feedback sonoro para navegação (D-pad / mouse / teclado).
 * Usa Web Audio API sintetizada — zero arquivos, zero latência, silenciável.
 *
 * Chame `initSounds()` uma vez (no root); depois use `playMove()` / `playSelect()`.
 * O usuário pode desativar via localStorage: `zeflix:sounds` = "off".
 */

let ctx: AudioContext | null = null;
let enabled = true;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  return ctx;
}

function beep(freq: number, durationMs: number, volume = 0.05, type: OscillatorType = "sine") {
  if (!enabled) return;
  try {
    const ac = getCtx();
    if (!ac) return;
    // Alguns navegadores suspendem o contexto até um gesto do usuário.
    if (ac.state === "suspended") void ac.resume().catch(() => {});
    const now = ac.currentTime;
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationMs / 1000);
    osc.connect(gain).connect(ac.destination);
    osc.start(now);
    osc.stop(now + durationMs / 1000 + 0.02);
  } catch {
    // Ignore audio restriction errors
  }
}

export function initSounds(): void {
  if (typeof window === "undefined") return;
  enabled = window.localStorage.getItem("zeflix:sounds") !== "off";
  // Precisa de um gesto do usuário para "destravar" o AudioContext em navegadores modernos.
  const unlock = () => {
    const ac = getCtx();
    if (ac && ac.state === "suspended") void ac.resume().catch(() => {});
  };
  window.addEventListener("pointerdown", unlock, { once: true });
  window.addEventListener("keydown", unlock, { once: true });
}

export function setSoundsEnabled(on: boolean): void {
  enabled = on;
  if (typeof window !== "undefined") {
    window.localStorage.setItem("zeflix:sounds", on ? "on" : "off");
  }
}

export function areSoundsEnabled(): boolean {
  return enabled;
}

/** Movimento do D-pad / setas — clique curto e discreto. */
export function playMove(): void {
  beep(520, 40, 0.03, "triangle");
}

/** Seleção — OK / Enter / clique em item interativo. */
export function playSelect(): void {
  beep(720, 70, 0.05, "sine");
  window.setTimeout(() => beep(960, 90, 0.04, "sine"), 45);
}

/** Play (iniciar reprodução de um conteúdo). */
export function playStart(): void {
  beep(440, 90, 0.05, "sine");
  window.setTimeout(() => beep(660, 110, 0.05, "sine"), 60);
  window.setTimeout(() => beep(880, 140, 0.05, "sine"), 130);
}

/** Abertura suave e melódica — acorde grave com brilho, tipo "logo sting". */
export function playExplosion(): void {
  if (!enabled) return;
  try {
    const ac = getCtx();
    if (!ac) return;
    if (ac.state === "suspended") void ac.resume().catch(() => {});
    const now = ac.currentTime;

    const master = ac.createGain();
    master.gain.value = 0.9;
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 3;
    master.connect(comp).connect(ac.destination);

    // Acorde Dó maior grave (C2, G2, E3, G3) — cheio, masculino, resolvido.
    const notes = [65.41, 98.0, 164.81, 196.0];
    notes.forEach((freq, i) => {
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = i < 2 ? "sine" : "triangle";
      osc.frequency.setValueAtTime(freq, now);
      const start = now + i * 0.08;
      const peak = 0.22 - i * 0.03;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(peak, start + 0.12);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 2.4);
      osc.connect(gain).connect(master);
      osc.start(start);
      osc.stop(start + 2.5);
    });

    // Brilho superior — quinta aguda que abre e some (G4).
    const shimmer = ac.createOscillator();
    const shimmerGain = ac.createGain();
    shimmer.type = "sine";
    shimmer.frequency.setValueAtTime(392.0, now + 0.35);
    shimmerGain.gain.setValueAtTime(0, now + 0.35);
    shimmerGain.gain.linearRampToValueAtTime(0.12, now + 0.55);
    shimmerGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);
    shimmer.connect(shimmerGain).connect(master);
    shimmer.start(now + 0.35);
    shimmer.stop(now + 2.3);
  } catch {
    // Ignore audio restriction errors
  }
}
