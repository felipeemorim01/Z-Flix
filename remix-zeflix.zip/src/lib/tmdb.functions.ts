import { createServerFn } from "@tanstack/react-start";
import type { TmdbItem, TmdbSeed } from "./tmdb-types";

export type { TmdbItem, TmdbSeed } from "./tmdb-types";

const DEFAULT_TMDB_API_KEY = "53f0c173647830c4251fb2cc22b157ec";
const getTmdbKey = () => process.env.TMDB_API_KEY || DEFAULT_TMDB_API_KEY;

/** Trending "populares hoje" — filmes + séries misturados. */
export const getTmdbTrending = createServerFn({ method: "GET" }).handler(async () => {
  if (!getTmdbKey()) return { items: [] as TmdbItem[], hasKey: false };
  try {
    const { getTrendingItems } = await import("./tmdb.server");
    const items = await getTrendingItems();
    return { items, hasKey: true };
  } catch {
    return { items: [] as TmdbItem[], hasKey: true };
  }
});

/**
 * Dado até ~5 títulos favoritos do usuário, busca recomendações agregadas.
 * Sem chamadas se não houver favoritos.
 */
export const getTmdbRecommendations = createServerFn({ method: "POST" })
  .inputValidator((data: { seeds: TmdbSeed[] }) => {
    if (!data || !Array.isArray(data.seeds)) return { seeds: [] as TmdbSeed[] };
    const seeds: TmdbSeed[] = data.seeds
      .filter((s) => typeof s?.title === "string" && s.title.length > 0)
      .slice(0, 5)
      .map((s) => ({
        title: String(s.title).slice(0, 120),
        kind: s.kind === "tv" ? "tv" : "movie",
      }));
    return { seeds };
  })
  .handler(async ({ data }) => {
    if (!getTmdbKey() || data.seeds.length === 0) {
      return {
        items: [] as TmdbItem[],
        seedTitle: null as string | null,
        seed: null as TmdbItem | null,
        hasKey: Boolean(getTmdbKey()),
      };
    }
    try {
      const { getRecommendationsForSeeds } = await import("./tmdb.server");
      return { ...(await getRecommendationsForSeeds(data.seeds)), hasKey: true };
    } catch {
      return {
        items: [] as TmdbItem[],
        seedTitle: null as string | null,
        seed: null as TmdbItem | null,
        hasKey: true,
      };
    }
  });

export const getTmdbPersonCredits = createServerFn({ method: "POST" })
  .inputValidator((data: { name: string }) => ({
    name: typeof data?.name === "string" ? data.name.trim().slice(0, 120) : "",
  }))
  .handler(async ({ data }) => {
    if (!getTmdbKey() || !data.name) return { items: [] as TmdbItem[], hasKey: false };
    try {
      const { getPersonCreditsByName } = await import("./tmdb.server");
      const items = await getPersonCreditsByName(data.name);
      return { items, hasKey: true };
    } catch {
      return { items: [] as TmdbItem[], hasKey: true };
    }
  });

/** Catálogo LGBTQIA+ segundo as keywords oficiais do TMDB. */
export const getTmdbLgbtq = createServerFn({ method: "GET" }).handler(async () => {
  if (!getTmdbKey()) return { items: [] as TmdbItem[], hasKey: false };
  try {
    const { getLgbtqItems } = await import("./tmdb.server");
    return { items: await getLgbtqItems(), hasKey: true };
  } catch {
    return { items: [] as TmdbItem[], hasKey: true };
  }
});
