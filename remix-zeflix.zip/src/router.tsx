import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        // Catálogo IPTV muda pouco; reusar cache entre navegações.
        staleTime: 5 * 60 * 1000,
        gcTime: 30 * 60 * 1000,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
        retry: 1,
      },
    },
  });

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    // Pré-carrega rota ao focar/hover (setas do D-pad também disparam foco).
    defaultPreload: "intent",
    defaultPreloadDelay: 0,
    // TanStack Query controla a validade — router não precisa reprocessar.
    defaultPreloadStaleTime: 0,
    // Não mostrar tela pendente instantaneamente: evita flash em nav rápida.
    defaultPendingMs: 300,
    defaultPendingMinMs: 0,
  });

  return router;
};
