# Plano de Otimização Visual e Categorias

Este plano descreve as alterações para otimizar a exibição das categorias nas abas de filmes e séries, padronizar o tamanho de todos os cartazes de conteúdo conforme a página Pride e aplicar as cores de perfil predefinidas.

## Alterações Visuais

### 1. Categorias (Filmes e Séries)

- **Novo Formato:** Substituir a lista lateral/larga por uma coluna de ícones de 50x50 pixels.
- **Títulos:** Remover o prefixo "Filmes | " ou "Séries | " e manter apenas o nome da categoria.
- **Design:** O título será exibido dentro ou sobreposto ao ícone quadrado, mantendo a identidade visual compacta.

### 2. Padronização de Cartazes (Posters)

- **Tamanho Único:** Ajustar todos os cards de conteúdo (`ContentRail`, `PosterCard`) para usar o mesmo dimensionamento da página Pride.
- **Consistência:** Isso afetará a Home, Pesquisar, Recomendações, Favoritos e Catálogos, garantindo que a interface não mude o tamanho dos posters entre as telas.

### 3. Cores de Perfil

- **Integração:** Garantir que as cores predefinidas no sistema de perfis sejam aplicadas corretamente aos elementos de destaque (bordas de foco, botões ativos) em todas as páginas modificadas.

## Detalhes Técnicos

- **Componente `CatalogPage`:**
  - Alterar o layout da `aside` para usar `grid-cols-5` ou similar em mobile e uma coluna de botões 50x50 em desktop.
  - Implementar o `regex` ou `split` no nome da categoria: `name.split('|').pop()?.trim()`.
- **Componente `ContentRail` / `PosterCard`:**
  - Ajustar as classes de largura (`w-[...]`) e `aspect-ratio` para corresponder ao layout da página Pride.
  - Atualmente a página Pride usa `layout="poster"` (padrão `grid` com `grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6`).
  - O `swarm` layout será ajustado para manter a densidade mas com o tamanho do poster da Pride.
- **Estilização:**
  - Uso de cores dinâmicas via `activeProfile?.color` para bordas e estados ativos.

## Arquivos a serem modificados:

- `src/components/catalog-page.tsx`
- `src/components/content-rail.tsx`
- `src/routes/browse.tsx`
- `src/routes/search.tsx`
- `src/routes/recommendations.tsx`
- `src/routes/favorites.tsx`
- `src/routes/pride.tsx`
